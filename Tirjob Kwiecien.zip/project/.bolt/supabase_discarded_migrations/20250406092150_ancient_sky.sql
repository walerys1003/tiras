/*
  # Fix RLS policies for users table

  1. Changes
    - Drop existing RLS policies for users table
    - Create new policies that allow proper user creation and management
    - Add policy for inserting users by authenticated users
    - Add policy for inserting users by the system

  2. Security
    - Maintain proper access control
    - Allow admin users to manage all users
    - Allow users to update their own data
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON users;

-- Create new policies
-- Allow anyone to read users (needed for auth checks)
CREATE POLICY "Anyone can view users"
  ON users
  FOR SELECT
  TO public
  USING (true);

-- Allow authenticated users to update their own data
CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid());

-- Allow authenticated users to insert users (needed for registration)
CREATE POLICY "Authenticated users can insert users"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow system to insert users (needed for trigger functions)
CREATE POLICY "System can insert users"
  ON users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow admin users to update any user
CREATE POLICY "Admin users can update any user"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Allow admin users to delete users
CREATE POLICY "Admin users can delete users"
  ON users
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );