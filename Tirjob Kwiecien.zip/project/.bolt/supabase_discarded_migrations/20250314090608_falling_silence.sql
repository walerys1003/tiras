/*
  # Add uniqueness constraints and indexes for locations

  1. Changes
    - Add unique constraints for country names
    - Add unique constraints for city names within a country
    - Add unique constraints for voivodeship names within a country
    - Add indexes for better query performance

  2. Security
    - Maintain existing RLS policies
    - Ensure data integrity
*/

-- Add unique constraints
ALTER TABLE job_countries 
ADD CONSTRAINT job_countries_country_name_key UNIQUE (country_name);

ALTER TABLE job_cities 
ADD CONSTRAINT job_cities_city_name_country_id_key UNIQUE (city_name, country_id);

ALTER TABLE job_voivodeships 
ADD CONSTRAINT job_voivodeships_name_country_id_key UNIQUE (name, country_id);

-- Add additional indexes for performance
CREATE INDEX IF NOT EXISTS idx_job_cities_city_name ON job_cities(city_name);
CREATE INDEX IF NOT EXISTS idx_job_cities_country_id ON job_cities(country_id);
CREATE INDEX IF NOT EXISTS idx_job_cities_voivodeship_id ON job_cities(voivodeship_id);

CREATE INDEX IF NOT EXISTS idx_job_voivodeships_name ON job_voivodeships(name);
CREATE INDEX IF NOT EXISTS idx_job_voivodeships_country_id ON job_voivodeships(country_id);

-- Function to normalize text (remove extra spaces, convert to lowercase)
CREATE OR REPLACE FUNCTION normalize_text(input_text text)
RETURNS text AS $$
BEGIN
  RETURN trim(regexp_replace(lower(input_text), '\s+', ' ', 'g'));
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Add trigger to normalize city names before insert/update
CREATE OR REPLACE FUNCTION normalize_city_name()
RETURNS TRIGGER AS $$
BEGIN
  NEW.city_name = normalize_text(NEW.city_name);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER normalize_city_name_trigger
  BEFORE INSERT OR UPDATE ON job_cities
  FOR EACH ROW
  EXECUTE FUNCTION normalize_city_name();

-- Add trigger to normalize country names before insert/update
CREATE OR REPLACE FUNCTION normalize_country_name()
RETURNS TRIGGER AS $$
BEGIN
  NEW.country_name = normalize_text(NEW.country_name);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER normalize_country_name_trigger
  BEFORE INSERT OR UPDATE ON job_countries
  FOR EACH ROW
  EXECUTE FUNCTION normalize_country_name();

-- Add trigger to normalize voivodeship names before insert/update
CREATE OR REPLACE FUNCTION normalize_voivodeship_name()
RETURNS TRIGGER AS $$
BEGIN
  NEW.name = normalize_text(NEW.name);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER normalize_voivodeship_name_trigger
  BEFORE INSERT OR UPDATE ON job_voivodeships
  FOR EACH ROW
  EXECUTE FUNCTION normalize_voivodeship_name();

-- Clean up any existing duplicates
DO $$
DECLARE
  duplicate RECORD;
BEGIN
  -- Clean up duplicate cities
  FOR duplicate IN
    SELECT MIN(id) as keep_id, city_name, country_id, array_agg(id) as ids
    FROM job_cities
    GROUP BY city_name, country_id
    HAVING COUNT(*) > 1
  LOOP
    -- Update job posts to use the kept city id
    UPDATE job_posts 
    SET city_id = duplicate.keep_id
    WHERE city_id = ANY(duplicate.ids) 
    AND city_id != duplicate.keep_id;
    
    -- Delete duplicate cities
    DELETE FROM job_cities 
    WHERE id = ANY(duplicate.ids) 
    AND id != duplicate.keep_id;
  END LOOP;

  -- Clean up duplicate voivodeships
  FOR duplicate IN
    SELECT MIN(id) as keep_id, name, country_id, array_agg(id) as ids
    FROM job_voivodeships
    GROUP BY name, country_id
    HAVING COUNT(*) > 1
  LOOP
    -- Update cities to use the kept voivodeship id
    UPDATE job_cities
    SET voivodeship_id = duplicate.keep_id
    WHERE voivodeship_id = ANY(duplicate.ids)
    AND voivodeship_id != duplicate.keep_id;
    
    -- Delete duplicate voivodeships
    DELETE FROM job_voivodeships
    WHERE id = ANY(duplicate.ids)
    AND id != duplicate.keep_id;
  END LOOP;
END $$;