/*
  # Fix users table RLS policies to prevent infinite recursion

  1. Changes
    - Drop all existing policies on users table
    - Create new simplified policies that avoid recursion:
      - Allow public read access to all users
      - Allow users to update their own data based on email
      - Allow public insert for system operations
      - Allow admin-only delete operations

  2. Security
    - Enable RLS
    - Prevent infinite recursion in policies
    - Maintain proper access control
*/

-- Drop all existing policies to start fresh
DO $$
BEGIN
  -- Drop all policies on users table
  DROP POLICY IF EXISTS "Enable read access for all users" ON users;
  DROP POLICY IF EXISTS "Enable update for users based on email" ON users;
  DROP POLICY IF EXISTS "Enable admin insert for users" ON users;
  DROP POLICY IF EXISTS "Enable delete for admin users" ON users;
  DROP POLICY IF EXISTS "Admins can read all users" ON users;
  DROP POLICY IF EXISTS "Users can read own data" ON users;
  DROP POLICY IF EXISTS "Admins can update users" ON users;
  DROP POLICY IF EXISTS "Users can update own data except role" ON users;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new simplified policies that avoid recursion

-- 1. Allow public read access to all users
-- This avoids recursion by not checking user roles in the policy
CREATE POLICY "Enable read access for all users"
ON users
FOR SELECT
TO public
USING (true);

-- 2. Allow users to update their own data based on email
-- This avoids recursion by using JWT claims directly
CREATE POLICY "Enable update for users based on email"
ON users
FOR UPDATE
TO public
USING (
  email = current_setting('request.jwt.claims', true)::json->>'email'
);

-- 3. Allow public insert for system operations
-- This is needed for trigger functions and initial setup
CREATE POLICY "Enable public insert for users"
ON users
FOR INSERT
TO public
WITH CHECK (true);

-- 4. Allow admin-only delete operations
-- This uses JWT claims to check admin role
CREATE POLICY "Enable delete for admin users"
ON users
FOR DELETE
TO public
USING (
  current_setting('request.jwt.claims', true)::json->'app_metadata'->>'role' = 'admin'
);