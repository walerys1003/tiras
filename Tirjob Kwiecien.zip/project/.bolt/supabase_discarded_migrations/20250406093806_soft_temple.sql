/*
  # Fix users table policies

  1. Changes
    - Remove recursive policies that were causing infinite loops
    - Simplify user access policies
    - Add proper RLS policies for user data access

  2. Security
    - Enable RLS on users table
    - Add policies for:
      - Users can read their own data
      - Admins can read all user data
      - Users can update their own data
      - Admins can update any user data
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new, non-recursive policies
CREATE POLICY "Users can read own data"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.uid() = id
  OR 
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
);

CREATE POLICY "Users can update own data"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.uid() = id
  OR 
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
)
WITH CHECK (
  auth.uid() = id
  OR 
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
);

-- Add index to improve policy performance
CREATE INDEX IF NOT EXISTS idx_users_id ON public.users(id);