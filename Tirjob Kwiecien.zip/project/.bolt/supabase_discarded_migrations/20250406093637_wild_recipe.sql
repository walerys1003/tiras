/*
  # Fix recursive policies on users table

  1. Changes
    - Drop existing policies on users table that may cause recursion
    - Add new, non-recursive policies for:
      - Select: Allow users to read their own data and admins to read all data
      - Update: Allow users to update their own data and admins to update all data
      - Delete: Only allow admins to delete users
      
  2. Security
    - Enable RLS on users table
    - Add specific policies for each operation
    - Prevent recursive policy checks by using direct role comparisons
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new non-recursive policies
CREATE POLICY "Users can read own data"
ON public.users
FOR SELECT
TO public
USING (
  auth.uid() = id 
  OR 
  EXISTS (
    SELECT 1 
    FROM auth.users au 
    WHERE au.id = auth.uid() 
    AND (au.raw_app_meta_data->>'role')::text = 'admin'
  )
);

CREATE POLICY "Users can update own data"
ON public.users
FOR UPDATE
TO public
USING (
  auth.uid() = id 
  OR 
  EXISTS (
    SELECT 1 
    FROM auth.users au 
    WHERE au.id = auth.uid() 
    AND (au.raw_app_meta_data->>'role')::text = 'admin'
  )
)
WITH CHECK (
  auth.uid() = id 
  OR 
  EXISTS (
    SELECT 1 
    FROM auth.users au 
    WHERE au.id = auth.uid() 
    AND (au.raw_app_meta_data->>'role')::text = 'admin'
  )
);

CREATE POLICY "Only admins can delete users"
ON public.users
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 
    FROM auth.users au 
    WHERE au.id = auth.uid() 
    AND (au.raw_app_meta_data->>'role')::text = 'admin'
  )
);