/*
  # Add automatic email confirmation for new users

  1. Changes
    - Create a trigger function to automatically confirm email addresses for new users
    - Add trigger to auth.users table to run after insert
    - Update existing users to have confirmed emails

  2. Security
    - Maintains existing security model
    - Only affects email confirmation status
*/

-- Create function to automatically confirm email for new users
CREATE OR REPLACE FUNCTION auto_confirm_user_email()
RETURNS TRIGGER AS $$
BEGIN
  -- Set email_confirmed_at to current timestamp if it's not already set
  IF NEW.email_confirmed_at IS NULL THEN
    UPDATE auth.users
    SET email_confirmed_at = now()
    WHERE id = NEW.id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically confirm email for new users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'auto_confirm_user_email_trigger'
  ) THEN
    CREATE TRIGGER auto_confirm_user_email_trigger
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION auto_confirm_user_email();
  END IF;
END $$;

-- Update existing users to have confirmed emails
UPDATE auth.users
SET email_confirmed_at = now()
WHERE email_confirmed_at IS NULL;

-- Log the change
DO $$
BEGIN
  RAISE NOTICE 'Added automatic email confirmation for new users';
END $$;