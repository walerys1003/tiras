/*
  # Fix RLS policies for users table

  1. Changes
    - Drop existing problematic policies
    - Add new policies that:
      - Allow admins to perform all operations
      - Allow users to read their own data
      - Allow users to update their own data
      - Prevent infinite recursion by using auth.uid() instead of subqueries

  2. Security
    - Maintains RLS protection
    - Properly scopes user access
    - Prevents unauthorized access while allowing admin management
*/

-- Drop existing policies to clean up
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON users;

-- Create new policies that avoid recursion and properly handle permissions

-- Allow admins to do everything
CREATE POLICY "Enable full access for admins"
ON users
FOR ALL
TO authenticated
USING (
  auth.jwt() ->> 'role' = 'admin'
)
WITH CHECK (
  auth.jwt() ->> 'role' = 'admin'
);

-- Allow users to read their own data
CREATE POLICY "Users can read own data"
ON users
FOR SELECT
TO authenticated
USING (
  auth.uid() = id
);

-- Allow users to update their own data (except role)
CREATE POLICY "Users can update own data"
ON users
FOR UPDATE
TO authenticated
USING (
  auth.uid() = id
)
WITH CHECK (
  auth.uid() = id AND
  -- Prevent users from changing their own role
  (role IS NOT DISTINCT FROM OLD.role)
);