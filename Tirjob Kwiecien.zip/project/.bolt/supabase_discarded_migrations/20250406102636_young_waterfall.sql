/*
  # Fix user deletion permissions

  1. Changes
    - Add policy to allow admin users to delete users
    - Ensure admin role is properly checked
    - Fix trigger for cascading deletion to auth.users

  2. Security
    - Maintain proper role-based access control
    - Ensure only admins can delete users
*/

-- Drop existing delete policy if it exists
DROP POLICY IF EXISTS "Enable delete for admin users" ON users;

-- Create a new policy that allows admin users to delete users
CREATE POLICY "Enable delete for admin users"
ON users
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 
    FROM users
    WHERE users.id = auth.uid() 
    AND users.role = 'admin'
  )
);

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS on_user_delete ON users;
DROP FUNCTION IF EXISTS handle_user_delete();

-- Create function to handle user deletion from users table to auth.users
CREATE OR REPLACE FUNCTION handle_user_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete from auth.users if the user exists
  DELETE FROM auth.users WHERE id = OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to handle user deletion
CREATE TRIGGER on_user_delete
  AFTER DELETE ON users
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_delete();