/*
  # Fix users table RLS policy recursion

  1. Changes
    - Drop existing problematic policies on users table
    - Create new, simplified policies that avoid recursion:
      - Allow admins to read all users
      - Allow users to read their own data
      - Allow admins to update user roles
      - Allow users to update their own non-role data

  2. Security
    - Maintains RLS protection
    - Prevents infinite recursion in policy evaluation
    - Ensures proper access control based on user roles
*/

-- Drop existing policies to start fresh
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new non-recursive policies
CREATE POLICY "Allow admins to read all users"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.jwt() ->> 'role' = 'admin'
);

CREATE POLICY "Allow users to read own data"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.uid() = id
);

CREATE POLICY "Allow admins to update user roles"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.jwt() ->> 'role' = 'admin'
)
WITH CHECK (
  auth.jwt() ->> 'role' = 'admin'
);

CREATE POLICY "Allow users to update own data"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.uid() = id AND 
  auth.jwt() ->> 'role' != 'admin'
)
WITH CHECK (
  auth.uid() = id AND
  auth.jwt() ->> 'role' != 'admin'
);