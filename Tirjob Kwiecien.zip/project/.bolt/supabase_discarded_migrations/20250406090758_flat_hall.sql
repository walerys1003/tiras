/*
  # Fix admin authentication

  1. Changes
    - Reset admin user password
    - Ensure admin user has correct role in app_metadata
    - Update email_confirmed_at to ensure immediate access
    - Add proper error handling

  2. Security
    - Store properly hashed password
    - Set correct role in app_metadata
    - Enable immediate access
*/

-- Delete existing admin user to start fresh
DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';

-- Create admin user with proper metadata and confirmed email
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  confirmation_token,
  recovery_token,
  email_change_token_new,
  email_change,
  created_at,
  updated_at,
  last_sign_in_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  is_sso_user
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@tirjob.pl',
  crypt('admin123', gen_salt('bf')), -- Simple password for testing
  now(),
  '',
  '',
  '',
  '',
  now(),
  now(),
  now(),
  '{"provider": "email", "providers": ["email"], "role": "admin"}',
  '{"name": "Administrator"}',
  false,
  false
)
ON CONFLICT (email) DO UPDATE
SET 
  encrypted_password = crypt('admin123', gen_salt('bf')),
  email_confirmed_at = now(),
  raw_app_meta_data = '{"provider": "email", "providers": ["email"], "role": "admin"}',
  raw_user_meta_data = '{"name": "Administrator"}';

-- Ensure admin user exists in users table
DO $$
DECLARE
  admin_id uuid;
BEGIN
  SELECT id INTO admin_id FROM auth.users WHERE email = 'admin@tirjob.pl';
  
  IF admin_id IS NOT NULL THEN
    INSERT INTO users (id, email, name, role)
    VALUES (
      admin_id,
      'admin@tirjob.pl',
      'Administrator',
      'admin'
    )
    ON CONFLICT (id) DO UPDATE
    SET role = 'admin';
  END IF;
END $$;