/*
  # Add admin user to users table

  1. Changes
    - Ensure admin user exists in auth.users
    - Ensure admin user exists in users table
    - Set proper role and metadata
    - Use simple password for testing

  2. Security
    - Maintain existing RLS policies
    - Ensure proper role assignment
*/

-- Ensure admin user exists in auth.users with proper role
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Check if admin user exists in auth.users
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';
  
  IF admin_user_id IS NULL THEN
    -- Admin user doesn't exist, create it
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      confirmation_token,
      recovery_token,
      email_change_token_new,
      email_change,
      created_at,
      updated_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      is_sso_user
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@tirjob.pl',
      crypt('admin123', gen_salt('bf')),
      now(),
      '',
      '',
      '',
      '',
      now(),
      now(),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "admin"}',
      '{"name": "Administrator"}',
      false,
      false
    )
    RETURNING id INTO admin_user_id;
  ELSE
    -- Admin user exists, ensure it has admin role in metadata
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        '"admin"'
      ),
      email_confirmed_at = now()
    WHERE id = admin_user_id;
  END IF;
  
  -- Ensure admin user exists in users table
  INSERT INTO users (id, email, name, role)
  VALUES (
    admin_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin'
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    role = 'admin',
    name = 'Administrator';
    
  -- Ensure admin user exists in users table by email (fallback)
  INSERT INTO users (id, email, name, role)
  VALUES (
    admin_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin'
  )
  ON CONFLICT (email) DO UPDATE
  SET 
    role = 'admin',
    name = 'Administrator';
END $$;