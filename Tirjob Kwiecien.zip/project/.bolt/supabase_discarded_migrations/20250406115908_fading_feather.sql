/*
  # Fix user role permissions and constraints

  1. Changes
    - Update users_role_check constraint to include all valid roles
    - Create function to sync user roles between tables
    - Add trigger to update auth.users metadata when users table is updated
    - Fix permissions for user deletion

  2. Security
    - Ensure proper role synchronization between tables
    - Fix permission issues for user management
*/

-- First, ensure the users_role_check constraint includes all valid roles
ALTER TABLE users 
DROP CONSTRAINT IF EXISTS users_role_check;

ALTER TABLE users 
ADD CONSTRAINT users_role_check 
CHECK (role = ANY (ARRAY['admin', 'redaktor', 'moderator', 'user']));

-- Create or replace function to sync user role with auth metadata
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
BEGIN
  -- Update auth.users metadata with the new role
  UPDATE auth.users
  SET raw_app_meta_data = jsonb_set(
    COALESCE(raw_app_meta_data, '{}'::jsonb),
    '{role}',
    to_jsonb(NEW.role)
  )
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role changes
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

CREATE TRIGGER sync_user_role_trigger
  AFTER INSERT OR UPDATE OF role ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Create function to handle new auth users
CREATE OR REPLACE FUNCTION handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into users table if not exists
  INSERT INTO public.users (id, email, name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_app_meta_data->>'role', 'user')
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new auth users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_auth_user();

-- Create function to handle user deletion
CREATE OR REPLACE FUNCTION handle_user_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete from auth.users if the user exists
  DELETE FROM auth.users WHERE id = OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to handle user deletion
DROP TRIGGER IF EXISTS on_user_delete ON users;

CREATE TRIGGER on_user_delete
  AFTER DELETE ON users
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_delete();

-- Drop existing policies to clean up
DO $$
BEGIN
  DROP POLICY IF EXISTS "Enable read access for all users" ON users;
  DROP POLICY IF EXISTS "Enable update for users based on email" ON users;
  DROP POLICY IF EXISTS "Enable public insert for users" ON users;
  DROP POLICY IF EXISTS "Enable delete for admin users" ON users;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
-- Allow anyone to read users table (needed for auth checks)
CREATE POLICY "Enable read access for all users"
ON users
FOR SELECT
TO public
USING (true);

-- Allow users to update their own data
CREATE POLICY "Enable update for users based on email"
ON users
FOR UPDATE
TO public
USING (
  email = (current_setting('request.jwt.claims', true)::json->>'email')
);

-- Allow public insert for system operations
CREATE POLICY "Enable public insert for users"
ON users
FOR INSERT
TO public
WITH CHECK (true);

-- Allow admin-only delete operations
CREATE POLICY "Enable delete for admin users"
ON users
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 
    FROM auth.users
    WHERE auth.users.id = auth.uid() 
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
);

-- Ensure all existing users have their roles synced to auth.users
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT * FROM users
  LOOP
    UPDATE auth.users
    SET raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      to_jsonb(user_record.role)
    )
    WHERE id = user_record.id;
  END LOOP;
END $$;