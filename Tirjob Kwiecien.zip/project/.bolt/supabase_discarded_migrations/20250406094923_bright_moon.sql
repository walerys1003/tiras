/*
  # Fix users table RLS policy for adding users

  1. Changes
    - Drop existing policies that are causing issues
    - Create new policies that allow admins to insert new users
    - Fix the policy recursion issue
    - Maintain existing security model

  2. Security
    - Maintain RLS protection
    - Allow admins to manage users
    - Prevent unauthorized access
*/

-- Drop existing policies to start fresh
DROP POLICY IF EXISTS "Allow admins to read all users" ON public.users;
DROP POLICY IF EXISTS "Allow users to read own data" ON public.users;
DROP POLICY IF EXISTS "Allow admins to update user roles" ON public.users;
DROP POLICY IF EXISTS "Allow users to update own data" ON public.users;
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new non-recursive policies
-- Allow public read access to users table (needed for auth checks)
CREATE POLICY "Enable read access for all users"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

-- Allow admins to insert new users
CREATE POLICY "Enable admin insert for users"
  ON public.users
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
    )
  );

-- Allow users to update their own data
CREATE POLICY "Enable update for users based on id"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
    )
  );

-- Allow admins to delete users
CREATE POLICY "Enable delete for admin users"
  ON public.users
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
    )
  );