/*
  # Fix RLS policies for users table

  1. Changes
    - Drop existing problematic policies
    - Create new policies that:
      - Allow public read access to users table
      - Allow users to update their own data
      - Allow admins to perform all operations
      - Prevent infinite recursion by using simpler policy definitions

  2. Security
    - Maintains RLS protection
    - Properly scopes user access
    - Prevents unauthorized access while allowing admin management
*/

-- Drop existing policies to clean up
DROP POLICY IF EXISTS "Enable full access for admins" ON users;
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on id" ON users;
DROP POLICY IF EXISTS "Enable admin insert for users" ON users;
DROP POLICY IF EXISTS "Enable delete for admin users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON users;

-- Create new policies that avoid recursion

-- Allow public read access to users table
CREATE POLICY "Enable read access for all users"
ON users
FOR SELECT
TO public
USING (true);

-- Allow users to update their own data
CREATE POLICY "Enable update for users based on email"
ON users
FOR UPDATE
TO public
USING (
  email = (current_setting('request.jwt.claims', true)::json->>'email')
);

-- Allow admins to insert new users
CREATE POLICY "Enable admin insert for users"
ON users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
  OR
  auth.uid() = id
);

-- Allow admins to delete users
CREATE POLICY "Enable delete for admin users"
ON users
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND (auth.users.raw_app_meta_data->>'role')::text = 'admin'
  )
);