/*
  # Fix admin authentication for krupakacp@gmail.com

  1. Changes
    - Update auth.users metadata to set admin role
    - Ensure email is confirmed
    - Update users table to match auth.users role
    - Add proper error handling

  2. Security
    - Maintain proper role-based access control
    - Ensure consistent role data between auth.users and users table
*/

-- Update auth.users metadata for krupakacp@gmail.com
DO $$
DECLARE
  user_id uuid;
BEGIN
  -- Get user ID from email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'krupakacp@gmail.com';
  
  IF user_id IS NULL THEN
    RAISE EXCEPTION 'User with email krupakacp@gmail.com not found';
  END IF;
  
  -- Update auth.users metadata with admin role
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      '"admin"'
    ),
    email_confirmed_at = COALESCE(email_confirmed_at, now())
  WHERE id = user_id;
  
  -- Update users table to match auth.users role
  UPDATE users
  SET 
    role = 'admin',
    updated_at = now()
  WHERE id = user_id;
  
  RAISE NOTICE 'Successfully updated user krupakacp@gmail.com to admin role';
END $$;