/*
  # Update SEO settings for job listings

  1. Changes
    - Update the page path for job listings from '/jobs' to '/oferty-pracy'
    - Add SEO settings for blog post detail pages
    - Add SEO settings for blog category pages
    - Ensure proper Polish language URL structure

  2. Security
    - Maintain existing RLS policies
*/

-- Update the page path for job listings if needed
UPDATE seo_settings
SET page_path = '/oferty-pracy'
WHERE page_path = '/jobs';

-- Insert SEO settings for blog post detail pages if they don't exist
INSERT INTO seo_settings (page_path, page_type, title, description, keywords, og_title, og_description, og_image, og_type, schema_org)
VALUES 
  ('/blog/:id', 'blog-post', 'Blog TirJob.pl - Artykuł',
   'Artykuł na blogu TirJob.pl - portal pracy dla kierowców i specjalistów transportu.',
   'blog transportowy, artykuł, porady dla kierowców, branża TSL',
   'Blog TirJob.pl - Artykuł',
   'Artykuł na blogu TirJob.pl - portal pracy dla kierowców i specjalistów transportu.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'article',
   '{
     "@context": "https://schema.org",
     "@type": "BlogPosting",
     "headline": "Artykuł na blogu TirJob.pl",
     "description": "Artykuł na blogu TirJob.pl",
     "publisher": {
       "@type": "Organization",
       "name": "TirJob.pl",
       "logo": {
         "@type": "ImageObject",
         "url": "https://tirjob.pl/logo.png"
       }
     }
   }'::jsonb)
ON CONFLICT (page_path) DO UPDATE SET
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  keywords = EXCLUDED.keywords,
  og_title = EXCLUDED.og_title,
  og_description = EXCLUDED.og_description,
  og_image = EXCLUDED.og_image,
  og_type = EXCLUDED.og_type,
  schema_org = EXCLUDED.schema_org;