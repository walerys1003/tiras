/*
  # Fix admin authentication and user roles

  1. Changes
    - Add trigger to sync auth.users role with users table
    - Add function to update user metadata
    - Ensure admin user exists with proper role
    - Fix RLS policies for users table

  2. Security
    - Enable RLS
    - Add proper policies for data access
    - Ensure role consistency between auth and users tables
*/

-- Create function to sync user role with auth metadata
CREATE OR REPLACE FUNCTION sync_user_role()
RETURNS TRIGGER AS $$
BEGIN
  -- Update auth.users metadata with the new role
  UPDATE auth.users
  SET raw_app_meta_data = jsonb_set(
    COALESCE(raw_app_meta_data, '{}'::jsonb),
    '{role}',
    to_jsonb(NEW.role)
  )
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role changes
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'sync_user_role_trigger'
  ) THEN
    CREATE TRIGGER sync_user_role_trigger
      AFTER UPDATE OF role ON users
      FOR EACH ROW
      EXECUTE FUNCTION sync_user_role();
  END IF;
END $$;

-- Create function to handle new auth users
CREATE OR REPLACE FUNCTION handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert into users table if not exists
  INSERT INTO public.users (id, email, name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_app_meta_data->>'role', 'user')
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new auth users
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION handle_new_auth_user();
  END IF;
END $$;

-- Ensure admin user exists in auth.users with proper role
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Check if admin user exists in auth.users
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';
  
  IF admin_user_id IS NULL THEN
    -- Admin user doesn't exist, create it
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@tirjob.pl',
      crypt('TirJob25!', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "admin"}',
      '{"name": "Administrator"}',
      now(),
      now()
    )
    RETURNING id INTO admin_user_id;
  ELSE
    -- Admin user exists, ensure it has admin role in metadata
    UPDATE auth.users
    SET raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      '"admin"'
    )
    WHERE id = admin_user_id;
  END IF;
  
  -- Ensure admin user exists in users table
  INSERT INTO users (id, email, name, role)
  VALUES (
    admin_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin'
  )
  ON CONFLICT (id) DO UPDATE
  SET role = 'admin';
END $$;