/*
  # Fix users table RLS policies

  1. Changes
    - Remove existing RLS policies on users table that may cause recursion
    - Add new, simplified RLS policies:
      - Allow admins to read all users
      - Allow users to read their own data
      - Allow admins to update user roles
      - Allow users to update their own data (except role)

  2. Security
    - Enable RLS on users table
    - Add policies for read and update operations
    - Prevent infinite recursion by using direct role checks
*/

-- First, drop existing policies that might cause recursion
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new, simplified policies
CREATE POLICY "Admins can read all users"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.jwt() ->> 'email' IN (
    SELECT email FROM public.users WHERE role = 'admin'
  )
);

CREATE POLICY "Users can read own data"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.jwt() ->> 'email' = email
);

CREATE POLICY "Admins can update users"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.jwt() ->> 'email' IN (
    SELECT email FROM public.users WHERE role = 'admin'
  )
)
WITH CHECK (
  auth.jwt() ->> 'email' IN (
    SELECT email FROM public.users WHERE role = 'admin'
  )
);

CREATE POLICY "Users can update own data except role"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.jwt() ->> 'email' = email
)
WITH CHECK (
  auth.jwt() ->> 'email' = email
  AND (role IS NOT DISTINCT FROM OLD.role) -- Prevent role changes
);