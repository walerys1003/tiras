/*
  # Fix authentication and RLS issues

  1. Changes
    - Drop existing policies that are causing issues
    - Create new simplified policies for users table
    - Ensure admin user exists in both auth.users and users tables
    - Fix RLS policies to allow proper access

  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Ensure admin user has proper role
*/

-- Drop existing policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Users can read own data" ON public.users;
  DROP POLICY IF EXISTS "Admin users can create users" ON public.users;
  DROP POLICY IF EXISTS "Users can update own data" ON public.users;
  DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
  DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;
  DROP POLICY IF EXISTS "Authenticated users can insert users" ON public.users;
  DROP POLICY IF EXISTS "Anyone can view users" ON public.users;
  DROP POLICY IF EXISTS "Users can update their own data" ON public.users;
  DROP POLICY IF EXISTS "System can insert users" ON public.users;
  DROP POLICY IF EXISTS "Admin users can update any user" ON public.users;
  DROP POLICY IF EXISTS "Admin users can delete users" ON public.users;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new simplified policies
-- Allow public read access to users table (needed for auth checks)
CREATE POLICY "Public read access for users"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

-- Allow insert for authenticated users (needed for registration)
CREATE POLICY "Authenticated users can insert users"
  ON public.users
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Allow insert for public users (needed for trigger functions)
CREATE POLICY "Public users can insert users"
  ON public.users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow update for authenticated users (own data or admin)
CREATE POLICY "Authenticated users can update users"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id OR 
    EXISTS (
      SELECT 1 FROM users
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Ensure admin user exists in auth.users with proper role
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Check if admin user exists in auth.users
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';
  
  IF admin_user_id IS NULL THEN
    -- Admin user doesn't exist, create it
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@tirjob.pl',
      crypt('admin123', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "admin"}',
      '{"name": "Administrator"}',
      now(),
      now()
    )
    RETURNING id INTO admin_user_id;
  ELSE
    -- Admin user exists, ensure it has admin role in metadata
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        '"admin"'
      ),
      email_confirmed_at = now()
    WHERE id = admin_user_id;
  END IF;
  
  -- Ensure admin user exists in users table
  INSERT INTO users (id, email, name, role)
  VALUES (
    admin_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin'
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    role = 'admin',
    name = 'Administrator';
    
  -- Also try by email as a fallback
  IF NOT FOUND THEN
    INSERT INTO users (id, email, name, role)
    VALUES (
      admin_user_id,
      'admin@tirjob.pl',
      'Administrator',
      'admin'
    )
    ON CONFLICT (email) DO UPDATE
    SET 
      id = admin_user_id,
      role = 'admin',
      name = 'Administrator';
  END IF;
END $$;