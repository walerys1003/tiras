/*
  # Fix infinite recursion in users table RLS policies

  1. Changes
    - Drop existing policies that cause recursion
    - Create new simplified policies that avoid querying the users table
    - Use auth.jwt() directly to check roles
    - Add proper policies for admin access

  2. Security
    - Enable RLS
    - Add policies for authenticated users
    - Prevent infinite recursion
*/

-- Drop existing policies to recreate them
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;
DROP POLICY IF EXISTS "Admins can read all users" ON public.users;
DROP POLICY IF EXISTS "Admins can update all users" ON public.users;
DROP POLICY IF EXISTS "Only admins can delete users" ON public.users;

-- Create new policies that avoid recursion by using auth.jwt() directly
-- Allow authenticated users to read their own data
CREATE POLICY "Authenticated users can read own data" ON public.users
FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Allow authenticated users to update their own data
CREATE POLICY "Authenticated users can update own data"
ON public.users
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Allow authenticated users with admin role to read all user data
CREATE POLICY "Admins can read all users" ON public.users
FOR SELECT
TO authenticated
USING (
  (auth.jwt()->>'role')::text = 'admin' OR
  (auth.jwt()->'app_metadata'->>'role')::text = 'admin'
);

-- Allow authenticated users with admin role to update all users
CREATE POLICY "Admins can update all users" ON public.users
FOR UPDATE
TO authenticated
USING (
  (auth.jwt()->>'role')::text = 'admin' OR
  (auth.jwt()->'app_metadata'->>'role')::text = 'admin'
)
WITH CHECK (
  (auth.jwt()->>'role')::text = 'admin' OR
  (auth.jwt()->'app_metadata'->>'role')::text = 'admin'
);

-- Allow authenticated users with admin role to delete users
CREATE POLICY "Admins can delete users" ON public.users
FOR DELETE
TO authenticated
USING (
  (auth.jwt()->>'role')::text = 'admin' OR
  (auth.jwt()->'app_metadata'->>'role')::text = 'admin'
);

-- Add index to improve policy performance
CREATE INDEX IF NOT EXISTS idx_users_id ON public.users(id);