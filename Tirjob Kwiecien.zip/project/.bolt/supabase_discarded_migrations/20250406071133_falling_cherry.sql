/*
  # Add user roles and update users table

  1. Changes
    - Update users table with role column
    - Add check constraint for valid roles
    - Add RLS policies for user management
    - Add trigger for updating updated_at

  2. Security
    - Enable RLS
    - Add policies for user access
    - Ensure proper role validation
*/

-- Check if users table exists and create it if not
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT users_role_check CHECK (role = ANY (ARRAY['admin', 'redaktor', 'moderator', 'user']))
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Enable read access for all users" ON users;
  DROP POLICY IF EXISTS "Enable update for users based on email" ON users;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable update for users based on email"
  ON users
  FOR UPDATE
  TO public
  USING (
    email = (current_setting('request.jwt.claims', true)::json->>'email')
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Create function to handle user updates
CREATE OR REPLACE FUNCTION handle_user_update()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for updating updated_at
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_user_updated'
  ) THEN
    CREATE TRIGGER on_user_updated
      BEFORE UPDATE ON users
      FOR EACH ROW
      EXECUTE FUNCTION handle_user_update();
  END IF;
END $$;