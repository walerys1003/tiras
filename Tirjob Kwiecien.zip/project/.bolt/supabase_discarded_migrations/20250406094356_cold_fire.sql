/*
  # Fix RLS recursion in users table

  1. Changes
    - Drop existing policies that cause recursion
    - Create simplified policies that avoid self-reference
    - Add public policy for read access
    - Add separate policies for admin and regular users

  2. Security
    - Enable RLS
    - Add proper policies for data access
    - Prevent infinite recursion
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can read all users" ON public.users;
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Admins can update users" ON public.users;
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;

-- Create new non-recursive policies
-- Allow public read access to all users
CREATE POLICY "Enable read access for all users"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

-- Allow update for users based on email
CREATE POLICY "Enable update for users based on email"
  ON public.users
  FOR UPDATE
  TO public
  USING (
    email = ((current_setting('request.jwt.claims'::text, true))::json ->> 'email'::text)
  );