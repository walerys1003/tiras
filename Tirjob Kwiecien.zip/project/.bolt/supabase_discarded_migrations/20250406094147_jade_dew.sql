/*
  # Fix users table RLS policies

  1. Changes
    - Remove recursive policies that cause infinite loops
    - Add proper RLS policies for users table:
      - Allow admins to read all users
      - Allow users to read their own data
      - Allow admins to update user roles
      - Allow users to update their own profile

  2. Security
    - Enable RLS on users table
    - Add policies for SELECT and UPDATE operations
    - Ensure proper access control based on user roles and ownership
*/

-- Drop existing policies that might be causing recursion
DROP POLICY IF EXISTS "Enable read access for all users" ON public.users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON public.users;

-- Create new, non-recursive policies
CREATE POLICY "Admins can read all users"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.jwt() ->> 'role' = 'admin'
);

CREATE POLICY "Users can read own data"
ON public.users
FOR SELECT
TO authenticated
USING (
  auth.uid() = id
);

CREATE POLICY "Admins can update users"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.jwt() ->> 'role' = 'admin'
)
WITH CHECK (
  auth.jwt() ->> 'role' = 'admin'
);

CREATE POLICY "Users can update own profile"
ON public.users
FOR UPDATE
TO authenticated
USING (
  auth.uid() = id
)
WITH CHECK (
  auth.uid() = id AND
  -- Prevent users from changing their own role
  (role IS NOT DISTINCT FROM OLD.role)
);