/*
  # Add storage bucket for job applications

  1. Storage
    - Create a new storage bucket called 'job-applications' for storing CV files
    - Enable public access for the bucket
    - Set up security policies for uploads and downloads

  2. Security
    - Allow public uploads to the bucket
    - Allow public access to CV files
    - Restrict file types to PDF, DOC, DOCX
    - Set max file size to 5MB
*/

-- Enable storage by creating the bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('job-applications', 'job-applications', true);

-- Allow public uploads to the bucket
CREATE POLICY "Allow public uploads to job-applications"
ON storage.objects
FOR INSERT
TO public
WITH CHECK (
  bucket_id = 'job-applications' AND
  octet_length(content) <= 5242880 AND -- 5MB max file size
  (
    lower(storage.extension(name)) = 'pdf' OR
    lower(storage.extension(name)) = 'doc' OR
    lower(storage.extension(name)) = 'docx'
  )
);

-- Allow public access to CV files
CREATE POLICY "Allow public access to job-applications"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'job-applications');