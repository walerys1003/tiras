/*
  # Add cascade delete trigger for users table

  1. Changes
    - Add trigger to handle cascade deletion of users
    - Add function to handle the cascade deletion

  2. Security
    - No changes to RLS policies
*/

-- Create function to handle user deletion
CREATE OR REPLACE FUNCTION handle_user_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete from auth.users if the user exists
  DELETE FROM auth.users WHERE id = OLD.id;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to handle user deletion
CREATE TRIGGER on_user_delete
  AFTER DELETE ON public.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_delete();