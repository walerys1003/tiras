/*
  # Fix blog posts RLS policies

  1. Changes
    - Drop existing policies for blog_posts and blog_categories
    - Create new policies that allow admin and redaktor roles to manage blog posts
    - Use proper JWT role check syntax
    - Ensure public users can view published blog posts

  2. Security
    - Enable RLS
    - Add policies for proper access control
    - Ensure data integrity
*/

-- Drop existing policies for blog_posts
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can view published blog posts" ON blog_posts;
  DROP POLICY IF EXISTS "Admin users can manage blog posts" ON blog_posts;
  DROP POLICY IF EXISTS "Admin and redaktor can manage blog posts" ON blog_posts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Drop existing policies for blog_categories
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can view blog categories" ON blog_categories;
  DROP POLICY IF EXISTS "Admin users can manage blog categories" ON blog_categories;
  DROP POLICY IF EXISTS "Admin and redaktor can manage blog categories" ON blog_categories;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies for blog_posts

-- 1. Allow anyone to view published blog posts
CREATE POLICY "Anyone can view published blog posts"
  ON blog_posts
  FOR SELECT
  TO public
  USING (status = 'published');

-- 2. Allow admin and redaktor to manage blog posts
CREATE POLICY "Admin and redaktor can manage blog posts"
  ON blog_posts
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role') IN ('admin', 'redaktor')
  )
  WITH CHECK (
    (auth.jwt() ->> 'role') IN ('admin', 'redaktor')
  );

-- Create new policies for blog_categories

-- 1. Allow anyone to view blog categories
CREATE POLICY "Anyone can view blog categories"
  ON blog_categories
  FOR SELECT
  TO public
  USING (true);

-- 2. Allow admin and redaktor to manage blog categories
CREATE POLICY "Admin and redaktor can manage blog categories"
  ON blog_categories
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role') IN ('admin', 'redaktor')
  )
  WITH CHECK (
    (auth.jwt() ->> 'role') IN ('admin', 'redaktor')
  );