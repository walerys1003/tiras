/*
  # Add job views tracking table

  1. New Tables
    - `job_views` - Tracks views of job posts
      - `id` (uuid, primary key)
      - `job_post_id` (uuid, foreign key)
      - `viewed_at` (timestamptz)
      - `viewer_ip` (text)
      - `session_id` (text)
      - `user_agent` (text)

  2. Security
    - Enable RLS
    - Add policies for public access
    - Ensure proper data tracking
*/

-- Create job_views table
CREATE TABLE job_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_post_id uuid REFERENCES job_posts(id) ON DELETE CASCADE,
  viewed_at timestamptz DEFAULT now(),
  viewer_ip text,
  session_id text,
  user_agent text
);

-- Enable RLS
ALTER TABLE job_views ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_job_views_job_post_id ON job_views(job_post_id);
CREATE INDEX idx_job_views_viewed_at ON job_views(viewed_at);
CREATE INDEX idx_job_views_session_id ON job_views(session_id);

-- Create policies
CREATE POLICY "Anyone can insert job views"
  ON job_views
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Admin users can view job views"
  ON job_views
  FOR SELECT
  TO authenticated
  USING (
    ((current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin') OR
    ((current_setting('request.jwt.claims', true)::json ->> 'role') = 'moderator')
  );

-- Create function to record a job view
CREATE OR REPLACE FUNCTION record_job_view(
  job_id UUID,
  ip TEXT DEFAULT NULL,
  session TEXT DEFAULT NULL,
  agent TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert the view record
  INSERT INTO job_views (
    job_post_id,
    viewer_ip,
    session_id,
    user_agent
  )
  VALUES (
    job_id,
    ip,
    session,
    agent
  );
  
  RETURN true;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Error recording job view: %', SQLERRM;
  RETURN false;
END;
$$;

-- Add analytics functions

-- Function to get job views count
CREATE OR REPLACE FUNCTION get_job_views_count(
  job_id UUID,
  start_date TIMESTAMPTZ DEFAULT NULL,
  end_date TIMESTAMPTZ DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  view_count INTEGER;
BEGIN
  IF start_date IS NULL AND end_date IS NULL THEN
    -- Count all views
    SELECT COUNT(*) INTO view_count
    FROM job_views
    WHERE job_post_id = job_id;
  ELSIF start_date IS NULL THEN
    -- Count views up to end_date
    SELECT COUNT(*) INTO view_count
    FROM job_views
    WHERE job_post_id = job_id
    AND viewed_at <= end_date;
  ELSIF end_date IS NULL THEN
    -- Count views from start_date
    SELECT COUNT(*) INTO view_count
    FROM job_views
    WHERE job_post_id = job_id
    AND viewed_at >= start_date;
  ELSE
    -- Count views in date range
    SELECT COUNT(*) INTO view_count
    FROM job_views
    WHERE job_post_id = job_id
    AND viewed_at BETWEEN start_date AND end_date;
  END IF;
  
  RETURN view_count;
END;
$$;

-- Function to get job applications count
CREATE OR REPLACE FUNCTION get_job_applications_count(
  job_id UUID,
  start_date TIMESTAMPTZ DEFAULT NULL,
  end_date TIMESTAMPTZ DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  app_count INTEGER;
BEGIN
  IF start_date IS NULL AND end_date IS NULL THEN
    -- Count all applications
    SELECT COUNT(*) INTO app_count
    FROM job_applications
    WHERE job_post_id = job_id;
  ELSIF start_date IS NULL THEN
    -- Count applications up to end_date
    SELECT COUNT(*) INTO app_count
    FROM job_applications
    WHERE job_post_id = job_id
    AND created_at <= end_date;
  ELSIF end_date IS NULL THEN
    -- Count applications from start_date
    SELECT COUNT(*) INTO app_count
    FROM job_applications
    WHERE job_post_id = job_id
    AND created_at >= start_date;
  ELSE
    -- Count applications in date range
    SELECT COUNT(*) INTO app_count
    FROM job_applications
    WHERE job_post_id = job_id
    AND created_at BETWEEN start_date AND end_date;
  END IF;
  
  RETURN app_count;
END;
$$;

-- Function to get job conversion rate
CREATE OR REPLACE FUNCTION get_job_conversion_rate(
  job_id UUID,
  start_date TIMESTAMPTZ DEFAULT NULL,
  end_date TIMESTAMPTZ DEFAULT NULL
)
RETURNS NUMERIC
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  view_count INTEGER;
  app_count INTEGER;
  conversion_rate NUMERIC;
BEGIN
  -- Get view count
  SELECT get_job_views_count(job_id, start_date, end_date) INTO view_count;
  
  -- Get application count
  SELECT get_job_applications_count(job_id, start_date, end_date) INTO app_count;
  
  -- Calculate conversion rate
  IF view_count > 0 THEN
    conversion_rate := (app_count::NUMERIC / view_count::NUMERIC) * 100;
  ELSE
    conversion_rate := 0;
  END IF;
  
  RETURN conversion_rate;
END;
$$;