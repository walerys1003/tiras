/*
  # Remove default SEO settings from admin_settings table

  1. Changes
    - Remove default SEO settings from admin_settings table
    - These settings are redundant since we have dedicated SEO settings per page
    - Keep other settings like contact, social media, and recruitment intact

  2. Security
    - Maintain existing RLS policies
*/

-- Delete default SEO settings from admin_settings table
DELETE FROM admin_settings
WHERE setting_group = 'seo'
AND key IN ('default_title', 'default_description', 'default_keywords');

-- Update App.tsx to use page-specific SEO settings instead of defaults
-- This is handled in the frontend code