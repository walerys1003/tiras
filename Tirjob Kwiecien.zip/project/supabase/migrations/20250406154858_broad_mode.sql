/*
  # Fix user changes not saving

  1. Changes
    - Update the sync_user_role_to_auth function to properly update auth.users
    - Add a trigger to update user_metadata when name changes
    - Ensure proper synchronization between users table and auth.users
    - Fix RLS policies to allow proper updates

  2. Security
    - Maintain existing security model
    - Ensure proper role-based access
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

-- Drop existing function
DROP FUNCTION IF EXISTS sync_user_role_to_auth();

-- Create improved function to sync user role and name to auth metadata
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
BEGIN
  -- Update auth.users metadata with the new role and name
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role)
    ),
    raw_user_meta_data = jsonb_set(
      COALESCE(raw_user_meta_data, '{}'::jsonb),
      '{name}',
      to_jsonb(NEW.name)
    )
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role and name changes
CREATE TRIGGER sync_user_role_trigger
  AFTER UPDATE OF role, name ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Drop existing policies
DROP POLICY IF EXISTS "Enable update for users based on email" ON users;
DROP POLICY IF EXISTS "Users can update their own data" ON users;
DROP POLICY IF EXISTS "Admin users can manage all users" ON users;

-- Create improved policies
CREATE POLICY "Admin users can manage all users"
  ON users
  FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin'
  );

CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id
  );

-- Ensure all existing users have proper metadata
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT * FROM users
  LOOP
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        to_jsonb(user_record.role)
      ),
      raw_user_meta_data = jsonb_set(
        COALESCE(raw_user_meta_data, '{}'::jsonb),
        '{name}',
        to_jsonb(user_record.name)
      )
    WHERE id = user_record.id;
  END LOOP;
END $$;