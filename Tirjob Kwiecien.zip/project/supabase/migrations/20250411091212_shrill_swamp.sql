/*
  # Fix RLS policies for job_posts table

  1. Changes
    - Simplify RLS policies for job_posts table
    - Remove all complex conditions from the INSERT policy
    - Ensure unauthenticated users can create job posts
    - Fix related tables' policies to allow proper job creation flow

  2. Security
    - Maintain view restrictions for active jobs only
    - Allow proper update restrictions via trigger function
    - Ensure admin/moderator users can manage all job posts
*/

-- Drop existing policies for job_posts
DROP POLICY IF EXISTS "Job posts are viewable by everyone" ON job_posts;
DROP POLICY IF EXISTS "Job posts are insertable by anyone" ON job_posts;
DROP POLICY IF EXISTS "Job posts are updatable by company email" ON job_posts;
DROP POLICY IF EXISTS "Admin users can manage job posts" ON job_posts;
DROP POLICY IF EXISTS "Public users can update payment status" ON job_posts;

-- Create simplified policies for job_posts

-- 1. Allow anyone to view active job posts
CREATE POLICY "Job posts are viewable by everyone"
  ON job_posts
  FOR SELECT
  TO public
  USING ((status = 'active') AND (expires_at > now()));

-- 2. Allow anyone to insert job posts with NO CONDITIONS
-- This is the key fix - removing all conditions from the INSERT policy
CREATE POLICY "Job posts are insertable by anyone"
  ON job_posts
  FOR INSERT
  TO public
  WITH CHECK (true);

-- 3. Allow company owners to update their own job posts
CREATE POLICY "Job posts are updatable by company email"
  ON job_posts
  FOR UPDATE
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = current_setting('request.jwt.claims', true)::json->>'email'
    )
  );

-- 4. Allow admin/moderator users to manage all job posts
CREATE POLICY "Admin users can manage job posts"
  ON job_posts
  FOR ALL
  TO authenticated
  USING (
    ((current_setting('request.jwt.claims', true)::json->>'role') = 'admin') OR
    ((current_setting('request.jwt.claims', true)::json->>'role') = 'moderator')
  );

-- Ensure all related tables have proper policies

-- Companies table
DROP POLICY IF EXISTS "Companies are insertable by anyone" ON companies;
CREATE POLICY "Companies are insertable by anyone"
  ON companies
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job requirements table
DROP POLICY IF EXISTS "Job requirements are insertable by anyone" ON job_requirements;
CREATE POLICY "Job requirements are insertable by anyone"
  ON job_requirements
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job duties table
DROP POLICY IF EXISTS "Job duties are insertable by anyone" ON job_duties;
CREATE POLICY "Job duties are insertable by anyone"
  ON job_duties
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job benefits table
DROP POLICY IF EXISTS "Job benefits are insertable by anyone" ON job_benefits;
CREATE POLICY "Job benefits are insertable by anyone"
  ON job_benefits
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job languages table
DROP POLICY IF EXISTS "Job languages are insertable by anyone" ON job_languages;
CREATE POLICY "Job languages are insertable by anyone"
  ON job_languages
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job qualifications table
DROP POLICY IF EXISTS "Job qualifications are insertable by anyone" ON job_qualifications;
CREATE POLICY "Job qualifications are insertable by anyone"
  ON job_qualifications
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job cities table
DROP POLICY IF EXISTS "Anyone can insert cities" ON job_cities;
CREATE POLICY "Anyone can insert cities"
  ON job_cities
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Payments table
DROP POLICY IF EXISTS "Anyone can insert payments" ON payments;
CREATE POLICY "Anyone can insert payments"
  ON payments
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Ensure job_countries has proper policies
DROP POLICY IF EXISTS "Anyone can view countries" ON job_countries;
CREATE POLICY "Anyone can view countries"
  ON job_countries
  FOR SELECT
  TO public
  USING (true);

-- Ensure job_voivodeships has proper policies
DROP POLICY IF EXISTS "Anyone can view voivodeships" ON job_voivodeships;
CREATE POLICY "Anyone can view voivodeships"
  ON job_voivodeships
  FOR SELECT
  TO public
  USING (true);