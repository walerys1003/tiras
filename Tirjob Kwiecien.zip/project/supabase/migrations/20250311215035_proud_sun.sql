/*
  # Fix authentication setup

  1. Changes
    - Drop and recreate users table with password_hash
    - Create auth user with correct configuration
    - Set up proper RLS policies
    - Add indexes for performance

  2. Security
    - Store hashed passwords
    - Enable RLS
    - Set up proper access policies
*/

-- Drop existing table if exists
DROP TABLE IF EXISTS users CASCADE;

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL DEFAULT 'user',
  password_hash text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT users_role_check CHECK (role = ANY (ARRAY['admin', 'user']))
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Create auth user and link to users table
DO $$
DECLARE
  auth_user_id uuid;
BEGIN
  -- Delete existing auth user if exists
  DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';
  
  -- Insert into auth.users
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    created_at,
    updated_at
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@tirjob.pl',
    crypt('Tirjob25!', gen_salt('bf')),
    '{"provider": "email", "providers": ["email"]}',
    '{}',
    false,
    now(),
    now()
  )
  RETURNING id INTO auth_user_id;

  -- Insert into users table with the same id
  INSERT INTO users (id, email, name, role, password_hash)
  VALUES (
    auth_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin',
    crypt('Tirjob25!', gen_salt('bf'))
  );
END $$;