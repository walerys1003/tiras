/*
  # Add SEO fields to blog_posts table

  1. New Columns
    - `seo_title` (text) - Custom SEO title for the blog post
    - `seo_description` (text) - Custom SEO description for the blog post
    - `seo_keywords` (text) - Custom SEO keywords for the blog post
    - `seo_image` (text) - Custom image URL for social media sharing

  2. Changes
    - Add new columns to blog_posts table
    - Set default values to NULL to make them optional
    - These fields will be used for custom SEO settings per blog post
*/

-- Add SEO fields to blog_posts table
ALTER TABLE blog_posts 
ADD COLUMN IF NOT EXISTS seo_title text,
ADD COLUMN IF NOT EXISTS seo_description text,
ADD COLUMN IF NOT EXISTS seo_keywords text,
ADD COLUMN IF NOT EXISTS seo_image text;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_blog_posts_seo_title ON blog_posts(seo_title);