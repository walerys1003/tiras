/*
  # Fix admin authentication

  1. Changes
    - Delete existing admin user
    - Create new admin user with proper app_metadata
    - Set email_confirmed_at to ensure immediate access
    - Remove trigger that was causing the error

  2. Security
    - Store role in app_metadata
    - Ensure proper password hashing
    - Enable immediate access
*/

-- Drop existing trigger if exists
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Delete existing admin user if exists
DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';

-- Create admin user with proper metadata
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  confirmation_token,
  recovery_token,
  email_change_token_new,
  email_change,
  created_at,
  updated_at,
  last_sign_in_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  is_sso_user,
  phone,
  phone_confirmed_at,
  phone_change,
  phone_change_token,
  email_change_token_current,
  email_change_confirm_status,
  banned_until,
  reauthentication_token,
  reauthentication_sent_at,
  is_anonymous
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@tirjob.pl',
  crypt('TirJob25!', gen_salt('bf')),
  now(),
  '',
  '',
  '',
  '',
  now(),
  now(),
  now(),
  '{"provider": "email", "providers": ["email"], "role": "admin"}',
  '{"name": "Administrator"}',
  false,
  false,
  null,
  null,
  '',
  '',
  '',
  0,
  null,
  '',
  null,
  false
);