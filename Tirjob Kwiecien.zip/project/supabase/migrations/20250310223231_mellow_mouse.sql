/*
  # Add job applications table and policies

  1. New Tables
    - `job_applications`
      - `id` (uuid, primary key)
      - `job_post_id` (uuid, foreign key)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `message` (text)
      - `cv_url` (text)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `job_applications` table
    - Add policy for public insertion of applications
    - Add policy for viewing applications by job owners
*/

-- Create job applications table
CREATE TABLE IF NOT EXISTS job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_post_id uuid REFERENCES job_posts(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  message text,
  cv_url text,
  status text DEFAULT 'new',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Create policy for inserting applications (anyone can apply)
CREATE POLICY "public_insert_applications"
  ON job_applications
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policy for viewing applications (only job owners can view)
CREATE POLICY "owners_view_applications"
  ON job_applications
  FOR SELECT
  TO authenticated
  USING (
    job_post_id IN (
      SELECT id FROM job_posts
      WHERE company_id = auth.uid()
    )
  );

-- Add trigger for updating updated_at if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_job_applications_updated_at'
  ) THEN
    CREATE TRIGGER update_job_applications_updated_at
      BEFORE UPDATE ON job_applications
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;