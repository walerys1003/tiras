/*
  # Create admin user in auth.users

  1. Changes
    - Drop users table
    - Create admin user in auth.users with proper metadata
    - Add role and name in metadata
    - Handle existing user properly

  2. Security
    - Store role in app_metadata
    - Store name in user_metadata
*/

-- Drop users table and related objects
DROP TABLE IF EXISTS users CASCADE;

-- Update admin user in auth.users with role in metadata
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Delete existing admin user if exists
  DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';
  
  -- Create new admin user
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    created_at,
    updated_at
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@tirjob.pl',
    crypt('Tirjob25!', gen_salt('bf')),
    now(),
    jsonb_build_object(
      'provider', 'email',
      'providers', array['email'],
      'role', 'admin'
    ),
    jsonb_build_object(
      'name', 'Administrator'
    ),
    false,
    now(),
    now()
  );
END $$;