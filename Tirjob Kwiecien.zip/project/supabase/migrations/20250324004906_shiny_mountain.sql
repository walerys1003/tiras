/*
  # Fix blog posts and add featured flag

  1. Changes
    - Check if is_featured column exists before adding
    - Update featured posts
    - Add missing content and metadata

  2. Security
    - Maintain existing RLS policies
*/

DO $$ 
BEGIN
  -- Check if is_featured column exists
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'blog_posts' 
    AND column_name = 'is_featured'
  ) THEN
    -- Add is_featured column
    ALTER TABLE blog_posts 
    ADD COLUMN is_featured boolean NOT NULL DEFAULT false;

    -- Create index for is_featured column
    CREATE INDEX idx_blog_posts_is_featured ON blog_posts(is_featured);
  END IF;
END $$;

-- Update featured posts
UPDATE blog_posts
SET is_featured = true
WHERE slug IN (
  'jak-zostac-kierowca-miedzynarodowym-2025',
  'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025',
  'jak-skutecznie-rekrutowac-kierowcow-2025',
  'sztuczna-inteligencja-w-transporcie'
);

-- Add views column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'blog_posts' 
    AND column_name = 'views'
  ) THEN
    ALTER TABLE blog_posts 
    ADD COLUMN views integer NOT NULL DEFAULT 0;

    CREATE INDEX idx_blog_posts_views ON blog_posts(views);
  END IF;
END $$;

-- Update views for some posts to create "popular" posts
UPDATE blog_posts
SET views = CASE 
  WHEN slug = 'jak-zostac-kierowca-miedzynarodowym-2025' THEN 1245
  WHEN slug = 'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025' THEN 3489
  WHEN slug = 'jak-skutecznie-rekrutowac-kierowcow-2025' THEN 2150
  WHEN slug = 'sztuczna-inteligencja-w-transporcie' THEN 5680
  WHEN slug = 'eco-driving-w-praktyce' THEN 3120
  WHEN slug = 'targi-pracy-tsl-2025' THEN 2890
  ELSE floor(random() * 2000 + 500)
END
WHERE views = 0;