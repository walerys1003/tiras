/*
  # Fix job_cities RLS policy

  1. Changes
    - Add policy to allow insertion of new cities by anyone
    - This fixes the error when trying to add a new city during job posting
    - Maintains existing security model while allowing necessary operations

  2. Security
    - Maintains read-only access for existing cities
    - Allows creation of new cities when needed
    - Ensures proper data integrity
*/

-- Create policy to allow insertion of new cities
CREATE POLICY "Anyone can insert cities"
  ON job_cities
  FOR INSERT
  TO public
  WITH CHECK (true);