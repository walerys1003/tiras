/*
  # Add password column to users table

  1. Changes
    - Add password column to users table
    - Update existing admin user with hashed password
    - Keep existing structure and policies
*/

-- Add password column to users table
ALTER TABLE users
ADD COLUMN IF NOT EXISTS password_hash text NOT NULL DEFAULT '';

-- Update admin user's password
UPDATE users 
SET password_hash = crypt('Tirjob25!', gen_salt('bf'))
WHERE email = 'admin@tirjob.pl';