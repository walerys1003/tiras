/*
  # Add payments table and update job posts

  1. New Tables
    - `payments`
      - `id` (uuid, primary key)
      - `job_post_id` (uuid, foreign key)
      - `amount` (numeric)
      - `currency` (text)
      - `status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Changes
    - Add status column to job_posts
    - Add payment_status column to job_posts
    - Add RLS policies for payments

  3. Security
    - Enable RLS
    - Add policies for payment access
*/

-- Create payments table
CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_post_id uuid REFERENCES job_posts(id) ON DELETE CASCADE,
  amount numeric NOT NULL,
  currency text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT payments_status_check CHECK (status = ANY (ARRAY['pending', 'completed', 'failed']))
);

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON payments
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert for all users"
  ON payments
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_payments_job_post_id ON payments(job_post_id);
CREATE INDEX idx_payments_status ON payments(status);

-- Add payment_status to job_posts
ALTER TABLE job_posts 
ADD COLUMN payment_status text NOT NULL DEFAULT 'pending'
CHECK (payment_status = ANY (ARRAY['pending', 'completed', 'failed']));

-- Create index for payment_status
CREATE INDEX idx_job_posts_payment_status ON job_posts(payment_status);