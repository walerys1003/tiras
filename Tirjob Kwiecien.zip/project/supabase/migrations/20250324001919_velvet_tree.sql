-- First ensure categories exist
INSERT INTO blog_categories (title, slug, description)
VALUES 
  ('Porady dla kandydatów', 'porady-dla-kandydatow', 'Wskazówki i porady dla kierowców i specjalistów transportu'),
  ('Porady dla pracodawców', 'porady-dla-pracodawcow', 'Informacje dla firm transportowych i spedycyjnych'),
  ('Trendy w branży transportowej', 'trendy-w-branzy', 'Najnowsze trendy i zmiany w branży transportowej'),
  ('Wydarzenia i szkolenia', 'wydarzenia-i-szkolenia', 'Informacje o wydarzeniach i szkoleniach branżowych'),
  ('Edukacja i rozwój zawodowy', 'edukacja-i-rozwoj', 'Materiały edukacyjne i porady rozwojowe'),
  ('Innowacje i przyszłość transportu', 'innowacje', 'Nowe technologie i rozwiązania w transporcie')
ON CONFLICT (slug) DO UPDATE 
SET 
  title = EXCLUDED.title,
  description = EXCLUDED.description;

-- Then insert blog posts
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Jak zostać kierowcą międzynarodowym? Kompletny przewodnik 2025',
  'jak-zostac-kierowca-miedzynarodowym-2025',
  '# Jak zostać kierowcą międzynarodowym - przewodnik 2025

## Wymagane kwalifikacje

1. Prawo jazdy kategorii C+E
2. Kwalifikacja wstępna
3. Karta kierowcy
4. Aktualne badania lekarskie i psychologiczne
5. Znajomość języków obcych (minimum podstawy)

## Krok po kroku

### 1. Zdobycie prawa jazdy
- Kategoria B (min. 3 lata)
- Kategoria C
- Kategoria C+E

### 2. Kwalifikacja wstępna
- 280 godzin zajęć
- Teoria i praktyka
- Egzamin państwowy

### 3. Zdobycie doświadczenia
- Start od transportu krajowego
- Poznanie specyfiki pracy
- Budowanie reputacji

### 4. Rozwój kompetencji
- Kursy językowe
- Szkolenia z czasu pracy
- Obsługa tachografu

## Perspektywy zawodowe

- Atrakcyjne wynagrodzenie
- Możliwość poznawania świata
- Stabilne zatrudnienie
- Rozwój kariery

## Wyzwania

- Długie okresy poza domem
- Stres i zmęczenie
- Odpowiedzialność za ładunek
- Przepisy i kontrole

## Podsumowanie

Zawód kierowcy międzynarodowego to odpowiedzialna i wymagająca praca, ale oferująca atrakcyjne warunki i możliwości rozwoju.',
  'Kompleksowy przewodnik dla osób zainteresowanych karierą kierowcy w transporcie międzynarodowym - od wymagań po pierwsze kroki w zawodzie.',
  (SELECT id FROM blog_categories WHERE slug = 'edukacja-i-rozwoj'),
  'published',
  NOW() - INTERVAL '2 days'
WHERE NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'jak-zostac-kierowca-miedzynarodowym-2025'
);

-- Add more blog posts here...