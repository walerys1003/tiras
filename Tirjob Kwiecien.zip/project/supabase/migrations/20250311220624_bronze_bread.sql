/*
  # Remove admin user

  1. Changes
    - Delete admin@tirjob.pl user from auth.users table
    - Delete admin@tirjob.pl user from users table
*/

-- Delete from auth.users
DELETE FROM auth.users 
WHERE email = 'admin@tirjob.pl';

-- Delete from users
DELETE FROM users 
WHERE email = 'admin@tirjob.pl';