/*
  # Create function to update user role in auth metadata

  1. Changes
    - Create a database function to update user role in auth metadata
    - This function will be called by the trigger on users table
    - Ensures role is synchronized between users table and auth.users

  2. Security
    - Function runs with SECURITY DEFINER to have necessary permissions
    - Only updates role in auth metadata
*/

-- Create or replace function to sync user role to auth metadata
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
BEGIN
  -- Update auth.users metadata with the new role
  UPDATE auth.users
  SET raw_app_meta_data = jsonb_set(
    COALESCE(raw_app_meta_data, '{}'::jsonb),
    '{role}',
    to_jsonb(NEW.role)
  )
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role changes if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'sync_user_role_trigger'
  ) THEN
    CREATE TRIGGER sync_user_role_trigger
      AFTER INSERT OR UPDATE OF role ON users
      FOR EACH ROW
      EXECUTE FUNCTION sync_user_role_to_auth();
  END IF;
END $$;