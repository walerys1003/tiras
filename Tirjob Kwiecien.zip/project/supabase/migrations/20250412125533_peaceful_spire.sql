/*
  # Fix Stripe payment currency

  1. Changes
    - Update create_stripe_checkout function to always use PLN
    - Ensure payment amounts are always in PLN
    - Add validation to prevent non-PLN payments

  2. Security
    - Maintain existing security model
    - Ensure proper validation of inputs
*/

-- Update function to create a Stripe checkout session with fixed PLN currency
CREATE OR REPLACE FUNCTION create_stripe_checkout(
  job_id UUID,
  amount INT,
  currency TEXT,
  job_title TEXT,
  company_name TEXT,
  is_premium BOOLEAN,
  success_url TEXT,
  cancel_url TEXT
)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  stripe_secret_key TEXT := 'sk_test_51O5JZpLxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; -- Replace with your actual secret key
  checkout_session_id TEXT;
  response TEXT;
  payment_id UUID;
  product_name TEXT;
  payment_currency TEXT := 'PLN'; -- Always use PLN for payments
BEGIN
  -- Input validation
  IF job_id IS NULL THEN
    RAISE EXCEPTION 'job_id cannot be null';
  END IF;
  
  IF amount <= 0 THEN
    RAISE EXCEPTION 'amount must be greater than 0';
  END IF;
  
  -- Set product name based on premium status
  IF is_premium THEN
    product_name := 'Ogłoszenie Premium (90 dni)';
  ELSE
    product_name := 'Standardowe ogłoszenie (60 dni)';
  END IF;
  
  -- Create a payment record (always in PLN)
  INSERT INTO payments (job_post_id, amount, currency, status)
  VALUES (job_id, amount::numeric / 100, payment_currency, 'pending')
  RETURNING id INTO payment_id;
  
  -- In a real implementation, this would make an HTTP request to Stripe API
  -- For now, we'll simulate the response
  checkout_session_id := 'cs_test_' || encode(gen_random_bytes(24), 'hex');
  
  -- Log the checkout session creation
  RAISE LOG 'Created checkout session: id=%, job_id=%, amount=%, currency=%, is_premium=%', 
    checkout_session_id, job_id, amount, payment_currency, is_premium;
  
  -- Return the checkout session ID
  RETURN checkout_session_id;
END;
$$;