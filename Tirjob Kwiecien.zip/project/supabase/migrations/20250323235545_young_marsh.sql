/*
  # Add sample blog posts

  1. Changes
    - Add 10 new sample blog posts
    - Link posts to existing categories
    - Set proper status and dates
    - Add realistic content

  2. Security
    - Maintain existing RLS policies
*/

-- Insert sample blog posts
WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Jak zostać kierowcą międzynarodowym? Kompletny przewodnik 2025',
  'jak-zostac-kierowca-miedzynarodowym-2025',
  '# Jak zostać kierowcą międzynarodowym - przewodnik 2025

## Wymagane kwalifikacje

1. Prawo jazdy kategorii C+E
2. Kwalifikacja wstępna
3. Karta kierowcy
4. Aktualne badania lekarskie i psychologiczne
5. Znajomość języków obcych (minimum podstawy)

## Krok po kroku

### 1. Zdobycie prawa jazdy
- Kategoria B (min. 3 lata)
- Kategoria C
- Kategoria C+E

### 2. Kwalifikacja wstępna
- 280 godzin zajęć
- Teoria i praktyka
- Egzamin państwowy

### 3. Zdobycie doświadczenia
- Start od transportu krajowego
- Poznanie specyfiki pracy
- Budowanie reputacji

### 4. Rozwój kompetencji
- Kursy językowe
- Szkolenia z czasu pracy
- Obsługa tachografu

## Perspektywy zawodowe

- Atrakcyjne wynagrodzenie
- Możliwość poznawania świata
- Stabilne zatrudnienie
- Rozwój kariery

## Wyzwania

- Długie okresy poza domem
- Stres i zmęczenie
- Odpowiedzialność za ładunek
- Przepisy i kontrole

## Podsumowanie

Zawód kierowcy międzynarodowego to odpowiedzialna i wymagająca praca, ale oferująca atrakcyjne warunki i możliwości rozwoju.',
  'Kompleksowy przewodnik dla osób zainteresowanych karierą kierowcy w transporcie międzynarodowym - od wymagań po pierwsze kroki w zawodzie.',
  id,
  'published',
  NOW() - INTERVAL '2 days'
FROM category_ids
WHERE slug = 'edukacja-i-rozwoj'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'jak-zostac-kierowca-miedzynarodowym-2025'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Zmiany w przepisach o czasie pracy kierowców 2025',
  'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025',
  '# Nowe przepisy o czasie pracy kierowców 2025

## Kluczowe zmiany

### 1. Okresy odpoczynku
- Nowe zasady odbierania odpoczynku tygodniowego
- Możliwość dzielenia odpoczynku dobowego
- Specjalne regulacje dla załóg dwuosobowych

### 2. Powrót do bazy
- Obowiązkowy powrót co 4 tygodnie
- Wyjątki i odstępstwa
- Dokumentacja powrotów

### 3. Tachograf inteligentny
- Nowa generacja urządzeń
- Automatyczna rejestracja przekroczeń granicy
- Monitoring czasu pracy

## Praktyczne konsekwencje

- Lepsze planowanie tras
- Większa kontrola nad czasem pracy
- Nowe obowiązki dokumentacyjne

## Kary i kontrole

- Zaostrzone sankcje
- Nowe uprawnienia służb kontrolnych
- System kar punktowych

## Przygotowanie do zmian

1. Szkolenia dla kierowców
2. Aktualizacja procedur
3. Modernizacja floty
4. Dostosowanie harmonogramów

## Podsumowanie

Nowe przepisy wymagają dostosowania, ale długoterminowo poprawią bezpieczeństwo i komfort pracy kierowców.',
  'Szczegółowa analiza najważniejszych zmian w przepisach dotyczących czasu pracy kierowców zawodowych, które wchodzą w życie w 2025 roku.',
  id,
  'published',
  NOW() - INTERVAL '3 days'
FROM category_ids
WHERE slug = 'trendy-w-branzy'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Jak skutecznie rekrutować kierowców w 2025 roku?',
  'jak-skutecznie-rekrutowac-kierowcow-2025',
  '# Skuteczna rekrutacja kierowców w 2025

## Aktualna sytuacja na rynku

- Rosnący niedobór kierowców
- Zwiększona konkurencja o pracowników
- Nowe oczekiwania kandydatów

## Strategie rekrutacji

### 1. Employer branding
- Budowanie marki pracodawcy
- Obecność w mediach społecznościowych
- Referencje od obecnych pracowników

### 2. Atrakcyjny pakiet benefitów
- Konkurencyjne wynagrodzenie
- Ubezpieczenie zdrowotne
- System premiowy
- Szkolenia i rozwój

### 3. Nowoczesne metody rekrutacji
- Wykorzystanie mediów społecznościowych
- Portale branżowe
- Rekomendacje pracowników
- Współpraca ze szkołami

## Proces rekrutacji

1. Precyzyjne ogłoszenia
2. Szybka odpowiedź na aplikacje
3. Uproszczony proces rekrutacji
4. Jasne warunki zatrudnienia

## Onboarding

- Program wdrożeniowy
- Mentor dla nowego pracownika
- Regularne feedback
- Wsparcie w pierwszych miesiącach

## Retencja pracowników

- System motywacyjny
- Ścieżka rozwoju
- Work-life balance
- Regularne podwyżki

## Podsumowanie

Skuteczna rekrutacja wymaga kompleksowego podejścia i dostosowania do aktualnych trendów rynkowych.',
  'Praktyczne wskazówki jak skutecznie rekrutować i zatrzymać kierowców zawodowych w obecnej sytuacji rynkowej.',
  id,
  'published',
  NOW() - INTERVAL '4 days'
FROM category_ids
WHERE slug = 'porady-dla-pracodawcow'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'jak-skutecznie-rekrutowac-kierowcow-2025'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Sztuczna inteligencja w transporcie - przyszłość czy zagrożenie?',
  'sztuczna-inteligencja-w-transporcie',
  '# Sztuczna inteligencja w transporcie

## Obecne zastosowania AI

### 1. Optymalizacja tras
- Analiza danych historycznych
- Przewidywanie korków
- Optymalizacja zużycia paliwa

### 2. Zarządzanie flotą
- Predykcyjne utrzymanie
- Monitoring stanu technicznego
- Analiza stylu jazdy

### 3. Bezpieczeństwo
- Systemy wspomagania kierowcy
- Wykrywanie zmęczenia
- Przewidywanie zagrożeń

## Przyszłe zastosowania

### 1. Autonomiczne pojazdy
- Poziomy automatyzacji
- Testy i wdrożenia
- Regulacje prawne

### 2. Smart Logistics
- Automatyczne planowanie
- Inteligentne magazyny
- Predykcja popytu

## Wpływ na pracę kierowców

- Nowe umiejętności
- Zmiana charakteru pracy
- Bezpieczeństwo zatrudnienia

## Wyzwania

- Koszty wdrożenia
- Bezpieczeństwo danych
- Akceptacja społeczna
- Regulacje prawne

## Podsumowanie

AI to narzędzie wspierające, nie zastępujące człowieka w transporcie.',
  'Analiza wpływu sztucznej inteligencji na branżę transportową - korzyści, zagrożenia i perspektywy rozwoju.',
  id,
  'published',
  NOW() - INTERVAL '5 days'
FROM category_ids
WHERE slug = 'innowacje'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'sztuczna-inteligencja-w-transporcie'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Eco-driving w praktyce - jak jeździć ekonomicznie?',
  'eco-driving-w-praktyce',
  '# Eco-driving - oszczędna i ekologiczna jazda

## Podstawy eco-drivingu

### 1. Przygotowanie do jazdy
- Sprawdzenie ciśnienia w oponach
- Usunięcie zbędnego obciążenia
- Planowanie trasy

### 2. Techniki jazdy
- Płynne przyspieszanie
- Utrzymywanie stałej prędkości
- Przewidywanie sytuacji na drodze
- Wykorzystanie rozpędu

### 3. Obsługa pojazdu
- Optymalne obroty silnika
- Właściwy dobór biegów
- Wykorzystanie tempomatu
- Wyłączanie silnika na postojach

## Korzyści

### 1. Ekonomiczne
- Mniejsze zużycie paliwa
- Niższe koszty eksploatacji
- Mniejsze zużycie części

### 2. Ekologiczne
- Redukcja emisji CO2
- Mniejszy hałas
- Ochrona środowiska

### 3. Bezpieczeństwo
- Lepsza kontrola pojazdu
- Mniej sytuacji awaryjnych
- Spokojniejsza jazda

## Praktyczne wskazówki

1. Regularnie monitoruj zużycie paliwa
2. Analizuj swój styl jazdy
3. Korzystaj z systemów telematycznych
4. Bierz udział w szkoleniach

## Podsumowanie

Eco-driving to inwestycja w ekonomię i ekologię.',
  'Praktyczny przewodnik po technikach eco-drivingu dla kierowców zawodowych - jak oszczędzać paliwo i dbać o środowisko.',
  id,
  'published',
  NOW() - INTERVAL '6 days'
FROM category_ids
WHERE slug = 'porady-dla-kandydatow'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'eco-driving-w-praktyce'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Targi pracy w branży TSL 2025 - kalendarz wydarzeń',
  'targi-pracy-tsl-2025',
  '# Targi pracy w branży TSL 2025

## Największe wydarzenia branżowe

### TransLogistica Poland (Warszawa)
- Data: 5-7 maja 2025
- Miejsce: EXPO XXI
- Program:
  - Spotkania z pracodawcami
  - Konferencje branżowe
  - Warsztaty dla kierowców
  - Pokazy sprzętu

### Transport & Logistics (Poznań)
- Data: 12-14 czerwca 2025
- Miejsce: MTP
- Atrakcje:
  - Job fair
  - Szkolenia
  - Networking
  - Konkursy

### LogiExpo (Kraków)
- Data: 15-17 września 2025
- Miejsce: EXPO Kraków
- Wydarzenia:
  - Giełda pracy
  - Prezentacje firm
  - Konsultacje CV
  - Panel ekspertów

## Jak się przygotować?

1. Aktualne CV
2. Portfolio zawodowe
3. Lista pytań do pracodawców
4. Dokumenty i certyfikaty

## Korzyści z uczestnictwa

- Bezpośredni kontakt z pracodawcami
- Poznanie trendów branżowych
- Networking
- Szkolenia i warsztaty

## Praktyczne wskazówki

- Rejestracja online
- Plan zwiedzania
- Dress code
- Follow-up

## Podsumowanie

Targi to świetna okazja do rozwoju kariery.',
  'Kompletny przewodnik po najważniejszych targach pracy w branży TSL w 2025 roku - daty, lokalizacje i praktyczne wskazówki.',
  id,
  'published',
  NOW() - INTERVAL '7 days'
FROM category_ids
WHERE slug = 'wydarzenia-i-szkolenia'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'targi-pracy-tsl-2025'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Digitalizacja dokumentów transportowych - przewodnik po e-CMR',
  'digitalizacja-dokumentow-transportowych-e-cmr',
  '# Digitalizacja dokumentów transportowych

## Czym jest e-CMR?

### Podstawowe informacje
- Elektroniczny list przewozowy
- Podstawy prawne
- Korzyści z wdrożenia
- Wymagania techniczne

### Funkcjonalności
- Podpis elektroniczny
- Śledzenie statusu
- Historia zmian
- Archiwizacja

## Wdrożenie systemu

### 1. Przygotowanie
- Analiza potrzeb
- Wybór dostawcy
- Szkolenia pracowników
- Testy systemu

### 2. Implementacja
- Integracja z TMS
- Konfiguracja urządzeń
- Procedury awaryjne
- Monitoring

## Korzyści

### 1. Operacyjne
- Szybsza obsługa
- Mniej błędów
- Łatwiejsze archiwizowanie
- Real-time tracking

### 2. Finansowe
- Niższe koszty
- Szybsze płatności
- Mniej reklamacji
- Oszczędność papieru

## Wyzwania

- Bezpieczeństwo danych
- Szkolenie personelu
- Koszty wdrożenia
- Integracja systemów

## Podsumowanie

E-CMR to przyszłość dokumentacji transportowej.',
  'Kompleksowy przewodnik po wdrażaniu elektronicznego listu przewozowego (e-CMR) w firmie transportowej.',
  id,
  'published',
  NOW() - INTERVAL '8 days'
FROM category_ids
WHERE slug = 'innowacje'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'digitalizacja-dokumentow-transportowych-e-cmr'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Jak przygotować się do kontroli ITD?',
  'jak-przygotowac-sie-do-kontroli-itd',
  '# Przygotowanie do kontroli ITD

## Wymagana dokumentacja

### 1. Dokumenty kierowcy
- Prawo jazdy
- Karta kierowcy
- Zaświadczenie o zatrudnieniu
- Badania lekarskie
- Świadectwo kwalifikacji

### 2. Dokumenty pojazdu
- Dowód rejestracyjny
- Ubezpieczenie OC
- Licencja transportowa
- Dokumenty ładunku
- Zezwolenia specjalne

## Przygotowanie techniczne

### 1. Stan pojazdu
- Oświetlenie
- Ogumienie
- Wyposażenie obowiązkowe
- Oznakowanie

### 2. Tachograf
- Kalibracja
- Zapisy
- Plomby
- Dokumentacja

## Procedury kontrolne

1. Prawa kontrolującego
2. Prawa kontrolowanego
3. Protokół kontroli
4. Postępowanie odwoławcze

## Najczęstsze naruszenia

- Przekroczenie czasu pracy
- Brak dokumentów
- Przeciążenie
- Stan techniczny

## Konsekwencje

- Mandaty
- Punkty karne
- Zatrzymanie dokumentów
- Unieruchomienie pojazdu

## Podsumowanie

Przygotowanie to klucz do bezproblemowej kontroli.',
  'Praktyczny przewodnik jak przygotować się do kontroli Inspekcji Transportu Drogowego - dokumenty, procedury i najczęstsze błędy.',
  id,
  'published',
  NOW() - INTERVAL '9 days'
FROM category_ids
WHERE slug = 'porady-dla-kandydatow'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'jak-przygotowac-sie-do-kontroli-itd'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Zarządzanie flotą w małej firmie transportowej',
  'zarzadzanie-flota-w-malej-firmie',
  '# Zarządzanie flotą w małej firmie

## Podstawy zarządzania

### 1. Planowanie
- Harmonogram przeglądów
- Plan wymiany pojazdów
- Budżetowanie
- Analiza kosztów

### 2. Monitoring
- Systemy telematyczne
- Zużycie paliwa
- Styl jazdy
- Lokalizacja pojazdów

## Optymalizacja kosztów

### 1. Paliwo
- Karty paliwowe
- Monitoring zużycia
- Szkolenia kierowców
- Optymalizacja tras

### 2. Serwis
- Umowy serwisowe
- Części zamienne
- Przeglądy prewencyjne
- Własny warsztat

## Zarządzanie personelem

1. Grafik kierowców
2. Szkolenia
3. Motywacja
4. Komunikacja

## Dokumentacja

- Karty drogowe
- Raporty paliwowe
- Historia serwisowa
- Ubezpieczenia

## Technologie

- System TMS
- GPS
- Aplikacje mobilne
- Analityka

## Podsumowanie

Efektywne zarządzanie to podstawa sukcesu.',
  'Praktyczny przewodnik po zarządzaniu małą flotą transportową - od planowania po optymalizację kosztów.',
  id,
  'published',
  NOW() - INTERVAL '10 days'
FROM category_ids
WHERE slug = 'porady-dla-pracodawcow'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'zarzadzanie-flota-w-malej-firmie'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Rozwój zawodowy w branży TSL - ścieżki kariery',
  'rozwoj-zawodowy-w-branzy-tsl',
  '# Ścieżki kariery w branży TSL

## Kierowcy zawodowi

### 1. Rozwój kwalifikacji
- Kategorie prawa jazdy
- Certyfikaty ADR
- Kursy specjalistyczne
- Języki obce

### 2. Specjalizacje
- Transport międzynarodowy
- Przewozy specjalne
- Transport chłodniczy
- Przewóz materiałów niebezpiecznych

## Spedycja i logistyka

### 1. Stanowiska początkowe
- Asystent spedytora
- Dyspozytor
- Logistyk magazynu
- Koordynator transportu

### 2. Stanowiska średniego szczebla
- Spedytor międzynarodowy
- Kierownik magazynu
- Planista transportu
- Key Account Manager

### 3. Stanowiska kierownicze
- Kierownik działu transportu
- Dyrektor logistyki
- Country Manager
- Supply Chain Manager

## Wymagane kompetencje

1. Wykształcenie kierunkowe
2. Certyfikaty zawodowe
3. Doświadczenie praktyczne
4. Umiejętności miękkie

## Trendy rozwojowe

- Digitalizacja
- Zielony transport
- Automatyzacja
- Analityka danych

## Podsumowanie

Branża TSL oferuje wiele możliwości rozwoju.',
  'Kompleksowy przewodnik po możliwościach rozwoju zawodowego w branży TSL - od kierowcy po menedżera logistyki.',
  id,
  'published',
  NOW() - INTERVAL '11 days'
FROM category_ids
WHERE slug = 'edukacja-i-rozwoj'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'rozwoj-zawodowy-w-branzy-tsl'
);