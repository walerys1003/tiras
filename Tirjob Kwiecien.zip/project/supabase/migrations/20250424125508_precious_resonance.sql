/*
  # Fix user edit functionality

  1. Changes
    - Improve update_user_with_metadata function to properly update auth.users
    - Add detailed logging for troubleshooting
    - Fix the way metadata is updated to preserve existing values
    - Ensure proper error handling and transaction management

  2. Security
    - Maintain SECURITY DEFINER to ensure proper permissions
    - Validate input parameters
    - Ensure proper role-based access control
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS update_user_with_metadata(UUID, TEXT, TEXT);

-- Create improved function to update user and metadata
CREATE OR REPLACE FUNCTION update_user_with_metadata(
  user_id UUID,
  user_name TEXT,
  user_role TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_existing_app_metadata JSONB;
  v_existing_user_metadata JSONB;
  v_updated_app_metadata JSONB;
  v_updated_user_metadata JSONB;
  v_caller_role TEXT;
  v_result RECORD;
BEGIN
  -- Input validation
  IF user_id IS NULL THEN
    RAISE EXCEPTION 'user_id cannot be null';
  END IF;
  
  IF user_name IS NULL OR user_name = '' THEN
    RAISE EXCEPTION 'user_name cannot be null or empty';
  END IF;
  
  IF user_role IS NULL OR user_role = '' THEN
    RAISE EXCEPTION 'user_role cannot be null or empty';
  END IF;
  
  -- Validate role value
  IF user_role NOT IN ('admin', 'redaktor', 'moderator', 'user') THEN
    RAISE EXCEPTION 'Invalid role. Must be one of: admin, redaktor, moderator, user';
  END IF;
  
  -- Get caller's role
  v_caller_role := current_setting('request.jwt.claims', true)::json->>'role';
  
  -- Check if caller has admin role
  IF v_caller_role != 'admin' THEN
    RAISE LOG 'Permission denied: caller_role=%, required_role=admin', v_caller_role;
    RAISE EXCEPTION 'Only admin users can update user roles';
  END IF;
  
  -- Log the update attempt
  RAISE LOG 'Updating user: id=%, name=%, role=%', user_id, user_name, user_role;
  
  -- Get existing metadata
  SELECT 
    raw_app_meta_data,
    raw_user_meta_data
  INTO 
    v_existing_app_metadata,
    v_existing_user_metadata
  FROM auth.users
  WHERE id = user_id;
  
  -- Check if user exists
  IF v_existing_app_metadata IS NULL THEN
    RAISE LOG 'User not found: id=%', user_id;
    RAISE EXCEPTION 'User not found';
  END IF;
  
  -- Log existing metadata
  RAISE LOG 'Existing metadata: app_metadata=%, user_metadata=%', 
    v_existing_app_metadata, 
    v_existing_user_metadata;
  
  -- Create updated metadata objects that preserve existing values
  v_updated_app_metadata := v_existing_app_metadata || jsonb_build_object('role', user_role);
  v_updated_user_metadata := v_existing_user_metadata || jsonb_build_object('name', user_name);
  
  -- Log updated metadata
  RAISE LOG 'Updated metadata: app_metadata=%, user_metadata=%', 
    v_updated_app_metadata, 
    v_updated_user_metadata;
  
  -- Start a transaction
  BEGIN
    -- Update users table
    UPDATE users
    SET 
      name = user_name,
      role = user_role,
      updated_at = now()
    WHERE id = user_id;
    
    -- Update auth.users metadata
    UPDATE auth.users
    SET 
      raw_app_meta_data = v_updated_app_metadata,
      raw_user_meta_data = v_updated_user_metadata
    WHERE id = user_id
    RETURNING id INTO v_result;
    
    -- Check if update was successful
    IF v_result.id IS NULL THEN
      RAISE LOG 'Failed to update auth.users for id=%', user_id;
      RAISE EXCEPTION 'Failed to update user metadata';
    END IF;
    
    -- Log successful update
    RAISE LOG 'Successfully updated user and metadata for id=%', user_id;
    
    -- Commit transaction
    RETURN TRUE;
  EXCEPTION WHEN OTHERS THEN
    -- Log any errors
    RAISE LOG 'Error in update_user_with_metadata transaction: %', SQLERRM;
    RAISE EXCEPTION 'Error updating user: %', SQLERRM;
  END;
END;
$$;