/*
  # Fix job posts RLS policies to allow public insertion

  1. Changes
    - Drop existing policies that are causing issues
    - Create new policies that allow public users to insert job posts
    - Fix policies for related tables to ensure proper data flow
    - Simplify trigger function to avoid errors

  2. Security
    - Allow public insertion while maintaining security for updates
    - Ensure proper access control for viewing and managing job posts
    - Maintain admin/moderator privileges
*/

-- Drop existing policies for job_posts
DROP POLICY IF EXISTS "Job posts are viewable by everyone" ON job_posts;
DROP POLICY IF EXISTS "Job posts are insertable by anyone" ON job_posts;
DROP POLICY IF EXISTS "Job posts are updatable by company email" ON job_posts;
DROP POLICY IF EXISTS "Admin users can manage job posts" ON job_posts;
DROP POLICY IF EXISTS "Public users can update payment status" ON job_posts;
DROP POLICY IF EXISTS "Enable job post creation for authenticated users" ON job_posts;
DROP POLICY IF EXISTS "Enable job post updates for company owners" ON job_posts;
DROP POLICY IF EXISTS "Enable job post deletion for company owners" ON job_posts;
DROP POLICY IF EXISTS "Enable job post viewing for active listings" ON job_posts;
DROP POLICY IF EXISTS "Enable admin management of job posts" ON job_posts;

-- Create new policies for job_posts

-- 1. Allow anyone to view active job posts
CREATE POLICY "Job posts are viewable by everyone"
  ON job_posts
  FOR SELECT
  TO public
  USING ((status = 'active') AND (expires_at > now()));

-- 2. Allow anyone to insert job posts (including unauthenticated users)
CREATE POLICY "Job posts are insertable by anyone"
  ON job_posts
  FOR INSERT
  TO public
  WITH CHECK (true);

-- 3. Allow company owners to update their own job posts
CREATE POLICY "Job posts are updatable by company email"
  ON job_posts
  FOR UPDATE
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = current_setting('request.jwt.claims', true)::json->>'email'
    )
  );

-- 4. Allow admin/moderator users to manage all job posts
CREATE POLICY "Admin users can manage job posts"
  ON job_posts
  FOR ALL
  TO authenticated
  USING (
    ((current_setting('request.jwt.claims', true)::json->>'role') = 'admin') OR
    ((current_setting('request.jwt.claims', true)::json->>'role') = 'moderator')
  );

-- Drop and recreate the trigger function with proper INSERT handling
DROP TRIGGER IF EXISTS check_job_post_update_trigger ON job_posts;
DROP FUNCTION IF EXISTS check_job_post_update();

-- Create a simplified trigger function that only applies to UPDATE operations
CREATE OR REPLACE FUNCTION check_job_post_update()
RETURNS TRIGGER AS $$
BEGIN
  -- For UPDATE operations, check if critical fields are being changed
  IF (
    (OLD.title IS DISTINCT FROM NEW.title) OR
    (OLD.position_category IS DISTINCT FROM NEW.position_category) OR
    (OLD.position_type IS DISTINCT FROM NEW.position_type) OR
    (OLD.work_type IS DISTINCT FROM NEW.work_type) OR
    (OLD.country_id IS DISTINCT FROM NEW.country_id) OR
    (OLD.city_id IS DISTINCT FROM NEW.city_id) OR
    (OLD.trailer_type IS DISTINCT FROM NEW.trailer_type) OR
    (OLD.schedule IS DISTINCT FROM NEW.schedule) OR
    (OLD.salary_amount IS DISTINCT FROM NEW.salary_amount) OR
    (OLD.salary_currency IS DISTINCT FROM NEW.salary_currency) OR
    (OLD.salary_type IS DISTINCT FROM NEW.salary_type) OR
    (OLD.is_premium IS DISTINCT FROM NEW.is_premium) OR
    (OLD.expires_at IS DISTINCT FROM NEW.expires_at) OR
    (OLD.company_id IS DISTINCT FROM NEW.company_id)
  ) THEN
    -- If any of these fields are changed, check if user is admin/moderator
    IF (
      ((current_setting('request.jwt.claims', true)::json->>'role') = 'admin') OR
      ((current_setting('request.jwt.claims', true)::json->>'role') = 'moderator')
    ) THEN
      -- Allow admins and moderators to update all fields
      RETURN NEW;
    ELSE
      -- For regular users, only allow updating payment_status and status
      RAISE EXCEPTION 'Only payment_status and status fields can be updated';
    END IF;
  END IF;
  
  -- If we get here, only payment_status and status are being updated, so allow it
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to enforce update restrictions (ONLY for UPDATE operations)
CREATE TRIGGER check_job_post_update_trigger
  BEFORE UPDATE ON job_posts
  FOR EACH ROW
  EXECUTE FUNCTION check_job_post_update();

-- Ensure all related tables have proper policies

-- Companies table
DROP POLICY IF EXISTS "Companies are insertable by anyone" ON companies;
CREATE POLICY "Companies are insertable by anyone"
  ON companies
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job requirements table
DROP POLICY IF EXISTS "Job requirements are insertable by anyone" ON job_requirements;
CREATE POLICY "Job requirements are insertable by anyone"
  ON job_requirements
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job duties table
DROP POLICY IF EXISTS "Job duties are insertable by anyone" ON job_duties;
CREATE POLICY "Job duties are insertable by anyone"
  ON job_duties
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job benefits table
DROP POLICY IF EXISTS "Job benefits are insertable by anyone" ON job_benefits;
CREATE POLICY "Job benefits are insertable by anyone"
  ON job_benefits
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job languages table
DROP POLICY IF EXISTS "Job languages are insertable by anyone" ON job_languages;
CREATE POLICY "Job languages are insertable by anyone"
  ON job_languages
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job qualifications table
DROP POLICY IF EXISTS "Job qualifications are insertable by anyone" ON job_qualifications;
CREATE POLICY "Job qualifications are insertable by anyone"
  ON job_qualifications
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Job cities table
DROP POLICY IF EXISTS "Anyone can insert cities" ON job_cities;
CREATE POLICY "Anyone can insert cities"
  ON job_cities
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Payments table
DROP POLICY IF EXISTS "Anyone can insert payments" ON payments;
CREATE POLICY "Anyone can insert payments"
  ON payments
  FOR INSERT
  TO public
  WITH CHECK (true);