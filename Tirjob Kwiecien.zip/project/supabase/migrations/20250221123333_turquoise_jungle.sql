/*
  # Schemat bazy danych TirJob.pl

  1. Nowe Tabele
    - `companies` - Firmy dodające ogłoszenia
      - `id` (uuid, primary key)
      - `name` (text) - Nazwa firmy
      - `email` (text) - Email kontaktowy
      - `phone` (text) - Telefon kontaktowy
      - `nip` (text) - NIP firmy
      - `invoice_data` (text) - Dane do faktury
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `job_posts` - Ogłoszenia o pracę
      - `id` (uuid, primary key)
      - `company_id` (uuid) - Powiązanie z firmą
      - `title` (text) - Tytuł ogłoszenia
      - `position_category` (text) - Kategoria stanowiska
      - `position_type` (text) - Typ stanowiska
      - `work_type` (text) - Rodzaj pracy (krajowy/międzynarodowy)
      - `country` (text) - Kraj
      - `voivodeship` (text) - Województwo (dla Polski)
      - `city` (text) - Miasto
      - `trailer_type` (text) - Rodzaj naczepy
      - `schedule` (text) - System pracy
      - `salary_amount` (numeric) - Kwota wynagrodzenia
      - `salary_currency` (text) - Waluta wynagrodzenia
      - `salary_type` (text) - Typ wynagrodzenia
      - `is_premium` (boolean) - Czy ogłoszenie premium
      - `expires_at` (timestamptz) - Data wygaśnięcia
      - `status` (text) - Status ogłoszenia
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `job_requirements` - Wymagania dla ogłoszenia
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `experience` (text) - Wymagane doświadczenie
      - `created_at` (timestamptz)

    - `job_duties` - Obowiązki w ogłoszeniu
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `duty` (text) - Opis obowiązku
      - `created_at` (timestamptz)

    - `job_benefits` - Benefity w ogłoszeniu
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `benefit` (text) - Opis benefitu
      - `created_at` (timestamptz)

    - `job_languages` - Wymagane języki
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `language` (text) - Język
      - `created_at` (timestamptz)

    - `job_qualifications` - Wymagane kwalifikacje
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `qualification` (text) - Kwalifikacja
      - `created_at` (timestamptz)

    - `job_applications` - Aplikacje na ogłoszenia
      - `id` (uuid, primary key)
      - `job_post_id` (uuid) - Powiązanie z ogłoszeniem
      - `name` (text) - Imię i nazwisko
      - `email` (text) - Email
      - `phone` (text) - Telefon
      - `message` (text) - Wiadomość
      - `cv_url` (text) - URL do CV
      - `status` (text) - Status aplikacji
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Bezpieczeństwo
    - Włączone RLS dla wszystkich tabel
    - Polityki dostępu dla uwierzytelnionych użytkowników
    - Zabezpieczenie danych firm i aplikacji

  3. Indeksy
    - Indeksy na często wyszukiwanych polach
    - Indeksy na kluczach obcych
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Companies table
CREATE TABLE companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  nip TEXT,
  invoice_data TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job posts table
CREATE TABLE job_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  position_category TEXT NOT NULL,
  position_type TEXT NOT NULL,
  work_type TEXT NOT NULL,
  country TEXT NOT NULL,
  voivodeship TEXT,
  city TEXT NOT NULL,
  trailer_type TEXT,
  schedule TEXT,
  salary_amount NUMERIC,
  salary_currency TEXT,
  salary_type TEXT,
  is_premium BOOLEAN DEFAULT false,
  expires_at TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job requirements table
CREATE TABLE job_requirements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  experience TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job duties table
CREATE TABLE job_duties (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  duty TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job benefits table
CREATE TABLE job_benefits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  benefit TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job languages table
CREATE TABLE job_languages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  language TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job qualifications table
CREATE TABLE job_qualifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  qualification TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job applications table
CREATE TABLE job_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_post_id UUID NOT NULL REFERENCES job_posts(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  message TEXT,
  cv_url TEXT,
  status TEXT DEFAULT 'new',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_job_posts_company_id ON job_posts(company_id);
CREATE INDEX idx_job_posts_status ON job_posts(status);
CREATE INDEX idx_job_posts_is_premium ON job_posts(is_premium);
CREATE INDEX idx_job_posts_expires_at ON job_posts(expires_at);
CREATE INDEX idx_job_posts_position_category ON job_posts(position_category);
CREATE INDEX idx_job_posts_country ON job_posts(country);
CREATE INDEX idx_job_posts_city ON job_posts(city);

-- Enable Row Level Security
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_requirements ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_duties ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_qualifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Companies are viewable by authenticated users" ON companies
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Companies are insertable by authenticated users" ON companies
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Companies are updatable by owners" ON companies
  FOR UPDATE TO authenticated USING (
    auth.uid() IN (
      SELECT DISTINCT company_id 
      FROM job_posts 
      WHERE company_id = companies.id
    )
  );

CREATE POLICY "Job posts are viewable by everyone" ON job_posts
  FOR SELECT USING (status = 'active' AND expires_at > NOW());

CREATE POLICY "Job posts are insertable by authenticated users" ON job_posts
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Job posts are updatable by owners" ON job_posts
  FOR UPDATE TO authenticated USING (company_id = auth.uid());

CREATE POLICY "Job requirements are viewable by everyone" ON job_requirements
  FOR SELECT USING (true);

CREATE POLICY "Job duties are viewable by everyone" ON job_duties
  FOR SELECT USING (true);

CREATE POLICY "Job benefits are viewable by everyone" ON job_benefits
  FOR SELECT USING (true);

CREATE POLICY "Job languages are viewable by everyone" ON job_languages
  FOR SELECT USING (true);

CREATE POLICY "Job qualifications are viewable by everyone" ON job_qualifications
  FOR SELECT USING (true);

CREATE POLICY "Job applications are insertable by everyone" ON job_applications
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job applications are viewable by job owners" ON job_applications
  FOR SELECT TO authenticated USING (
    job_post_id IN (
      SELECT id FROM job_posts WHERE company_id = auth.uid()
    )
  );

-- Create functions for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_companies_updated_at
  BEFORE UPDATE ON companies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_job_posts_updated_at
  BEFORE UPDATE ON job_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_job_applications_updated_at
  BEFORE UPDATE ON job_applications
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();