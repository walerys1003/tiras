/*
  # Fix RLS policies for job creation

  1. Changes
    - Drop existing policies that might be causing issues
    - Create new policies for job_cities and job_posts tables
    - Add policies for related tables (requirements, duties, benefits, etc.)
    - Fix syntax by removing IF NOT EXISTS which is not supported for policies

  2. Security
    - Maintain proper security model
    - Allow public users to create job listings
    - Ensure proper data access control
*/

-- First, drop existing policies that might be causing issues
DROP POLICY IF EXISTS "Anyone can insert cities" ON job_cities;
DROP POLICY IF EXISTS "Job posts are insertable by anyone" ON job_posts;

-- Create policy for job_cities to allow public insertion
CREATE POLICY "Anyone can insert cities"
  ON job_cities
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policy for job_posts to allow public insertion
CREATE POLICY "Job posts are insertable by anyone"
  ON job_posts
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Drop existing policies for related tables if they exist
DROP POLICY IF EXISTS "Job requirements are insertable by anyone" ON job_requirements;
DROP POLICY IF EXISTS "Job duties are insertable by anyone" ON job_duties;
DROP POLICY IF EXISTS "Job benefits are insertable by anyone" ON job_benefits;
DROP POLICY IF EXISTS "Job languages are insertable by anyone" ON job_languages;
DROP POLICY IF EXISTS "Job qualifications are insertable by anyone" ON job_qualifications;
DROP POLICY IF EXISTS "Anyone can insert payments" ON payments;
DROP POLICY IF EXISTS "Companies are insertable by anyone" ON companies;

-- Create policies for related tables (without IF NOT EXISTS)
CREATE POLICY "Job requirements are insertable by anyone"
  ON job_requirements
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Job duties are insertable by anyone"
  ON job_duties
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Job benefits are insertable by anyone"
  ON job_benefits
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Job languages are insertable by anyone"
  ON job_languages
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Job qualifications are insertable by anyone"
  ON job_qualifications
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policy for payments to allow public insertion
CREATE POLICY "Anyone can insert payments"
  ON payments
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policy for companies to allow public insertion
CREATE POLICY "Companies are insertable by anyone"
  ON companies
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Ensure all tables have RLS enabled
ALTER TABLE job_cities ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_requirements ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_duties ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_qualifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;