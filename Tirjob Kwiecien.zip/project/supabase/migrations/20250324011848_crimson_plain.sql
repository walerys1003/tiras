/*
  # Add featured image column to blog_posts table

  1. Changes
    - Add featured_image column to blog_posts table
    - Update existing posts with Unsplash images
    - Add index for performance

  2. Security
    - Maintain existing RLS policies
*/

-- Add featured_image column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'blog_posts' 
    AND column_name = 'featured_image'
  ) THEN
    ALTER TABLE blog_posts 
    ADD COLUMN featured_image text;
  END IF;
END $$;

-- Update existing posts with featured images
UPDATE blog_posts
SET featured_image = CASE 
  WHEN slug = 'jak-zostac-kierowca-miedzynarodowym-2025' 
  THEN 'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2575&q=80'
  
  WHEN slug = 'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025' 
  THEN 'https://images.unsplash.com/photo-1516733968668-dbdce39c4651?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'jak-skutecznie-rekrutowac-kierowcow-2025' 
  THEN 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'sztuczna-inteligencja-w-transporcie' 
  THEN 'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'eco-driving-w-praktyce' 
  THEN 'https://images.unsplash.com/photo-1586768015051-8c122be6e1ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'targi-pracy-tsl-2025' 
  THEN 'https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'digitalizacja-dokumentow-transportowych-e-cmr' 
  THEN 'https://images.unsplash.com/photo-1423666639041-f56000c27a9a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'jak-przygotowac-sie-do-kontroli-itd' 
  THEN 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'zarzadzanie-flota-w-malej-firmie' 
  THEN 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  WHEN slug = 'rozwoj-zawodowy-w-branzy-tsl' 
  THEN 'https://images.unsplash.com/photo-1565856381933-251f0da06317?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80'
  
  ELSE 'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2575&q=80'
END
WHERE featured_image IS NULL;