/*
  # Allow public users to create job posts

  1. Changes
    - Drop existing policies for job_posts
    - Create new policies that allow public (unauthenticated) users to create job posts
    - Maintain existing security for viewing and updating
    - Remove authentication requirements for job post creation

  2. Security
    - Allow public job post creation
    - Maintain proper access control for other operations
    - Ensure data integrity
*/

-- Drop existing policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Enable job post creation for authenticated users" ON job_posts;
  DROP POLICY IF EXISTS "Enable job post updates for company owners" ON job_posts;
  DROP POLICY IF EXISTS "Enable job post deletion for company owners" ON job_posts;
  DROP POLICY IF EXISTS "Enable job post viewing for active listings" ON job_posts;
  DROP POLICY IF EXISTS "Enable admin management of job posts" ON job_posts;
  DROP POLICY IF EXISTS "Job posts are insertable by anyone" ON job_posts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies

-- Allow anyone (public) to insert job posts
CREATE POLICY "Job posts are insertable by anyone"
  ON job_posts
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow company owners to update their own job posts
CREATE POLICY "Enable job post updates for company owners"
  ON job_posts
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  );

-- Allow company owners to delete their own job posts
CREATE POLICY "Enable job post deletion for company owners"
  ON job_posts
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  );

-- Allow viewing of active job posts and own job posts
CREATE POLICY "Enable job post viewing for active listings"
  ON job_posts
  FOR SELECT
  TO public
  USING (
    (status = 'active' AND expires_at > now())
    OR
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
    OR
    (auth.jwt()->>'role' IN ('admin', 'moderator'))
  );

-- Allow admin/moderator users to manage all job posts
CREATE POLICY "Enable admin management of job posts"
  ON job_posts
  FOR ALL
  TO authenticated
  USING (auth.jwt()->>'role' IN ('admin', 'moderator'))
  WITH CHECK (auth.jwt()->>'role' IN ('admin', 'moderator'));