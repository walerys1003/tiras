/*
  # Remove authentication tables and data

  1. Changes
    - Drop users table if exists
    - Remove admin user from auth.users
*/

-- Drop users table if exists
DROP TABLE IF EXISTS users CASCADE;

-- Remove admin user from auth.users
DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';