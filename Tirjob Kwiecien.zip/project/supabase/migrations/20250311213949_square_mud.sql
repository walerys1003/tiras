/*
  # Create auth user and link with users table

  1. Changes
    - Create auth user for admin@tirjob.pl
    - Update users table to link with auth.users
    - Add RLS policies for authentication

  2. Security
    - Enable RLS
    - Add policies for auth users
*/

-- First, create the auth user
DO $$
DECLARE
  auth_user_id uuid;
BEGIN
  -- Insert into auth.users
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token,
    email_change_token_new,
    email_change,
    last_sign_in_at
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@tirjob.pl',
    crypt('admin123', gen_salt('bf')),
    NOW(),
    NOW(),
    NOW(),
    '',
    '',
    '',
    '',
    NOW()
  )
  RETURNING id INTO auth_user_id;

  -- Update users table to link with auth user
  UPDATE users
  SET id = auth_user_id
  WHERE email = 'admin@tirjob.pl';
END $$;