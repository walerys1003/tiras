/*
  # Fix admin user setup

  1. Changes
    - Delete existing admin user from both tables to avoid conflicts
    - Create admin user in auth.users table
    - Create matching record in users table
    - Add proper error handling

  2. Security
    - Store hashed passwords
    - Ensure proper role assignment
*/

-- First, delete any existing admin user to avoid conflicts
DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';
DELETE FROM users WHERE email = 'admin@tirjob.pl';

-- Create auth user and link to users table
DO $$
DECLARE
  auth_user_id uuid;
BEGIN
  -- Insert into auth.users
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    created_at,
    updated_at
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@tirjob.pl',
    crypt('Tirjob25!', gen_salt('bf')),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    '{}',
    false,
    now(),
    now()
  )
  RETURNING id INTO auth_user_id;

  -- Insert into users table with the same id
  INSERT INTO users (id, email, name, role, password_hash)
  VALUES (
    auth_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin',
    crypt('Tirjob25!', gen_salt('bf'))
  );
END $$;