/*
  # Allow anonymous job posting

  1. Changes
    - Update RLS policies to allow anonymous users to create job listings
    - Add policies for anonymous access to companies and job_posts tables
    - Ensure data integrity with proper foreign key relationships

  2. Security
    - Allow anonymous users to create companies and job posts
    - Maintain read-only access for public job listings
    - Protect sensitive data while allowing necessary operations
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Companies are viewable by authenticated users" ON companies;
DROP POLICY IF EXISTS "Companies are insertable by authenticated users" ON companies;
DROP POLICY IF EXISTS "Companies are updatable by owners" ON companies;
DROP POLICY IF EXISTS "Job posts are viewable by everyone" ON job_posts;
DROP POLICY IF EXISTS "Job posts are insertable by authenticated users" ON job_posts;
DROP POLICY IF EXISTS "Job posts are updatable by owners" ON job_posts;

-- Create new policies for companies table
CREATE POLICY "Companies are viewable by everyone" ON companies
  FOR SELECT USING (true);

CREATE POLICY "Companies are insertable by anyone" ON companies
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Companies are updatable by company email" ON companies
  FOR UPDATE USING (
    email = current_setting('request.jwt.claims')::json->>'email'
  );

-- Create new policies for job_posts table
CREATE POLICY "Job posts are viewable by everyone" ON job_posts
  FOR SELECT USING (status = 'active' AND expires_at > NOW());

CREATE POLICY "Job posts are insertable by anyone" ON job_posts
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job posts are updatable by company email" ON job_posts
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = current_setting('request.jwt.claims')::json->>'email'
    )
  );

-- Create policies for related tables
CREATE POLICY "Job requirements are insertable by anyone" ON job_requirements
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job duties are insertable by anyone" ON job_duties
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job benefits are insertable by anyone" ON job_benefits
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job languages are insertable by anyone" ON job_languages
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Job qualifications are insertable by anyone" ON job_qualifications
  FOR INSERT WITH CHECK (true);