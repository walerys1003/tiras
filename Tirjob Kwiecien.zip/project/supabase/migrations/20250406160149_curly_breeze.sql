/*
  # Fix user role update functionality

  1. Changes
    - Add detailed logging to diagnose user update issues
    - Fix RLS policies for user management
    - Ensure proper error handling in trigger function
    - Add explicit permissions for admin users

  2. Security
    - Maintain proper role-based access control
    - Ensure admin users can manage other users
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Admin users can manage all users" ON users;
DROP POLICY IF EXISTS "Users can update their own data" ON users;
DROP POLICY IF EXISTS "Enable insert for all users" ON users;

-- Create improved policies with better logging
CREATE POLICY "Enable read access for all users"
  ON users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin users can update all users"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin'
  );

CREATE POLICY "Admin users can delete users"
  ON users
  FOR DELETE
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin'
  );

CREATE POLICY "Admin users can insert users"
  ON users
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin'
  );

CREATE POLICY "Public can insert users"
  ON users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

-- Drop existing function
DROP FUNCTION IF EXISTS sync_user_role_to_auth();

-- Create improved function to sync user role and name to auth metadata with detailed logging
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
DECLARE
  v_result RECORD;
  v_app_metadata JSONB;
  v_user_metadata JSONB;
  v_jwt_role TEXT;
  v_jwt_claims JSONB;
BEGIN
  -- Get JWT claims for debugging
  BEGIN
    v_jwt_claims := current_setting('request.jwt.claims', true)::jsonb;
    v_jwt_role := v_jwt_claims ->> 'role';
    RAISE LOG 'JWT claims: %, JWT role: %', v_jwt_claims, v_jwt_role;
  EXCEPTION WHEN OTHERS THEN
    RAISE LOG 'Error getting JWT claims: %', SQLERRM;
  END;

  -- Log the function call for debugging
  RAISE LOG 'sync_user_role_to_auth called: old_role=%, new_role=%, old_name=%, new_name=%', 
    OLD.role, NEW.role, OLD.name, NEW.name;

  -- Get current metadata
  SELECT raw_app_meta_data, raw_user_meta_data INTO v_app_metadata, v_user_metadata
  FROM auth.users
  WHERE id = NEW.id;
  
  RAISE LOG 'Current metadata for user %: app_metadata=%, user_metadata=%', 
    NEW.id, v_app_metadata, v_user_metadata;

  -- Update auth.users metadata with the new role and name
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_set(
      COALESCE(v_app_metadata, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role)
    ),
    raw_user_meta_data = jsonb_set(
      COALESCE(v_user_metadata, '{}'::jsonb),
      '{name}',
      to_jsonb(NEW.name)
    )
  WHERE id = NEW.id
  RETURNING id INTO v_result;
  
  -- Log the result
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', NEW.id;
  ELSE
    RAISE LOG 'Successfully updated auth.users for id=%', NEW.id;
    
    -- Get updated metadata for verification
    SELECT raw_app_meta_data, raw_user_meta_data INTO v_app_metadata, v_user_metadata
    FROM auth.users
    WHERE id = NEW.id;
    
    RAISE LOG 'Updated metadata for user %: app_metadata=%, user_metadata=%', 
      NEW.id, v_app_metadata, v_user_metadata;
  END IF;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in sync_user_role_to_auth: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role and name changes
CREATE TRIGGER sync_user_role_trigger
  AFTER UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Create function to log all database operations for debugging
CREATE OR REPLACE FUNCTION log_all_operations()
RETURNS TRIGGER AS $$
BEGIN
  RAISE LOG 'Operation: %, Table: %, User: %, Data: %', 
    TG_OP, 
    TG_TABLE_NAME, 
    current_setting('request.jwt.claims', true)::jsonb ->> 'email',
    row_to_json(NEW);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to log all operations on users table
CREATE TRIGGER log_users_operations
  AFTER INSERT OR UPDATE OR DELETE ON users
  FOR EACH ROW
  EXECUTE FUNCTION log_all_operations();