/*
  # Add default SEO settings to admin_settings table

  1. Changes
    - Add default SEO settings to admin_settings table
    - These settings will be used as fallbacks when no specific SEO settings are found
    - Ensure proper data for SEO optimization

  2. Security
    - Maintain existing RLS policies
*/

-- Insert or update default SEO settings
INSERT INTO admin_settings (key, value, setting_group)
VALUES 
  ('default_title', 'TirJob.pl - Portal pracy dla kierowców i specjalistów transportu', 'seo'),
  ('default_description', 'Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.', 'seo'),
  ('default_keywords', 'praca kierowca, praca transport, oferty pracy kierowca, kierowca C+E, praca spedytor', 'seo')
ON CONFLICT (key) DO UPDATE 
SET 
  value = EXCLUDED.value,
  updated_at = now();

-- Update homepage SEO settings with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "TirJob.pl - Portal pracy dla kierowców i specjalistów transportu",
  "url": "https://tirjob.pl",
  "description": "Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://tirjob.pl/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  },
  "publisher": {
    "@type": "Organization",
    "name": "TirJob.pl",
    "logo": {
      "@type": "ImageObject",
      "url": "https://i.ibb.co/7NdqLD2G/2.png",
      "width": "600",
      "height": "60"
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+48 501 42 00 42",
      "contactType": "customer service",
      "email": "kontakt@tirjob.pl"
    }
  }
}'::jsonb
WHERE page_path = '/'
AND page_type = 'home';