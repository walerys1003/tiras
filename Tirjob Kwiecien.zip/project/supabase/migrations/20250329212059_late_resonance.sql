/*
  # Fix newsletter subscribers policies

  1. Changes
    - Drop existing policies
    - Create new policies with proper role checks
    - Add policy for delete operations
    - Use raw_app_meta_data for role check

  2. Security
    - Enable RLS
    - Add proper policies for admin access
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can subscribe to newsletter" ON newsletter_subscribers;
DROP POLICY IF EXISTS "Enable read access for all users" ON newsletter_subscribers;
DROP POLICY IF EXISTS "Enable update for admin users" ON newsletter_subscribers;
DROP POLICY IF EXISTS "Enable delete for admin users" ON newsletter_subscribers;

-- Enable RLS
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscribers
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON newsletter_subscribers
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable delete for admin users"
  ON newsletter_subscribers
  FOR DELETE
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
      AND raw_app_meta_data->>'role' = 'admin'
    )
  );

-- Create index for status if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_newsletter_subscribers_status 
ON newsletter_subscribers(status);