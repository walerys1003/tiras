/*
  # Create admin users table and activity logs

  1. New Tables
    - `admin_users`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `role` (text)
      - `password_hash` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `admin_activity_logs`
      - `id` (uuid, primary key)
      - `admin_id` (uuid, foreign key)
      - `action` (text)
      - `entity_type` (text)
      - `entity_id` (uuid)
      - `details` (jsonb)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Add trigger for logging admin activity
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT admin_users_role_check CHECK (role = ANY (ARRAY['admin', 'editor']))
);

-- Create admin_activity_logs table
CREATE TABLE IF NOT EXISTS admin_activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES admin_users(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_activity_logs ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_admin_activity_logs_admin_id ON admin_activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_activity_logs_entity_type ON admin_activity_logs(entity_type);

-- Create function for logging admin activity
CREATE OR REPLACE FUNCTION log_admin_activity()
RETURNS TRIGGER AS $$
DECLARE
  v_admin_id uuid;
  v_action text;
  v_details jsonb;
BEGIN
  -- Get admin_id from current user's email
  SELECT id INTO v_admin_id
  FROM admin_users
  WHERE email = current_setting('request.jwt.claims')::json->>'email';

  -- Determine action type
  IF TG_OP = 'INSERT' THEN
    v_action := 'create';
    v_details := row_to_json(NEW)::jsonb;
  ELSIF TG_OP = 'UPDATE' THEN
    v_action := 'update';
    v_details := jsonb_build_object(
      'old', row_to_json(OLD),
      'new', row_to_json(NEW)
    );
  ELSIF TG_OP = 'DELETE' THEN
    v_action := 'delete';
    v_details := row_to_json(OLD)::jsonb;
  END IF;

  -- Insert log entry
  INSERT INTO admin_activity_logs (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    v_admin_id,
    v_action,
    TG_TABLE_NAME,
    CASE 
      WHEN TG_OP = 'DELETE' THEN OLD.id
      ELSE NEW.id
    END,
    v_details
  );

  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Drop existing trigger if exists
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_trigger
    WHERE tgname = 'log_blog_categories_activity'
  ) THEN
    DROP TRIGGER log_blog_categories_activity ON blog_categories;
  END IF;
END $$;

-- Create triggers for logging
CREATE TRIGGER log_blog_categories_activity
  AFTER INSERT OR UPDATE OR DELETE ON blog_categories
  FOR EACH ROW EXECUTE FUNCTION log_admin_activity();

-- Add policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Admin users can view own data" ON admin_users;
  DROP POLICY IF EXISTS "Admin users can update own data" ON admin_users;
  DROP POLICY IF EXISTS "Admin users can view activity logs" ON admin_activity_logs;
END $$;

CREATE POLICY "Admin users can view own data"
  ON admin_users
  FOR SELECT
  TO public
  USING (email = current_setting('request.jwt.claims')::json->>'email');

CREATE POLICY "Admin users can update own data"
  ON admin_users
  FOR UPDATE
  TO public
  USING (email = current_setting('request.jwt.claims')::json->>'email');

CREATE POLICY "Admin users can view activity logs"
  ON admin_activity_logs
  FOR SELECT
  TO public
  USING (
    current_setting('request.jwt.claims')::json->>'email' IN (
      SELECT email FROM admin_users
    )
  );

-- Insert default admin user
INSERT INTO admin_users (email, name, role, password_hash)
VALUES (
  'admin@tirjob.pl',
  'Administrator',
  'admin',
  '$2a$10$X7U.2QxO5XK8CkUz.BTXwOkK.1JZHxqHxBOe.yYzZBvCrHZBXkp6.'
) ON CONFLICT (email) DO NOTHING;