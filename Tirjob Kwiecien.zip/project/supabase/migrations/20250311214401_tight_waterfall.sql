/*
  # Update admin password

  1. Changes
    - Update admin user password to "Tirjob25!"
    - Keep existing user data and permissions
*/

-- Update admin password
DO $$
DECLARE
  auth_user_id uuid;
BEGIN
  -- Get existing auth user ID
  SELECT id INTO auth_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';

  -- Update password if user exists
  IF auth_user_id IS NOT NULL THEN
    UPDATE auth.users
    SET encrypted_password = crypt('Tirjob25!', gen_salt('bf'))
    WHERE id = auth_user_id;
  END IF;
END $$;