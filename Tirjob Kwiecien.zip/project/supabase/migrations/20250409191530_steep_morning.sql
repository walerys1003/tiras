/*
  # Fix user deletion functionality

  1. Changes
    - Create a function to delete users from auth.users table
    - Add proper RLS policies for user deletion
    - Ensure cascading delete works properly
    - Add logging for debugging

  2. Security
    - Use SECURITY DEFINER for privileged operations
    - Ensure proper role checks
*/

-- Create a function to delete users from auth.users
CREATE OR REPLACE FUNCTION delete_user_by_id(user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  v_email TEXT;
  v_role TEXT;
BEGIN
  -- Get user info for logging
  SELECT email, role INTO v_email, v_role
  FROM users
  WHERE id = user_id;
  
  -- Log the deletion attempt
  RAISE LOG 'Attempting to delete user: id=%, email=%, role=%', 
    user_id, v_email, v_role;

  -- Delete from auth.users which will cascade to users table
  DELETE FROM auth.users
  WHERE id = user_id;
  
  -- Check if deletion was successful
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = user_id) THEN
    RAISE LOG 'Successfully deleted user: id=%, email=%', user_id, v_email;
    RETURN true;
  ELSE
    RAISE LOG 'Failed to delete user: id=%, email=%', user_id, v_email;
    RETURN false;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Error in delete_user_by_id: %', SQLERRM;
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Ensure the users table has ON DELETE CASCADE for auth.users
DO $$
BEGIN
  -- First drop the existing foreign key constraint if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'users_id_fkey' 
    AND table_name = 'users'
  ) THEN
    ALTER TABLE users DROP CONSTRAINT users_id_fkey;
  END IF;

  -- Add the foreign key constraint with ON DELETE CASCADE
  ALTER TABLE users 
  ADD CONSTRAINT users_id_fkey 
  FOREIGN KEY (id) 
  REFERENCES auth.users(id) 
  ON DELETE CASCADE;
END $$;

-- Create or update RLS policy for admin users to delete users
DO $$
BEGIN
  DROP POLICY IF EXISTS "Admin users can delete users" ON users;
  
  CREATE POLICY "Admin users can delete users"
    ON users
    FOR DELETE
    TO authenticated
    USING (
      ((current_setting('request.jwt.claims'::text, true))::json ->> 'role'::text) = 'admin'::text
    );
END $$;