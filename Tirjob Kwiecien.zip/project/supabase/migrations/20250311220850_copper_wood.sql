/*
  # Add admin user to users table

  1. Changes
    - Insert admin user into users table
*/

-- Insert admin user
INSERT INTO users (
  email,
  name,
  role,
  password_hash
)
VALUES (
  'admin@tirjob.pl',
  'Administrator',
  'admin',
  crypt('Tirjob25!', gen_salt('bf'))
)
ON CONFLICT (email) DO UPDATE SET
  name = EXCLUDED.name,
  role = EXCLUDED.role,
  password_hash = EXCLUDED.password_hash;