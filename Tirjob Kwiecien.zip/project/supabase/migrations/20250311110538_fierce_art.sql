/*
  # Update newsletter subscribers table

  1. Changes
    - Create table if not exists with status check constraint
    - Enable RLS
    - Create admin view policy with existence check
    - Add status index

  Note: Added DO block to check for existing policy before creation
*/

-- Create newsletter_subscribers table
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT newsletter_subscribers_status_check CHECK (status = ANY (ARRAY['active', 'unsubscribed']))
);

-- Enable Row Level Security
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- Create policy for admin view if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'newsletter_subscribers' 
    AND policyname = 'Admin users can view newsletter subscribers'
  ) THEN
    CREATE POLICY "Admin users can view newsletter subscribers"
      ON newsletter_subscribers
      FOR SELECT
      TO public
      USING (
        ((current_setting('request.jwt.claims'::text))::json ->> 'email'::text) IN (
          SELECT email FROM admin_users
        )
      );
  END IF;
END
$$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_newsletter_subscribers_status ON newsletter_subscribers(status);