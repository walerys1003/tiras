/*
  # Fix user role update functionality

  1. Changes
    - Create a new edge function to update user roles
    - Add more detailed logging to the sync_user_role_to_auth function
    - Ensure proper error handling
    - Fix RLS policies for user management

  2. Security
    - Maintain proper role-based access control
    - Ensure admin users can manage other users
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

-- Drop existing function
DROP FUNCTION IF EXISTS sync_user_role_to_auth();

-- Create improved function to sync user role and name to auth metadata with detailed logging
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
DECLARE
  v_result RECORD;
  v_app_metadata JSONB;
  v_user_metadata JSONB;
BEGIN
  -- Log the function call for debugging
  RAISE LOG 'sync_user_role_to_auth called: old_role=%, new_role=%, old_name=%, new_name=%', 
    OLD.role, NEW.role, OLD.name, NEW.name;

  -- Get current metadata
  SELECT raw_app_meta_data, raw_user_meta_data INTO v_app_metadata, v_user_metadata
  FROM auth.users
  WHERE id = NEW.id;
  
  RAISE LOG 'Current metadata for user %: app_metadata=%, user_metadata=%', 
    NEW.id, v_app_metadata, v_user_metadata;

  -- Update auth.users metadata with the new role and name
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_set(
      COALESCE(v_app_metadata, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role)
    ),
    raw_user_meta_data = jsonb_set(
      COALESCE(v_user_metadata, '{}'::jsonb),
      '{name}',
      to_jsonb(NEW.name)
    )
  WHERE id = NEW.id
  RETURNING id INTO v_result;
  
  -- Log the result
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', NEW.id;
  ELSE
    RAISE LOG 'Successfully updated auth.users for id=%', NEW.id;
    
    -- Get updated metadata for verification
    SELECT raw_app_meta_data, raw_user_meta_data INTO v_app_metadata, v_user_metadata
    FROM auth.users
    WHERE id = NEW.id;
    
    RAISE LOG 'Updated metadata for user %: app_metadata=%, user_metadata=%', 
      NEW.id, v_app_metadata, v_user_metadata;
  END IF;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in sync_user_role_to_auth: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role and name changes
CREATE TRIGGER sync_user_role_trigger
  AFTER UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Ensure all existing users have proper metadata
DO $$
DECLARE
  user_record RECORD;
  v_app_metadata JSONB;
  v_user_metadata JSONB;
BEGIN
  FOR user_record IN SELECT * FROM users
  LOOP
    -- Get current metadata
    SELECT raw_app_meta_data, raw_user_meta_data INTO v_app_metadata, v_user_metadata
    FROM auth.users
    WHERE id = user_record.id;
    
    -- Update auth.users metadata
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(v_app_metadata, '{}'::jsonb),
        '{role}',
        to_jsonb(user_record.role)
      ),
      raw_user_meta_data = jsonb_set(
        COALESCE(v_user_metadata, '{}'::jsonb),
        '{name}',
        to_jsonb(user_record.name)
      )
    WHERE id = user_record.id;
  END LOOP;
END $$;