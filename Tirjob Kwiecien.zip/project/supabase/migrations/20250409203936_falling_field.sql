/*
  # Update SEO settings for jobs path

  1. Changes
    - Update the page_path for job listings from '/jobs' to '/oferty-pracy'
    - Keep all other SEO settings the same
    - Ensure proper Polish language URL structure

  2. Security
    - Maintain existing RLS policies
*/

-- Update the page path for job listings
UPDATE seo_settings
SET page_path = '/oferty-pracy'
WHERE page_path = '/jobs';

-- Insert SEO settings for job detail pages if they don't exist
INSERT INTO seo_settings (page_path, page_type, title, description, keywords, og_title, og_description, og_image, og_type, schema_org)
VALUES 
  ('/oferty-pracy/:id', 'job-detail', 'Oferta pracy - TirJob.pl',
   'Szczegóły oferty pracy w branży transportowej. Sprawdź wymagania, obowiązki i benefity oferowane przez pracodawcę.',
   'oferta pracy, praca kierowca, praca transport, kierowca C+E, spedytor, logistyk',
   'Oferta pracy - TirJob.pl',
   'Szczegóły oferty pracy w branży transportowej. Sprawdź wymagania, obowiązki i benefity oferowane przez pracodawcę.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "JobPosting",
     "title": "Oferta pracy w branży transportowej",
     "description": "Szczegóły oferty pracy",
     "datePosted": "2025-04-10",
     "employmentType": "FULL_TIME",
     "hiringOrganization": {
       "@type": "Organization",
       "name": "TirJob.pl",
       "sameAs": "https://tirjob.pl"
     },
     "jobLocation": {
       "@type": "Place",
       "address": {
         "@type": "PostalAddress",
         "addressCountry": "PL"
       }
     }
   }'::jsonb)
ON CONFLICT (page_path) DO UPDATE SET
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  keywords = EXCLUDED.keywords,
  og_title = EXCLUDED.og_title,
  og_description = EXCLUDED.og_description,
  og_image = EXCLUDED.og_image,
  og_type = EXCLUDED.og_type,
  schema_org = EXCLUDED.schema_org;