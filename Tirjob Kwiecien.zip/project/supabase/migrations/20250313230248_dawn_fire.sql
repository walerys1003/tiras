/*
  # Add sample job posts with location data

  1. Changes
    - Add sample job posts with different locations
    - Include various countries and cities
    - Set proper expiration dates
    - Add all required related data
*/

-- Insert sample companies if they don't exist
INSERT INTO companies (id, name, email, phone)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'Trans Europa Sp. z o.o.', 'kontakt@transeuropa.pl', '+48 501 234 567'),
  ('22222222-2222-2222-2222-222222222222', 'German Logistics GmbH', 'info@germanlog.de', '+49 176 1234567'),
  ('33333333-3333-3333-3333-333333333333', 'French Transport SARL', 'contact@frenchtransport.fr', '+33 6 12 34 56 78'),
  ('44444444-4444-4444-4444-444444444444', 'Dutch Cargo B.V.', 'info@dutchcargo.nl', '+31 6 12345678'),
  ('55555555-5555-5555-5555-555555555555', 'Belgian Transport NV', 'info@belgiantransport.be', '+32 470 123456')
ON CONFLICT (id) DO NOTHING;

-- Insert sample job posts
INSERT INTO job_posts (
  company_id,
  title,
  position_category,
  position_type,
  work_type,
  country,
  voivodeship,
  city,
  trailer_type,
  schedule,
  salary_amount,
  salary_currency,
  salary_type,
  is_premium,
  expires_at,
  status
)
VALUES
  -- Polish jobs
  (
    '11111111-1111-1111-1111-111111111111',
    'Kierowca C+E – Transport krajowy',
    'drivers',
    'kat. C+E',
    'domestic',
    'Polska',
    'Mazowieckie',
    'Warszawa',
    'Plandeka',
    '2/1',
    8000,
    'PLN',
    'netto',
    true,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- German jobs
  (
    '22222222-2222-2222-2222-222222222222',
    'Kierowca C+E – Transport międzynarodowy',
    'drivers',
    'kat. C+E',
    'international',
    'Niemcy',
    NULL,
    'Berlin',
    'Plandeka',
    '3/1',
    3000,
    'EUR',
    'netto',
    true,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- French jobs
  (
    '33333333-3333-3333-3333-333333333333',
    'Kierowca C+E – Transport międzynarodowy',
    'drivers',
    'kat. C+E',
    'international',
    'Francja',
    NULL,
    'Paris',
    'Plandeka',
    '3/1',
    2800,
    'EUR',
    'netto',
    true,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- Dutch jobs
  (
    '44444444-4444-4444-4444-444444444444',
    'Kierowca C+E – Transport międzynarodowy',
    'drivers',
    'kat. C+E',
    'international',
    'Holandia',
    NULL,
    'Amsterdam',
    'Chłodnia',
    '4/1',
    3200,
    'EUR',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- Belgian jobs
  (
    '55555555-5555-5555-5555-555555555555',
    'Kierowca C+E – Transport międzynarodowy',
    'drivers',
    'kat. C+E',
    'international',
    'Belgia',
    NULL,
    'Brussels',
    'Plandeka',
    '3/1',
    3100,
    'EUR',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  );

-- Add job requirements
INSERT INTO job_requirements (job_post_id, experience)
SELECT id, '2y'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

-- Add job languages
INSERT INTO job_languages (job_post_id, language)
SELECT id, 'Polski'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

-- Add additional languages for international jobs
INSERT INTO job_languages (job_post_id, language)
SELECT id, 
  CASE 
    WHEN country = 'Niemcy' THEN 'Niemiecki'
    WHEN country = 'Francja' THEN 'Francuski'
    WHEN country = 'Holandia' THEN 'Holenderski'
    WHEN country = 'Belgia' THEN 'Francuski'
    ELSE 'Angielski'
  END
FROM job_posts
WHERE work_type = 'international'
AND created_at >= NOW() - INTERVAL '1 minute';

-- Add job qualifications
INSERT INTO job_qualifications (job_post_id, qualification)
SELECT id, 'Karta kierowcy'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

-- Add job duties
INSERT INTO job_duties (job_post_id, duty)
SELECT id, 'Transport towarów zgodnie z wyznaczoną trasą'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

-- Add job benefits
INSERT INTO job_benefits (job_post_id, benefit)
SELECT id, 'Atrakcyjne wynagrodzenie'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';