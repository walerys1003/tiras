/*
  # Fix admin authentication session handling

  1. Changes
    - Update admin_users table structure
    - Add more reliable session handling policies
    - Ensure proper JWT claims access
    - Add necessary indexes

  2. Security
    - Enable RLS
    - Add proper policies for authenticated access
*/

-- Drop existing table and policies
DROP TABLE IF EXISTS admin_users CASCADE;

-- Create admin_users table
CREATE TABLE admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT admin_users_role_check CHECK (role = ANY (ARRAY['admin', 'editor']))
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admin users can view data"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (
    auth.jwt()->>'email' IN (
      SELECT email FROM admin_users
    )
  );

CREATE POLICY "Admin users can update own data"
  ON admin_users
  FOR UPDATE
  TO authenticated
  USING (
    auth.jwt()->>'email' = email
  );

-- Create indexes
CREATE INDEX idx_admin_users_email ON admin_users(email);
CREATE INDEX idx_admin_users_role ON admin_users(role);

-- Insert default admin user
INSERT INTO admin_users (email, name, role)
VALUES (
  'admin@tirjob.pl',
  'Administrator',
  'admin'
) ON CONFLICT (email) 
DO UPDATE SET
  name = EXCLUDED.name,
  role = EXCLUDED.role;