/*
  # Add blog tables and sample data

  1. New Tables
    - `blog_categories` - Blog post categories
      - `id` (uuid, primary key)
      - `title` (text)
      - `slug` (text, unique)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `blog_posts` - Blog posts
      - `id` (uuid, primary key)
      - `title` (text)
      - `slug` (text, unique)
      - `content` (text)
      - `excerpt` (text)
      - `category_id` (uuid, foreign key)
      - `status` (text)
      - `author_id` (uuid)
      - `published_at` (timestamptz)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for public viewing
    - Add policies for admin management
*/

-- Drop existing policies if they exist
DO $$
BEGIN
  DROP POLICY IF EXISTS "Anyone can view blog categories" ON blog_categories;
  DROP POLICY IF EXISTS "Anyone can view published blog posts" ON blog_posts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create blog_categories table if it doesn't exist
CREATE TABLE IF NOT EXISTS blog_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create blog_posts table if it doesn't exist
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  content text NOT NULL,
  excerpt text,
  category_id uuid REFERENCES blog_categories(id),
  status text NOT NULL DEFAULT 'draft',
  author_id uuid,
  published_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT blog_posts_status_check CHECK (status = ANY (ARRAY['draft', 'published']))
);

-- Enable RLS
ALTER TABLE blog_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX IF NOT EXISTS blog_categories_slug_key ON blog_categories(slug);
CREATE INDEX IF NOT EXISTS blog_posts_slug_key ON blog_posts(slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_author_id ON blog_posts(author_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_category_id ON blog_posts(category_id);
CREATE INDEX IF NOT EXISTS idx_blog_posts_published_at ON blog_posts(published_at);
CREATE INDEX IF NOT EXISTS idx_blog_posts_status ON blog_posts(status);

-- Create policies
CREATE POLICY "Anyone can view blog categories" 
  ON blog_categories
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view published blog posts" 
  ON blog_posts
  FOR SELECT
  TO public
  USING (status = 'published');

-- Insert sample categories if they don't exist
INSERT INTO blog_categories (title, slug, description)
SELECT * FROM (VALUES
  ('Porady dla kandydatów', 'porady-dla-kandydatow', 'Wskazówki i porady dla kierowców i specjalistów transportu'),
  ('Porady dla pracodawców', 'porady-dla-pracodawcow', 'Informacje dla firm transportowych i spedycyjnych'),
  ('Trendy w branży', 'trendy-w-branzy', 'Najnowsze trendy i zmiany w branży transportowej'),
  ('Wydarzenia i szkolenia', 'wydarzenia-i-szkolenia', 'Informacje o wydarzeniach i szkoleniach branżowych'),
  ('Edukacja i rozwój zawodowy', 'edukacja-i-rozwoj', 'Materiały edukacyjne i porady rozwojowe'),
  ('Innowacje i przyszłość transportu', 'innowacje', 'Nowe technologie i rozwiązania w transporcie')
) AS v(title, slug, description)
WHERE NOT EXISTS (
  SELECT 1 FROM blog_categories WHERE slug = v.slug
);

-- Insert sample blog posts if they don't exist
WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Jak negocjować lepsze warunki zatrudnienia jako kierowca zawodowy?',
  'jak-negocjowac-lepsze-warunki-zatrudnienia',
  '# Jak negocjować lepsze warunki zatrudnienia

W dynamicznie zmieniającym się rynku transportowym, gdzie konkurencja o dobrych kierowców jest coraz większa, umiejętność negocjacji warunków zatrudnienia staje się kluczowa dla rozwoju Twojej kariery zawodowej.

## Przygotowanie do negocjacji

1. Zbierz informacje o:
   - Aktualnych stawkach rynkowych
   - Standardach zatrudnienia
   - Sytuacji finansowej pracodawcy
   - Swoich mocnych stronach

## Kluczowe aspekty do negocjacji

- System wynagradzania
- System pracy (2/1, 3/1, 4/2)
- Dodatkowe benefity
- Wybór tras

## Podsumowanie

Pamiętaj, że negocjacje to nie konflikt, lecz poszukiwanie rozwiązania korzystnego dla obu stron.',
  'Poznaj skuteczne techniki negocjacyjne, które pomogą Ci uzyskać lepsze wynagrodzenie i korzystniejsze warunki pracy.',
  id,
  'published',
  now()
FROM category_ids
WHERE slug = 'porady-dla-kandydatow'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'jak-negocjowac-lepsze-warunki-zatrudnienia'
);

WITH category_ids AS (
  SELECT id, slug FROM blog_categories
)
INSERT INTO blog_posts (
  title,
  slug,
  content,
  excerpt,
  category_id,
  status,
  published_at
)
SELECT
  'Elektryczne ciężarówki - rewolucja na europejskich drogach?',
  'elektryczne-ciezarowki-rewolucja',
  '# Elektryczne ciężarówki - przyszłość transportu

Elektryfikacja transportu ciężkiego to jeden z najgorętszych tematów w branży TSL. Sprawdź, jak zmieni się transport drogowy w najbliższych latach.

## Obecny stan technologii

- Zasięg: 200-800 km
- Czas ładowania: 45 min - 4h
- Dostępne modele i producenci

## Zalety i wyzwania

### Zalety:
- Niższe koszty eksploatacji
- Zero emisji
- Cicha praca

### Wyzwania:
- Infrastruktura ładowania
- Zasięg
- Początkowe koszty

## Perspektywy rozwoju

Prognozowany udział w rynku i kierunki rozwoju technologii.',
  'Analizujemy obecny stan rozwoju elektrycznych pojazdów ciężarowych oraz perspektywy ich wdrożenia w europejskiej branży transportowej.',
  id,
  'published',
  now()
FROM category_ids
WHERE slug = 'innowacje'
AND NOT EXISTS (
  SELECT 1 FROM blog_posts WHERE slug = 'elektryczne-ciezarowki-rewolucja'
);