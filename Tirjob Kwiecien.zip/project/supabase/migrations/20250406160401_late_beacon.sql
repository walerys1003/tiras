/*
  # Fix user edit functionality

  1. Changes
    - Create a direct function to update user role and name
    - Add service role function to bypass RLS
    - Fix trigger function to properly update auth metadata
    - Add detailed logging for troubleshooting

  2. Security
    - Maintain proper role-based access control
    - Use security definer for privileged operations
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

-- Drop existing function
DROP FUNCTION IF EXISTS sync_user_role_to_auth();

-- Create improved function to sync user role and name to auth metadata
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
DECLARE
  v_result RECORD;
BEGIN
  -- Log the function call for debugging
  RAISE LOG 'sync_user_role_to_auth called: old_role=%, new_role=%, old_name=%, new_name=%', 
    OLD.role, NEW.role, OLD.name, NEW.name;

  -- Direct update to auth.users without using jsonb_set
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_build_object(
      'provider', COALESCE(raw_app_meta_data->>'provider', 'email'),
      'providers', COALESCE(raw_app_meta_data->'providers', '["email"]'::jsonb),
      'role', NEW.role
    ),
    raw_user_meta_data = jsonb_build_object(
      'name', NEW.name
    )
  WHERE id = NEW.id
  RETURNING id INTO v_result;
  
  -- Log the result
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', NEW.id;
  ELSE
    RAISE LOG 'Successfully updated auth.users for id=%', NEW.id;
  END IF;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in sync_user_role_to_auth: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role and name changes
CREATE TRIGGER sync_user_role_trigger
  AFTER UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Create a direct function to update user role and name
CREATE OR REPLACE FUNCTION update_user_with_metadata(
  user_id UUID,
  user_name TEXT,
  user_role TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  v_result RECORD;
BEGIN
  -- Log the function call
  RAISE LOG 'update_user_with_metadata called: id=%, name=%, role=%', 
    user_id, user_name, user_role;

  -- Update users table
  UPDATE users
  SET 
    name = user_name,
    role = user_role,
    updated_at = now()
  WHERE id = user_id
  RETURNING id INTO v_result;
  
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update users table for id=%', user_id;
    RETURN false;
  END IF;
  
  -- Directly update auth.users
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_build_object(
      'provider', COALESCE(raw_app_meta_data->>'provider', 'email'),
      'providers', COALESCE(raw_app_meta_data->'providers', '["email"]'::jsonb),
      'role', user_role
    ),
    raw_user_meta_data = jsonb_build_object(
      'name', user_name
    )
  WHERE id = user_id
  RETURNING id INTO v_result;
  
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', user_id;
    RETURN false;
  END IF;
  
  RAISE LOG 'Successfully updated user and metadata for id=%', user_id;
  RETURN true;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Error in update_user_with_metadata: %', SQLERRM;
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;