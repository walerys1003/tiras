/*
  # Remove admin tables and related objects

  1. Changes
    - Drop admin_users table and related objects
    - Drop admin_activity_logs table and related objects
    - Remove all admin-related policies and triggers
*/

-- Drop admin tables if they exist
DROP TABLE IF EXISTS admin_users CASCADE;
DROP TABLE IF EXISTS admin_activity_logs CASCADE;

-- Drop admin-related functions if they exist
DROP FUNCTION IF EXISTS log_admin_activity CASCADE;