/*
  # Improve admin authentication

  1. Changes
    - Add more permissive RLS policy for admin users table
    - Ensure proper email check in policies
    - Add index for performance

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Ensure proper authentication checks
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admin users can view own data" ON admin_users;
DROP POLICY IF EXISTS "Admin users can update own data" ON admin_users;

-- Create more permissive select policy
CREATE POLICY "Admin users can view own data"
  ON admin_users
  FOR SELECT
  TO public
  USING (true);

-- Create update policy
CREATE POLICY "Admin users can update own data"
  ON admin_users
  FOR UPDATE
  TO public
  USING (
    email = current_setting('request.jwt.claims', true)::json->>'email'
  );

-- Ensure admin user exists
INSERT INTO admin_users (email, name, role)
VALUES (
  'admin@tirjob.pl',
  'Administrator',
  'admin'
) ON CONFLICT (email) 
DO UPDATE SET
  name = EXCLUDED.name,
  role = EXCLUDED.role;