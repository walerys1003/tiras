/*
  # Fix job post update trigger to allow inserts

  1. Changes
    - Modify check_job_post_update function to explicitly handle INSERT operations
    - Ensure trigger only fires on UPDATE operations, not INSERT
    - Keep existing RLS policies intact
    - Fix comparison logic to handle NULL values properly

  2. Security
    - Maintain existing security model
    - Allow public users to create job posts
    - Restrict field updates for non-admin users
*/

-- Drop existing trigger
DROP TRIGGER IF EXISTS check_job_post_update_trigger ON job_posts;

-- Recreate the trigger function with proper INSERT handling
CREATE OR REPLACE FUNCTION check_job_post_update()
RETURNS TRIGGER AS $$
BEGIN
  -- Skip all checks for INSERT operations
  IF (TG_OP = 'INSERT') THEN
    RETURN NEW;
  END IF;

  -- For UPDATE operations, check if critical fields are being changed
  IF (
    (OLD.title IS DISTINCT FROM NEW.title) OR
    (OLD.position_category IS DISTINCT FROM NEW.position_category) OR
    (OLD.position_type IS DISTINCT FROM NEW.position_type) OR
    (OLD.work_type IS DISTINCT FROM NEW.work_type) OR
    (OLD.country_id IS DISTINCT FROM NEW.country_id) OR
    (OLD.city_id IS DISTINCT FROM NEW.city_id) OR
    (OLD.trailer_type IS DISTINCT FROM NEW.trailer_type) OR
    (OLD.schedule IS DISTINCT FROM NEW.schedule) OR
    (OLD.salary_amount IS DISTINCT FROM NEW.salary_amount) OR
    (OLD.salary_currency IS DISTINCT FROM NEW.salary_currency) OR
    (OLD.salary_type IS DISTINCT FROM NEW.salary_type) OR
    (OLD.is_premium IS DISTINCT FROM NEW.is_premium) OR
    (OLD.expires_at IS DISTINCT FROM NEW.expires_at) OR
    (OLD.company_id IS DISTINCT FROM NEW.company_id)
  ) THEN
    -- If any of these fields are changed, check if user is admin/moderator
    IF (
      ((current_setting('request.jwt.claims'::text, true))::json ->> 'role'::text) = 'admin'::text OR
      ((current_setting('request.jwt.claims'::text, true))::json ->> 'role'::text) = 'moderator'::text
    ) THEN
      -- Allow admins and moderators to update all fields
      RETURN NEW;
    ELSE
      -- For regular users, only allow updating payment_status and status
      RAISE EXCEPTION 'Only payment_status and status fields can be updated';
    END IF;
  END IF;
  
  -- If we get here, only payment_status and status are being updated, so allow it
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in check_job_post_update: %', SQLERRM;
  -- Re-raise the exception
  RAISE;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to enforce update restrictions (ONLY for UPDATE operations)
CREATE TRIGGER check_job_post_update_trigger
  BEFORE UPDATE ON job_posts
  FOR EACH ROW
  EXECUTE FUNCTION check_job_post_update();