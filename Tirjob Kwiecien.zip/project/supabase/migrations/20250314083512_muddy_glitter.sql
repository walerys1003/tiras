/*
  # Add location tables and migrate data

  1. New Tables
    - `job_countries`
      - `id` (uuid, primary key)
      - `country_name` (text)
      - `created_at` (timestamptz)

    - `job_cities`
      - `id` (uuid, primary key)
      - `city_name` (text)
      - `country_id` (uuid, foreign key)
      - `created_at` (timestamptz)

  2. Changes
    - Add new columns to job_posts
    - Migrate existing location data
    - Update foreign key constraints
    - Update RLS policies

  3. Security
    - Enable RLS
    - Add policies for data access
*/

-- Create job_countries table
CREATE TABLE job_countries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_name text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- Create job_cities table
CREATE TABLE job_cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  city_name text NOT NULL,
  country_id uuid NOT NULL REFERENCES job_countries(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(city_name, country_id)
);

-- Enable RLS
ALTER TABLE job_countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE job_cities ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view countries"
  ON job_countries
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view cities"
  ON job_cities
  FOR SELECT
  TO public
  USING (true);

-- Create indexes
CREATE INDEX idx_job_cities_country_id ON job_cities(country_id);
CREATE INDEX idx_job_cities_city_name ON job_cities(city_name);
CREATE INDEX idx_job_countries_country_name ON job_countries(country_name);

-- Add temporary columns to job_posts
ALTER TABLE job_posts ADD COLUMN temp_country_id uuid;
ALTER TABLE job_posts ADD COLUMN temp_city_id uuid;

-- Migrate existing data
DO $$
DECLARE
  job_record RECORD;
  v_country_id uuid;
  v_city_id uuid;
BEGIN
  -- First, insert all unique countries
  INSERT INTO job_countries (country_name)
  SELECT DISTINCT country
  FROM job_posts
  WHERE country IS NOT NULL
  ON CONFLICT (country_name) DO NOTHING;

  -- Then, insert all unique cities with their country relationships
  FOR job_record IN SELECT DISTINCT country, city FROM job_posts WHERE country IS NOT NULL AND city IS NOT NULL
  LOOP
    -- Get country_id
    SELECT id INTO v_country_id
    FROM job_countries
    WHERE country_name = job_record.country;

    -- Insert city if it doesn't exist
    INSERT INTO job_cities (city_name, country_id)
    VALUES (job_record.city, v_country_id)
    ON CONFLICT (city_name, country_id) DO NOTHING
    RETURNING id INTO v_city_id;

    -- If city already existed, get its id
    IF v_city_id IS NULL THEN
      SELECT id INTO v_city_id
      FROM job_cities
      WHERE city_name = job_record.city AND country_id = v_country_id;
    END IF;

    -- Update job_posts with the new IDs
    UPDATE job_posts
    SET 
      temp_country_id = v_country_id,
      temp_city_id = v_city_id
    WHERE country = job_record.country AND city = job_record.city;
  END LOOP;
END $$;

-- Update columns one at a time to avoid syntax errors
ALTER TABLE job_posts DROP COLUMN country;
ALTER TABLE job_posts DROP COLUMN city;
ALTER TABLE job_posts ALTER COLUMN temp_country_id SET NOT NULL;
ALTER TABLE job_posts ALTER COLUMN temp_city_id SET NOT NULL;
ALTER TABLE job_posts RENAME COLUMN temp_country_id TO country_id;
ALTER TABLE job_posts RENAME COLUMN temp_city_id TO city_id;
ALTER TABLE job_posts ADD CONSTRAINT fk_job_posts_country FOREIGN KEY (country_id) REFERENCES job_countries(id);
ALTER TABLE job_posts ADD CONSTRAINT fk_job_posts_city FOREIGN KEY (city_id) REFERENCES job_cities(id);

-- Create indexes for the new columns
CREATE INDEX idx_job_posts_country_id ON job_posts(country_id);
CREATE INDEX idx_job_posts_city_id ON job_posts(city_id);