/*
  # Fix user deletion cascade with a direct approach

  1. Changes
    - Create a function to handle user deletion directly
    - Add a trigger to auth.users to delete corresponding users table entries
    - This avoids the need to modify the foreign key constraint

  2. Security
    - Maintain existing security model
    - Ensure proper cascading deletion
*/

-- Create a function to handle auth user deletion
CREATE OR REPLACE FUNCTION handle_auth_user_deletion()
RETURNS TRIGGER AS $$
BEGIN
  -- Log the deletion
  RAISE LOG 'Auth user deleted: id=%, email=%', 
    OLD.id, 
    OLD.email;
    
  -- Delete the corresponding record from users table
  DELETE FROM users WHERE id = OLD.id;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger on auth.users to handle deletions
DO $$
BEGIN
  DROP TRIGGER IF EXISTS on_auth_user_deleted ON auth.users;
  
  CREATE TRIGGER on_auth_user_deleted
    AFTER DELETE ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION handle_auth_user_deletion();
END $$;

-- Create a function to log user deletions
CREATE OR REPLACE FUNCTION log_user_deletion()
RETURNS TRIGGER AS $$
BEGIN
  RAISE LOG 'User deleted from users table: id=%, email=%, role=%', 
    OLD.id, 
    OLD.email,
    OLD.role;
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to log user deletions
DO $$
BEGIN
  DROP TRIGGER IF EXISTS log_user_deletion_trigger ON users;
  
  CREATE TRIGGER log_user_deletion_trigger
    BEFORE DELETE ON users
    FOR EACH ROW
    EXECUTE FUNCTION log_user_deletion();
END $$;

-- Create a function to update user with metadata in one transaction
CREATE OR REPLACE FUNCTION update_user_with_metadata(
  user_id UUID,
  user_name TEXT,
  user_role TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
  v_result RECORD;
BEGIN
  -- Log the function call
  RAISE LOG 'update_user_with_metadata called: id=%, name=%, role=%', 
    user_id, user_name, user_role;

  -- Update users table
  UPDATE users
  SET 
    name = user_name,
    role = user_role,
    updated_at = now()
  WHERE id = user_id
  RETURNING id INTO v_result;
  
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update users table for id=%', user_id;
    RETURN false;
  END IF;
  
  -- Directly update auth.users
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_build_object(
      'provider', COALESCE(raw_app_meta_data->>'provider', 'email'),
      'providers', COALESCE(raw_app_meta_data->'providers', '["email"]'::jsonb),
      'role', user_role
    ),
    raw_user_meta_data = jsonb_build_object(
      'name', user_name
    )
  WHERE id = user_id
  RETURNING id INTO v_result;
  
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', user_id;
    RETURN false;
  END IF;
  
  RAISE LOG 'Successfully updated user and metadata for id=%', user_id;
  RETURN true;
EXCEPTION WHEN OTHERS THEN
  RAISE LOG 'Error in update_user_with_metadata: %', SQLERRM;
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;