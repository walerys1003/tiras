/*
  # Add RLS policies for newsletter subscribers

  1. Changes
    - Add RLS policies for newsletter_subscribers table
    - Allow admin users to view all subscribers
    - Allow public users to subscribe
    - Add index for performance

  2. Security
    - Enable RLS
    - Add proper policies for data access
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can subscribe to newsletter" ON newsletter_subscribers;
DROP POLICY IF EXISTS "Admin users can view subscribers" ON newsletter_subscribers;

-- Enable RLS
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscribers
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Admin users can view subscribers"
  ON newsletter_subscribers
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
      AND raw_app_meta_data->>'role' = 'admin'
    )
  );

-- Create index for status if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_newsletter_subscribers_status 
ON newsletter_subscribers(status);