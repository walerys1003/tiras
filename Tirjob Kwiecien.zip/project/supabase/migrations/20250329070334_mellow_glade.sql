/*
  # Fix users table RLS policies

  1. Changes
    - Drop existing policies that cause recursion
    - Create new simplified policies
    - Add public policy for email checks
    - Maintain data security

  2. Security
    - Enable RLS
    - Add proper policies for data access
    - Prevent infinite recursion
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own data" ON users;
DROP POLICY IF EXISTS "Users can update own data" ON users;
DROP POLICY IF EXISTS "Admins can view all users" ON users;
DROP POLICY IF EXISTS "Admins can update all users" ON users;

-- Create new simplified policies
CREATE POLICY "Enable read access for all users"
  ON users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable update for users based on email"
  ON users
  FOR UPDATE
  TO public
  USING (
    email = current_setting('request.jwt.claims', true)::json->>'email'
  );