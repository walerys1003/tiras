/*
  # Create admin_settings table

  1. New Tables
    - `admin_settings` - Stores system settings
      - `id` (uuid, primary key)
      - `key` (text, unique) - Setting key
      - `value` (text) - Setting value
      - `setting_group` (text) - Setting group (contact, social, etc.)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Ensure proper data integrity
*/

-- Create admin_settings table
CREATE TABLE IF NOT EXISTS admin_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text,
  setting_group text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admin users can manage settings"
  ON admin_settings
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role') = 'admin'
  )
  WITH CHECK (
    (auth.jwt() ->> 'role') = 'admin'
  );

CREATE POLICY "Anyone can view settings"
  ON admin_settings
  FOR SELECT
  TO public
  USING (true);

-- Create indexes
CREATE INDEX idx_admin_settings_key ON admin_settings(key);
CREATE INDEX idx_admin_settings_group ON admin_settings(setting_group);

-- Create function for updating updated_at
CREATE OR REPLACE FUNCTION update_admin_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating updated_at
CREATE TRIGGER update_admin_settings_updated_at
  BEFORE UPDATE ON admin_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_admin_settings_updated_at();

-- Insert default settings
INSERT INTO admin_settings (key, value, setting_group)
VALUES 
  -- Contact settings
  ('contact_email', 'kontakt@tirjob.pl', 'contact'),
  ('contact_phone', '+48 501 42 00 42', 'contact'),
  ('company_address', 'ul. Świeradowska 47\n02-662 Warszawa', 'contact'),
  
  -- Social media settings
  ('facebook_url', 'https://facebook.com/tirjob', 'social'),
  ('linkedin_url', 'https://linkedin.com/company/tirjob', 'social'),
  ('instagram_url', 'https://instagram.com/tirjob.pl', 'social'),
  
  -- Recruitment settings
  ('job_post_duration', '60', 'recruitment'),
  ('job_post_price', '500', 'recruitment'),
  ('job_post_premium_price', '750', 'recruitment'),
  
  -- SEO settings
  ('default_title', 'TirJob.pl - Portal pracy dla kierowców i specjalistów transportu', 'seo'),
  ('default_description', 'Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.', 'seo'),
  ('default_keywords', 'praca kierowca, praca transport, oferty pracy kierowca, kierowca C+E, praca spedytor', 'seo'),
  
  -- Branding settings
  ('logo_url', 'https://i.ibb.co/7NdqLD2G/2.png', 'branding'),
  ('favicon_url', '/vite.svg', 'branding'),
  ('primary_color', '#e11d48', 'branding')
ON CONFLICT (key) DO UPDATE 
SET 
  value = EXCLUDED.value,
  updated_at = now();