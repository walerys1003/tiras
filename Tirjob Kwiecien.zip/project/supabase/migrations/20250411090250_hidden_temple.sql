/*
  # Fix job posts RLS policies

  1. Changes
    - Add proper RLS policies for job posts table
    - Allow authenticated users to create job posts
    - Ensure company-user relationship is properly handled

  2. Security
    - Enable RLS
    - Add policies for proper access control
    - Maintain data integrity
*/

-- Drop existing policies
DO $$
BEGIN
  DROP POLICY IF EXISTS "Job posts are insertable by anyone" ON job_posts;
  DROP POLICY IF EXISTS "Job posts are updatable by company email" ON job_posts;
  DROP POLICY IF EXISTS "Job posts are viewable by everyone" ON job_posts;
  DROP POLICY IF EXISTS "Public users can update payment status" ON job_posts;
  DROP POLICY IF EXISTS "Admin users can manage job posts" ON job_posts;
EXCEPTION
  WHEN undefined_object THEN NULL;
END $$;

-- Create new policies
CREATE POLICY "Enable job post creation for authenticated users"
  ON job_posts
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  );

CREATE POLICY "Enable job post updates for company owners"
  ON job_posts
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  );

CREATE POLICY "Enable job post deletion for company owners"
  ON job_posts
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
  );

CREATE POLICY "Enable job post viewing for active listings"
  ON job_posts
  FOR SELECT
  TO public
  USING (
    (status = 'active' AND expires_at > now())
    OR
    EXISTS (
      SELECT 1 FROM companies c
      WHERE c.id = job_posts.company_id
      AND c.email = auth.jwt()->>'email'
    )
    OR
    auth.jwt()->>'role' IN ('admin', 'moderator')
  );

CREATE POLICY "Enable admin management of job posts"
  ON job_posts
  FOR ALL
  TO authenticated
  USING (auth.jwt()->>'role' IN ('admin', 'moderator'))
  WITH CHECK (auth.jwt()->>'role' IN ('admin', 'moderator'));