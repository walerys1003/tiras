/*
  # Fix admin authentication system

  1. Changes
    - Drop and recreate admin_users table with proper structure
    - Add RLS policies for admin authentication
    - Create default admin user with proper email field
    - Add indexes for performance

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Ensure proper authentication checks
*/

-- Drop existing table if exists
DROP TABLE IF EXISTS admin_users CASCADE;

-- Create admin_users table
CREATE TABLE admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT admin_users_role_check CHECK (role = ANY (ARRAY['admin', 'editor']))
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admin users can view own data"
  ON admin_users
  FOR SELECT
  TO public
  USING (email = (auth.jwt() ->> 'email')::text);

CREATE POLICY "Admin users can update own data"
  ON admin_users
  FOR UPDATE
  TO public
  USING (email = (auth.jwt() ->> 'email')::text);

-- Insert default admin user
INSERT INTO admin_users (email, name, role)
VALUES (
  'admin@tirjob.pl',
  'Administrator',
  'admin'
) ON CONFLICT (email) DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_role ON admin_users(role);