/*
  # Add password verification function

  1. Changes
    - Add function to verify bcrypt password hashes
*/

-- Create password verification function
CREATE OR REPLACE FUNCTION verify_user_password(
  password_to_check text,
  stored_hash text
) RETURNS boolean AS $$
BEGIN
  RETURN stored_hash = crypt(password_to_check, stored_hash);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;