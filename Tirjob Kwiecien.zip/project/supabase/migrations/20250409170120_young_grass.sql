/*
  # Add cascade delete for users table

  1. Changes
    - Add ON DELETE CASCADE constraint to users table
    - This ensures that when a user is deleted from auth.users, the corresponding record in users table is also deleted

  2. Security
    - Maintain existing RLS policies
    - Ensure data consistency between auth.users and users table
*/

-- First drop the existing foreign key constraint if it exists
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_id_fkey;

-- Add the foreign key constraint with ON DELETE CASCADE
ALTER TABLE users 
ADD CONSTRAINT users_id_fkey 
FOREIGN KEY (id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;