/*
  # Add premium duration setting

  1. Changes
    - Add job_post_premium_duration setting to admin_settings table
    - Set default value to 90 days
    - Ensure it's in the recruitment group

  2. Security
    - Maintain existing RLS policies
*/

-- Insert premium duration setting if it doesn't exist
INSERT INTO admin_settings (key, value, setting_group)
VALUES ('job_post_premium_duration', '90', 'recruitment')
ON CONFLICT (key) DO UPDATE 
SET 
  value = EXCLUDED.value,
  updated_at = now();