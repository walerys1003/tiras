/*
  # Add user management policies

  1. Changes
    - Add RLS policies for users table
    - Ensure only admin users can manage other users
    - Allow users to view their own data
    - Add function to check admin role from JWT

  2. Security
    - Enable RLS
    - Add proper policies for admin access
    - Ensure data consistency
*/

-- Create policy for admin users to manage all users
CREATE POLICY "Admin users can manage all users"
  ON users
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin'
  );

-- Create policy for users to view their own data
CREATE POLICY "Users can view their own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = id
  );

-- Create policy for users to update their own data
CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id
  );

-- Create function to check if user has admin role
CREATE OR REPLACE FUNCTION auth.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN (
    current_setting('request.jwt.claims', true)::json ->> 'role'
  ) = 'admin';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to check if user has specific role
CREATE OR REPLACE FUNCTION auth.has_role(required_role text)
RETURNS boolean AS $$
BEGIN
  RETURN (
    current_setting('request.jwt.claims', true)::json ->> 'role'
  ) = required_role;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;