/*
  # Add more test data for location filtering

  1. Changes
    - Add more sample companies
    - Add more job posts with various locations
    - Ensure proper data distribution for testing
    - Add multiple jobs in same cities

  2. Security
    - Maintain existing RLS policies
*/

-- Insert more sample companies
INSERT INTO companies (id, name, email, phone)
VALUES 
  ('66666666-6666-6666-6666-666666666666', 'Paris Transport SARL', 'contact@paristransport.fr', '+33 6 98 76 54 32'),
  ('77777777-7777-7777-7777-777777777777', 'Berlin Logistics GmbH', 'info@berlinlog.de', '+49 176 9876543'),
  ('88888888-8888-8888-8888-888888888888', 'Warsaw Express Sp. z o.o.', 'kontakt@warsawexpress.pl', '+48 501 987 654')
ON CONFLICT (id) DO NOTHING;

-- Insert more job posts with duplicate cities
INSERT INTO job_posts (
  company_id,
  title,
  position_category,
  position_type,
  work_type,
  country,
  voivodeship,
  city,
  trailer_type,
  schedule,
  salary_amount,
  salary_currency,
  salary_type,
  is_premium,
  expires_at,
  status
)
VALUES
  -- More jobs in Paris
  (
    '66666666-6666-6666-6666-666666666666',
    'Kierowca C+E – Transport lokalny Paryż',
    'drivers',
    'kat. C+E',
    'domestic',
    'Francja',
    NULL,
    'Paris',
    'Plandeka',
    '2/1',
    2600,
    'EUR',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  (
    '66666666-6666-6666-6666-666666666666',
    'Kierowca B – Dostawy miejskie',
    'drivers',
    'kat. B',
    'domestic',
    'Francja',
    NULL,
    'Paris',
    'Bus < 3,5t',
    'pn-pt',
    2200,
    'EUR',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- More jobs in Berlin
  (
    '77777777-7777-7777-7777-777777777777',
    'Kierowca C+E – Transport międzynarodowy',
    'drivers',
    'kat. C+E',
    'international',
    'Niemcy',
    NULL,
    'Berlin',
    'Chłodnia',
    '3/1',
    3200,
    'EUR',
    'netto',
    true,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  (
    '77777777-7777-7777-7777-777777777777',
    'Kierowca C – Transport lokalny',
    'drivers',
    'kat. C',
    'domestic',
    'Niemcy',
    NULL,
    'Berlin',
    'Kontener',
    'pn-pt',
    2800,
    'EUR',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  -- More jobs in Warsaw
  (
    '88888888-8888-8888-8888-888888888888',
    'Kierowca C+E – Transport krajowy',
    'drivers',
    'kat. C+E',
    'domestic',
    'Polska',
    'Mazowieckie',
    'Warszawa',
    'Plandeka',
    '2/1',
    8500,
    'PLN',
    'netto',
    true,
    NOW() + INTERVAL '60 days',
    'active'
  ),
  (
    '88888888-8888-8888-8888-888888888888',
    'Kierowca B – Dostawy ekspresowe',
    'drivers',
    'kat. B',
    'domestic',
    'Polska',
    'Mazowieckie',
    'Warszawa',
    'Bus < 3,5t',
    'pn-pt',
    5000,
    'PLN',
    'netto',
    false,
    NOW() + INTERVAL '60 days',
    'active'
  );

-- Add requirements, languages, qualifications, duties and benefits for new jobs
INSERT INTO job_requirements (job_post_id, experience)
SELECT id, '2y'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

INSERT INTO job_languages (job_post_id, language)
SELECT id, 'Polski'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

INSERT INTO job_languages (job_post_id, language)
SELECT id, 
  CASE 
    WHEN country = 'Niemcy' THEN 'Niemiecki'
    WHEN country = 'Francja' THEN 'Francuski'
    ELSE 'Angielski'
  END
FROM job_posts
WHERE work_type = 'international'
AND created_at >= NOW() - INTERVAL '1 minute';

INSERT INTO job_qualifications (job_post_id, qualification)
SELECT id, 'Karta kierowcy'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

INSERT INTO job_duties (job_post_id, duty)
SELECT id, 'Transport towarów zgodnie z wyznaczoną trasą'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';

INSERT INTO job_benefits (job_post_id, benefit)
SELECT id, 'Atrakcyjne wynagrodzenie'
FROM job_posts
WHERE created_at >= NOW() - INTERVAL '1 minute';