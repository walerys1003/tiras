/*
  # Add schema.org examples to SEO settings

  1. Changes
    - Update existing SEO settings with proper schema.org data
    - Add structured data for better search engine visibility
    - Ensure all main pages have appropriate schema.org markup

  2. Security
    - Maintain existing RLS policies
*/

-- Update homepage with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "TirJob.pl - Portal pracy dla kierowców i specjalistów transportu",
  "url": "https://tirjob.pl",
  "description": "Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://tirjob.pl/search?q={search_term_string}",
    "query-input": "required name=search_term_string"
  },
  "publisher": {
    "@type": "Organization",
    "name": "TirJob.pl",
    "logo": {
      "@type": "ImageObject",
      "url": "https://i.ibb.co/7NdqLD2G/2.png",
      "width": "600",
      "height": "60"
    }
  }
}'::jsonb
WHERE page_path = '/';

-- Update blog page with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "Blog",
  "name": "Blog TirJob – Wiedza i Trendy dla Branży Transportowej",
  "url": "https://tirjob.pl/blog",
  "description": "Najświeższe informacje, praktyczne porady i nowinki z rynku transportowego – wszystko w jednym miejscu!",
  "publisher": {
    "@type": "Organization",
    "name": "TirJob.pl",
    "logo": {
      "@type": "ImageObject",
      "url": "https://i.ibb.co/7NdqLD2G/2.png",
      "width": "600",
      "height": "60"
    }
  }
}'::jsonb
WHERE page_path = '/blog';

-- Update contact page with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "TirJob.pl",
  "url": "https://tirjob.pl",
  "logo": {
    "@type": "ImageObject",
    "url": "https://i.ibb.co/7NdqLD2G/2.png",
    "width": "600",
    "height": "60"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+48-501-420-042",
    "contactType": "customer service",
    "email": "kontakt@tirjob.pl",
    "availableLanguage": ["Polish", "English"]
  },
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "ul. Świeradowska 47",
    "addressLocality": "Warszawa",
    "postalCode": "02-662",
    "addressCountry": "PL"
  }
}'::jsonb
WHERE page_path = '/kontakt';

-- Update job listings page with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "CollectionPage",
  "name": "Oferty pracy dla kierowców i specjalistów transportu - TirJob.pl",
  "description": "Przeglądaj aktualne oferty pracy dla kierowców i specjalistów transportu. Znajdź pracę dopasowaną do Twoich kwalifikacji i oczekiwań.",
  "url": "https://tirjob.pl/oferty-pracy",
  "publisher": {
    "@type": "Organization",
    "name": "TirJob.pl",
    "logo": {
      "@type": "ImageObject",
      "url": "https://i.ibb.co/7NdqLD2G/2.png",
      "width": "600",
      "height": "60"
    }
  },
  "mainEntity": {
    "@type": "ItemList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "item": {
          "@type": "JobPosting",
          "title": "Kierowca C+E - Transport międzynarodowy",
          "description": "Oferta pracy dla kierowcy C+E w transporcie międzynarodowym",
          "employmentType": "FULL_TIME"
        }
      }
    ]
  }
}'::jsonb
WHERE page_path = '/oferty-pracy';

-- Update pricing page with proper schema.org data
UPDATE seo_settings
SET schema_org = '{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Cennik usług - TirJob.pl",
  "description": "Sprawdź cennik usług rekrutacyjnych TirJob.pl. Publikuj ogłoszenia o pracę i docieraj do najlepszych kandydatów w branży transportowej.",
  "url": "https://tirjob.pl/cennik",
  "mainEntity": {
    "@type": "PriceSpecification",
    "name": "Cennik usług TirJob.pl",
    "description": "Cennik usług rekrutacyjnych dla branży transportowej",
    "price": "500.00",
    "priceCurrency": "PLN"
  }
}'::jsonb
WHERE page_path = '/cennik';