/*
  # Fix user changes not saving properly

  1. Changes
    - Recreate the sync_user_role_to_auth function with proper error handling
    - Add debug logging to track function execution
    - Ensure proper synchronization between users table and auth.users
    - Fix RLS policies to allow proper updates

  2. Security
    - Maintain existing security model
    - Ensure proper role-based access
*/

-- Drop existing trigger if it exists
DROP TRIGGER IF EXISTS sync_user_role_trigger ON users;

-- Drop existing function
DROP FUNCTION IF EXISTS sync_user_role_to_auth();

-- Create improved function to sync user role and name to auth metadata with error handling
CREATE OR REPLACE FUNCTION sync_user_role_to_auth()
RETURNS TRIGGER AS $$
DECLARE
  v_result RECORD;
BEGIN
  -- Log the function call for debugging
  RAISE LOG 'sync_user_role_to_auth called: old_role=%, new_role=%, old_name=%, new_name=%', 
    OLD.role, NEW.role, OLD.name, NEW.name;

  -- Update auth.users metadata with the new role and name
  UPDATE auth.users
  SET 
    raw_app_meta_data = jsonb_set(
      COALESCE(raw_app_meta_data, '{}'::jsonb),
      '{role}',
      to_jsonb(NEW.role)
    ),
    raw_user_meta_data = jsonb_set(
      COALESCE(raw_user_meta_data, '{}'::jsonb),
      '{name}',
      to_jsonb(NEW.name)
    )
  WHERE id = NEW.id
  RETURNING id INTO v_result;
  
  -- Log the result
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to update auth.users for id=%', NEW.id;
  ELSE
    RAISE LOG 'Successfully updated auth.users for id=%', NEW.id;
  END IF;
  
  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in sync_user_role_to_auth: %', SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to sync role and name changes
CREATE TRIGGER sync_user_role_trigger
  AFTER UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_role_to_auth();

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON users;
DROP POLICY IF EXISTS "Enable update for users based on email" ON users;
DROP POLICY IF EXISTS "Enable insert for all users" ON users;
DROP POLICY IF EXISTS "Users can update their own data" ON users;
DROP POLICY IF EXISTS "Admin users can manage all users" ON users;

-- Create improved policies
CREATE POLICY "Enable read access for all users"
  ON users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin users can manage all users"
  ON users
  FOR ALL
  TO authenticated
  USING (
    (current_setting('request.jwt.claims', true)::json ->> 'role') = 'admin'
  );

CREATE POLICY "Users can update their own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id
  );

CREATE POLICY "Enable insert for all users"
  ON users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Ensure all existing users have proper metadata
DO $$
DECLARE
  user_record RECORD;
BEGIN
  FOR user_record IN SELECT * FROM users
  LOOP
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        to_jsonb(user_record.role)
      ),
      raw_user_meta_data = jsonb_set(
        COALESCE(raw_user_meta_data, '{}'::jsonb),
        '{name}',
        to_jsonb(user_record.name)
      )
    WHERE id = user_record.id;
  END LOOP;
END $$;