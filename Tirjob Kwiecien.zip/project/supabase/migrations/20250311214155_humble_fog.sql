/*
  # Fix authentication setup

  1. Changes
    - Drop and recreate users table with proper auth integration
    - Create auth user with proper password
    - Add RLS policies for authentication
    - Link auth user with users table

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing table if exists
DROP TABLE IF EXISTS users CASCADE;

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY,
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT users_role_check CHECK (role = ANY (ARRAY['admin', 'user']))
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- First create auth user
DO $$
DECLARE
  auth_user_id uuid;
BEGIN
  -- Delete existing auth user if exists
  DELETE FROM auth.users WHERE email = 'admin@tirjob.pl';
  
  -- Insert into auth.users
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token,
    email_change_token_new,
    email_change,
    last_sign_in_at,
    raw_app_meta_data,
    raw_user_meta_data
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    'admin@tirjob.pl',
    crypt('admin123', gen_salt('bf')),
    NOW(),
    NOW(),
    NOW(),
    '',
    '',
    '',
    '',
    NOW(),
    '{"provider":"email","providers":["email"]}',
    '{}'
  )
  RETURNING id INTO auth_user_id;

  -- Then insert into users table with the same id
  INSERT INTO users (id, email, name, role)
  VALUES (
    auth_user_id,
    'admin@tirjob.pl',
    'Administrator',
    'admin'
  );
END $$;