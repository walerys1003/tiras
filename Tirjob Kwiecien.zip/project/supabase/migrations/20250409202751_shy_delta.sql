/*
  # Add SEO settings table

  1. New Tables
    - `seo_settings` - Stores SEO metadata for different pages
      - `id` (uuid, primary key)
      - `page_path` (text, unique) - URL path of the page
      - `page_type` (text) - Type of page (home, blog, etc.)
      - `title` (text) - Meta title
      - `description` (text) - Meta description
      - `keywords` (text) - Meta keywords
      - `og_title` (text) - OpenGraph title
      - `og_description` (text) - OpenGraph description
      - `og_image` (text) - OpenGraph image URL
      - `og_type` (text) - OpenGraph type
      - `schema_org` (jsonb) - Schema.org JSON-LD data
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for admin access
*/

-- Create seo_settings table
CREATE TABLE seo_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  page_path text UNIQUE NOT NULL,
  page_type text NOT NULL,
  title text,
  description text,
  keywords text,
  og_title text,
  og_description text,
  og_image text,
  og_type text,
  schema_org jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE seo_settings ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_seo_settings_page_path ON seo_settings(page_path);
CREATE INDEX idx_seo_settings_page_type ON seo_settings(page_type);

-- Create policies
CREATE POLICY "Admin users can manage SEO settings"
  ON seo_settings
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin'
  );

CREATE POLICY "Anyone can view SEO settings"
  ON seo_settings
  FOR SELECT
  TO public
  USING (true);

-- Create function for updating updated_at
CREATE OR REPLACE FUNCTION update_seo_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating updated_at
CREATE TRIGGER update_seo_settings_updated_at
  BEFORE UPDATE ON seo_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_seo_settings_updated_at();

-- Insert default SEO settings for main pages
INSERT INTO seo_settings (page_path, page_type, title, description, keywords, og_title, og_description, og_image, og_type, schema_org)
VALUES 
  ('/', 'home', 'TirJob.pl - Portal pracy dla kierowców i specjalistów transportu', 
   'Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.',
   'praca kierowca, praca transport, oferty pracy kierowca, kierowca C+E, praca spedytor',
   'TirJob.pl - Portal pracy dla kierowców i specjalistów transportu',
   'Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.',
   'https://i.ibb.co/7NdqLD2G/2.png',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebSite",
     "name": "TirJob.pl",
     "url": "https://tirjob.pl",
     "description": "Portal pracy dla kierowców i specjalistów transportu",
     "potentialAction": {
       "@type": "SearchAction",
       "target": "https://tirjob.pl/search?q={search_term_string}",
       "query-input": "required name=search_term_string"
     }
   }'::jsonb),
   
  ('/blog', 'blog', 'Blog TirJob – Wiedza i Trendy dla Branży Transportowej',
   'Najświeższe informacje, praktyczne porady i nowinki z rynku transportowego – wszystko w jednym miejscu!',
   'blog transportowy, porady dla kierowców, trendy w transporcie, TSL blog',
   'Blog TirJob – Wiedza i Trendy dla Branży Transportowej',
   'Najświeższe informacje, praktyczne porady i nowinki z rynku transportowego – wszystko w jednym miejscu!',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'blog',
   '{
     "@context": "https://schema.org",
     "@type": "Blog",
     "name": "Blog TirJob.pl",
     "url": "https://tirjob.pl/blog",
     "description": "Blog o branży transportowej, poradach dla kierowców i trendach w TSL"
   }'::jsonb),
   
  ('/cennik', 'pricing', 'Cennik usług - TirJob.pl',
   'Sprawdź cennik usług rekrutacyjnych TirJob.pl. Publikuj ogłoszenia o pracę i docieraj do najlepszych kandydatów w branży transportowej.',
   'cennik ogłoszeń, publikacja ogłoszeń, rekrutacja kierowców, ceny',
   'Cennik usług - TirJob.pl',
   'Sprawdź cennik usług rekrutacyjnych TirJob.pl. Publikuj ogłoszenia o pracę i docieraj do najlepszych kandydatów w branży transportowej.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "PriceSpecification",
     "name": "Cennik usług TirJob.pl",
     "description": "Cennik usług rekrutacyjnych dla branży transportowej",
     "price": "499.00",
     "priceCurrency": "PLN"
   }'::jsonb),
   
  ('/kontakt', 'contact', 'Kontakt - TirJob.pl',
   'Skontaktuj się z nami. Jesteśmy dostępni, aby odpowiedzieć na wszystkie Twoje pytania dotyczące rekrutacji w branży transportowej.',
   'kontakt, pomoc, wsparcie, rekrutacja transportowa',
   'Kontakt - TirJob.pl',
   'Skontaktuj się z nami. Jesteśmy dostępni, aby odpowiedzieć na wszystkie Twoje pytania dotyczące rekrutacji w branży transportowej.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "Organization",
     "name": "TirJob.pl",
     "url": "https://tirjob.pl",
     "logo": "https://tirjob.pl/logo.png",
     "contactPoint": {
       "@type": "ContactPoint",
       "telephone": "+48-501-420-042",
       "contactType": "customer service",
       "email": "kontakt@tirjob.pl"
     },
     "address": {
       "@type": "PostalAddress",
       "streetAddress": "ul. Świeradowska 47",
       "addressLocality": "Warszawa",
       "postalCode": "02-662",
       "addressCountry": "PL"
     }
   }'::jsonb);