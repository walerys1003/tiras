/*
  # Add admin user if not exists

  1. Changes
    - Check if admin user exists before inserting
    - Create admin user in auth.users table only if it doesn't exist
    - Create admin user in users table only if it doesn't exist
    - Link both records with the same UUID
*/

-- Create auth user and link to users table
DO $$
DECLARE
  auth_user_id uuid;
  existing_auth_user_id uuid;
BEGIN
  -- Check if auth user already exists
  SELECT id INTO existing_auth_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';

  IF existing_auth_user_id IS NULL THEN
    -- Insert into auth.users only if user doesn't exist
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@tirjob.pl',
      crypt('Tirjob25!', gen_salt('bf')),
      '{"provider": "email", "providers": ["email"]}',
      '{}',
      false,
      now(),
      now()
    )
    RETURNING id INTO auth_user_id;

    -- Insert into users table with the same id
    INSERT INTO users (id, email, name, role, password_hash)
    VALUES (
      auth_user_id,
      'admin@tirjob.pl',
      'Administrator',
      'admin',
      crypt('Tirjob25!', gen_salt('bf'))
    )
    ON CONFLICT (email) DO UPDATE SET
      name = EXCLUDED.name,
      role = EXCLUDED.role,
      password_hash = EXCLUDED.password_hash;
  END IF;
END $$;