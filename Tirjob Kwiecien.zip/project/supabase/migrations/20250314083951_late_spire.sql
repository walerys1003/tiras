/*
  # Add voivodeships table and update cities

  1. New Tables
    - `job_voivodeships`
      - `id` (uuid, primary key)
      - `name` (text)
      - `country_id` (uuid, foreign key)
      - `created_at` (timestamptz)

  2. Changes
    - Add voivodeship_id to job_cities
    - Migrate existing voivodeship data
    - Add foreign key constraints
    - Update RLS policies

  3. Security
    - Enable RLS
    - Add policies for data access
*/

-- Create job_voivodeships table
CREATE TABLE job_voivodeships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  country_id uuid NOT NULL REFERENCES job_countries(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(name, country_id)
);

-- Add voivodeship_id to job_cities
ALTER TABLE job_cities ADD COLUMN voivodeship_id uuid REFERENCES job_voivodeships(id) ON DELETE SET NULL;

-- Enable RLS
ALTER TABLE job_voivodeships ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view voivodeships"
  ON job_voivodeships
  FOR SELECT
  TO public
  USING (true);

-- Create indexes
CREATE INDEX idx_job_cities_voivodeship_id ON job_cities(voivodeship_id);
CREATE INDEX idx_job_voivodeships_country_id ON job_voivodeships(country_id);
CREATE INDEX idx_job_voivodeships_name ON job_voivodeships(name);

-- Migrate existing data
DO $$
DECLARE
  v_poland_id uuid;
  v_voivodeship_id uuid;
  job_record RECORD;
BEGIN
  -- Get Poland's ID
  SELECT id INTO v_poland_id
  FROM job_countries
  WHERE country_name = 'Polska';

  IF v_poland_id IS NOT NULL THEN
    -- Insert all Polish voivodeships
    INSERT INTO job_voivodeships (name, country_id)
    VALUES
      ('Dolnośląskie', v_poland_id),
      ('Kujawsko-pomorskie', v_poland_id),
      ('Lubelskie', v_poland_id),
      ('Lubuskie', v_poland_id),
      ('Łódzkie', v_poland_id),
      ('Małopolskie', v_poland_id),
      ('Mazowieckie', v_poland_id),
      ('Opolskie', v_poland_id),
      ('Podkarpackie', v_poland_id),
      ('Podlaskie', v_poland_id),
      ('Pomorskie', v_poland_id),
      ('Śląskie', v_poland_id),
      ('Świętokrzyskie', v_poland_id),
      ('Warmińsko-mazurskie', v_poland_id),
      ('Wielkopolskie', v_poland_id),
      ('Zachodniopomorskie', v_poland_id)
    ON CONFLICT (name, country_id) DO NOTHING;

    -- Update cities with voivodeship_id
    FOR job_record IN 
      SELECT DISTINCT jp.voivodeship, jc.id as city_id
      FROM job_posts jp
      JOIN job_cities jc ON jc.id = jp.city_id
      WHERE jp.voivodeship IS NOT NULL
    LOOP
      -- Get voivodeship_id
      SELECT id INTO v_voivodeship_id
      FROM job_voivodeships
      WHERE name = job_record.voivodeship
      AND country_id = v_poland_id;

      -- Update city
      IF v_voivodeship_id IS NOT NULL THEN
        UPDATE job_cities
        SET voivodeship_id = v_voivodeship_id
        WHERE id = job_record.city_id;
      END IF;
    END LOOP;
  END IF;
END $$;

-- Drop voivodeship column from job_posts as it's now stored in job_cities
ALTER TABLE job_posts DROP COLUMN voivodeship;