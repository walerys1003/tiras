/*
  # Add is_featured column to blog_posts

  1. Changes
    - Add is_featured column to blog_posts table
    - Set default value to false
    - Update existing posts to mark some as featured
    - Add index for performance

  2. Security
    - Maintain existing RLS policies
*/

-- Add is_featured column
ALTER TABLE blog_posts 
ADD COLUMN is_featured boolean NOT NULL DEFAULT false;

-- Create index for is_featured column
CREATE INDEX idx_blog_posts_is_featured ON blog_posts(is_featured);

-- Update some existing posts to be featured
UPDATE blog_posts
SET is_featured = true
WHERE slug IN (
  'jak-zostac-kierowca-miedzynarodowym-2025',
  'zmiany-w-przepisach-o-czasie-pracy-kierowcow-2025',
  'jak-skutecznie-rekrutowac-kierowcow-2025',
  'sztuczna-inteligencja-w-transporcie'
);