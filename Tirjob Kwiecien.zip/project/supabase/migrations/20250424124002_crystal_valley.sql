/*
  # Fix user deletion functionality

  1. Changes
    - Create a new RPC function to properly delete users
    - Add proper error handling and logging
    - Ensure admin users can delete other users
    - Fix permission issues with auth.users table

  2. Security
    - Use SECURITY DEFINER for privileged operations
    - Ensure proper role checks
    - Log all deletion operations for audit purposes
*/

-- Create a new function to delete users with proper error handling
CREATE OR REPLACE FUNCTION delete_user_by_id(user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_email TEXT;
  v_user_role TEXT;
  v_caller_role TEXT;
  v_result RECORD;
BEGIN
  -- Get information about the user to be deleted
  SELECT email, raw_app_meta_data->>'role' INTO v_user_email, v_user_role
  FROM auth.users
  WHERE id = user_id;
  
  -- Check if user exists
  IF v_user_email IS NULL THEN
    RAISE LOG 'User not found: id=%', user_id;
    RETURN FALSE;
  END IF;
  
  -- Get caller's role
  v_caller_role := current_setting('request.jwt.claims', true)::json->>'role';
  
  -- Check if caller has admin role
  IF v_caller_role != 'admin' THEN
    RAISE LOG 'Permission denied: caller_role=%, required_role=admin', v_caller_role;
    RAISE EXCEPTION 'Only admin users can delete users';
  END IF;
  
  -- Log the deletion attempt
  RAISE LOG 'Deleting user: id=%, email=%, role=%', user_id, v_user_email, v_user_role;
  
  -- Delete the user from auth.users
  DELETE FROM auth.users
  WHERE id = user_id
  RETURNING id INTO v_result;
  
  -- Check if deletion was successful
  IF v_result.id IS NULL THEN
    RAISE LOG 'Failed to delete user: id=%, email=%', user_id, v_user_email;
    RETURN FALSE;
  END IF;
  
  -- Log successful deletion
  RAISE LOG 'Successfully deleted user: id=%, email=%', user_id, v_user_email;
  RETURN TRUE;
EXCEPTION WHEN OTHERS THEN
  -- Log any errors
  RAISE LOG 'Error in delete_user_by_id: %', SQLERRM;
  RAISE EXCEPTION 'Error deleting user: %', SQLERRM;
END;
$$;