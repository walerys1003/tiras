/*
  # Add more SEO settings for remaining pages

  1. Changes
    - Add SEO settings for all remaining pages in the site
    - Include proper metadata for each page type
    - Set appropriate OpenGraph data
    - Add Schema.org structured data

  2. Security
    - Maintain existing RLS policies
*/

-- Insert additional SEO settings for remaining pages
INSERT INTO seo_settings (page_path, page_type, title, description, keywords, og_title, og_description, og_image, og_type, schema_org)
VALUES 
  ('/uslugi-promocji', 'promotion-services', 'Usługi promocji - TirJob.pl',
   'Zwiększ widoczność swoich ogłoszeń o pracę. Sprawdź nasze usługi promocji i dotrzyj do najlepszych kandydatów w branży transportowej.',
   'promocja ogłoszeń, wyróżnienie oferty, reklama pracy, kampanie reklamowe, transport',
   'Usługi promocji - TirJob.pl',
   'Zwiększ widoczność swoich ogłoszeń o pracę. Sprawdź nasze usługi promocji i dotrzyj do najlepszych kandydatów w branży transportowej.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "Service",
     "name": "Usługi promocji TirJob.pl",
     "description": "Usługi promocji ogłoszeń o pracę w branży transportowej",
     "provider": {
       "@type": "Organization",
       "name": "TirJob.pl"
     },
     "offers": {
       "@type": "Offer",
       "price": "399.00",
       "priceCurrency": "PLN"
     }
   }'::jsonb),
   
  ('/social-media', 'social-media', 'Social Media - TirJob.pl',
   'Dołącz do naszej społeczności w mediach społecznościowych. Bądź na bieżąco z najnowszymi ofertami pracy i informacjami z branży transportowej.',
   'social media, facebook, linkedin, instagram, społeczność kierowców, transport',
   'Social Media - TirJob.pl',
   'Dołącz do naszej społeczności w mediach społecznościowych. Bądź na bieżąco z najnowszymi ofertami pracy i informacjami z branży transportowej.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebPage",
     "name": "Social Media TirJob.pl",
     "description": "Nasze profile w mediach społecznościowych",
     "mainEntity": {
       "@type": "Organization",
       "name": "TirJob.pl",
       "sameAs": [
         "https://www.facebook.com/tirjob",
         "https://www.linkedin.com/company/tirjob",
         "https://www.instagram.com/tirjob.pl"
       ]
     }
   }'::jsonb),
   
  ('/newsletter', 'newsletter', 'Newsletter - TirJob.pl',
   'Zapisz się do newslettera TirJob.pl i otrzymuj najnowsze oferty pracy oraz informacje z branży transportowej prosto na swoją skrzynkę.',
   'newsletter, subskrypcja, oferty pracy, transport, kierowcy',
   'Newsletter - TirJob.pl',
   'Zapisz się do newslettera TirJob.pl i otrzymuj najnowsze oferty pracy oraz informacje z branży transportowej prosto na swoją skrzynkę.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebPage",
     "name": "Newsletter TirJob.pl",
     "description": "Zapisz się do newslettera TirJob.pl"
   }'::jsonb),
   
  ('/regulamin', 'terms', 'Regulamin - TirJob.pl',
   'Zapoznaj się z regulaminem serwisu TirJob.pl. Znajdziesz tu informacje o zasadach korzystania z portalu, publikacji ogłoszeń i ochronie danych.',
   'regulamin, zasady, warunki korzystania, portal pracy, transport',
   'Regulamin - TirJob.pl',
   'Zapoznaj się z regulaminem serwisu TirJob.pl. Znajdziesz tu informacje o zasadach korzystania z portalu, publikacji ogłoszeń i ochronie danych.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebPage",
     "name": "Regulamin TirJob.pl",
     "description": "Regulamin korzystania z serwisu TirJob.pl",
     "mainEntity": {
       "@type": "Article",
       "name": "Regulamin",
       "articleBody": "Regulamin serwisu TirJob.pl"
     }
   }'::jsonb),
   
  ('/polityka-prywatnosci', 'privacy', 'Polityka prywatności - TirJob.pl',
   'Dowiedz się, jak chronimy Twoje dane osobowe. Nasza polityka prywatności wyjaśnia, jakie informacje zbieramy i w jaki sposób je wykorzystujemy.',
   'polityka prywatności, RODO, ochrona danych, cookies, prywatność',
   'Polityka prywatności - TirJob.pl',
   'Dowiedz się, jak chronimy Twoje dane osobowe. Nasza polityka prywatności wyjaśnia, jakie informacje zbieramy i w jaki sposób je wykorzystujemy.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebPage",
     "name": "Polityka prywatności TirJob.pl",
     "description": "Polityka prywatności i cookies serwisu TirJob.pl",
     "mainEntity": {
       "@type": "Article",
       "name": "Polityka prywatności",
       "articleBody": "Polityka prywatności serwisu TirJob.pl"
     }
   }'::jsonb),
   
  ('/dodaj-ogloszenie', 'job-post', 'Dodaj ogłoszenie - TirJob.pl',
   'Dodaj ogłoszenie o pracę w branży transportowej. Docieraj do tysięcy kierowców i specjalistów transportu szukających pracy.',
   'dodaj ogłoszenie, publikacja oferty, rekrutacja kierowców, oferta pracy transport',
   'Dodaj ogłoszenie - TirJob.pl',
   'Dodaj ogłoszenie o pracę w branży transportowej. Docieraj do tysięcy kierowców i specjalistów transportu szukających pracy.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "WebPage",
     "name": "Dodaj ogłoszenie - TirJob.pl",
     "description": "Formularz dodawania ogłoszeń o pracę w branży transportowej"
   }'::jsonb),
   
  ('/jobs', 'job-list', 'Oferty pracy dla kierowców i specjalistów transportu - TirJob.pl',
   'Przeglądaj aktualne oferty pracy dla kierowców i specjalistów transportu. Znajdź pracę dopasowaną do Twoich kwalifikacji i oczekiwań.',
   'oferty pracy, praca kierowca, praca transport, kierowca C+E, spedytor, logistyk',
   'Oferty pracy dla kierowców i specjalistów transportu - TirJob.pl',
   'Przeglądaj aktualne oferty pracy dla kierowców i specjalistów transportu. Znajdź pracę dopasowaną do Twoich kwalifikacji i oczekiwań.',
   'https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3',
   'website',
   '{
     "@context": "https://schema.org",
     "@type": "JobPosting",
     "title": "Oferty pracy dla kierowców i specjalistów transportu",
     "description": "Aktualne oferty pracy w branży transportowej",
     "datePosted": "2025-04-10",
     "employmentType": "FULL_TIME",
     "hiringOrganization": {
       "@type": "Organization",
       "name": "TirJob.pl",
       "sameAs": "https://tirjob.pl"
     },
     "jobLocation": {
       "@type": "Place",
       "address": {
         "@type": "PostalAddress",
         "addressCountry": "PL"
       }
     }
   }'::jsonb)
ON CONFLICT (page_path) DO UPDATE SET
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  keywords = EXCLUDED.keywords,
  og_title = EXCLUDED.og_title,
  og_description = EXCLUDED.og_description,
  og_image = EXCLUDED.og_image,
  og_type = EXCLUDED.og_type,
  schema_org = EXCLUDED.schema_org;