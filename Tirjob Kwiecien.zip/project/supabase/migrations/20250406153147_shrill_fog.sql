/*
  # Update role checks in RLS policies

  1. Changes
    - Update RLS policies to use app_metadata for role checks
    - Add policies for admin access based on app_metadata
    - Remove references to users table in policies
    - Ensure proper authentication checks

  2. Security
    - Enable RLS
    - Add policies for proper access control
    - Use app_metadata for role-based access
*/

-- Create policies for blog_posts
CREATE POLICY "Admin users can manage blog posts"
  ON blog_posts
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin' OR
    (auth.jwt() ->> 'role')::text = 'redaktor'
  );

-- Create policies for blog_categories
CREATE POLICY "Admin users can manage blog categories"
  ON blog_categories
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin' OR
    (auth.jwt() ->> 'role')::text = 'redaktor'
  );

-- Create policies for job_posts
CREATE POLICY "Admin users can manage job posts"
  ON job_posts
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin' OR
    (auth.jwt() ->> 'role')::text = 'moderator'
  );

-- Create policies for newsletter_subscribers
CREATE POLICY "Admin users can manage newsletter subscribers"
  ON newsletter_subscribers
  FOR ALL
  TO authenticated
  USING (
    (auth.jwt() ->> 'role')::text = 'admin'
  );

-- Create function to check if user has admin role
CREATE OR REPLACE FUNCTION auth.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN (
    current_setting('request.jwt.claims', true)::json ->> 'role'
  ) = 'admin';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;