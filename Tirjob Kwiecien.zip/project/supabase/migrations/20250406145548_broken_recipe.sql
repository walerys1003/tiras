-- Drop trigger if exists
DROP TRIGGER IF EXISTS auto_confirm_user_email_trigger ON auth.users;

-- Drop function if exists
DROP FUNCTION IF EXISTS auto_confirm_user_email() CASCADE;

-- Create function to auto-confirm email for new users
CREATE OR REPLACE FUNCTION auto_confirm_user_email()
RETURNS TRIGGER AS $$
BEGIN
  -- Set email_confirmed_at to current timestamp if it's not already set
  IF NEW.email_confirmed_at IS NULL THEN
    UPDATE auth.users
    SET email_confirmed_at = NOW()
    WHERE id = NEW.id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically confirm email for new users
CREATE TRIGGER auto_confirm_user_email_trigger
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION auto_confirm_user_email();

-- Ensure all existing users have their emails confirmed
UPDATE auth.users
SET email_confirmed_at = now()
WHERE email_confirmed_at IS NULL;

-- Ensure admin user exists with proper role
DO $$
DECLARE
  admin_user_id uuid;
  redaktor_user_id uuid;
  moderator_user_id uuid;
BEGIN
  -- Check if admin user exists
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'admin@tirjob.pl';
  
  IF admin_user_id IS NULL THEN
    -- Create admin user if it doesn't exist
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@tirjob.pl',
      crypt('admin123', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "admin"}',
      '{"name": "Administrator"}',
      now(),
      now()
    );
  ELSE
    -- Update existing admin user to ensure it has admin role
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        '"admin"'
      ),
      email_confirmed_at = now()
    WHERE id = admin_user_id;
  END IF;
  
  -- Check if redaktor user exists
  SELECT id INTO redaktor_user_id
  FROM auth.users
  WHERE email = 'redaktor@tirjob.pl';
  
  IF redaktor_user_id IS NULL THEN
    -- Create redaktor user if it doesn't exist
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'redaktor@tirjob.pl',
      crypt('redaktor123', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "redaktor"}',
      '{"name": "Redaktor"}',
      now(),
      now()
    );
  ELSE
    -- Update existing redaktor user to ensure it has redaktor role
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        '"redaktor"'
      ),
      email_confirmed_at = now()
    WHERE id = redaktor_user_id;
  END IF;
  
  -- Check if moderator user exists
  SELECT id INTO moderator_user_id
  FROM auth.users
  WHERE email = 'moderator@tirjob.pl';
  
  IF moderator_user_id IS NULL THEN
    -- Create moderator user if it doesn't exist
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'moderator@tirjob.pl',
      crypt('moderator123', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "moderator"}',
      '{"name": "Moderator"}',
      now(),
      now()
    );
  ELSE
    -- Update existing moderator user to ensure it has moderator role
    UPDATE auth.users
    SET 
      raw_app_meta_data = jsonb_set(
        COALESCE(raw_app_meta_data, '{}'::jsonb),
        '{role}',
        '"moderator"'
      ),
      email_confirmed_at = now()
    WHERE id = moderator_user_id;
  END IF;
END $$;