import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import BlogHero from './blog/BlogHero';
import BlogCategories from './blog/BlogCategories';
import BlogArticleList from './blog/BlogArticleList';
import BlogCTA from './blog/BlogCTA';
import { getBlogCategories, getBlogPosts, getFeaturedPosts, type BlogCategory } from '../lib/blog';
import type { BlogPostProps } from './BlogPost';

export default function Blog() {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [articles, setArticles] = useState<BlogPostProps[]>([]);
  const [featuredArticles, setFeaturedArticles] = useState<BlogPostProps[]>([]);
  const [totalArticles, setTotalArticles] = useState(0);
  const [loading, setLoading] = useState(true);
  const articlesPerPage = 7;
  
  // Load categories and initial articles
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const [categoriesData, articlesData, featuredData] = await Promise.all([
          getBlogCategories(),
          getBlogPosts(selectedCategory, currentPage, articlesPerPage),
          !selectedCategory ? getFeaturedPosts() : Promise.resolve([])
        ]);

        setCategories(categoriesData);
        setArticles(articlesData.posts);
        setFeaturedArticles(featuredData);
        setTotalArticles(articlesData.total);
      } catch (error) {
        console.error('Error loading blog data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [selectedCategory, currentPage]);

  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
    `;
    
    document.head.appendChild(styleElement);
    
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Handle category selection
  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentPage(1);
    
    // Scroll to articles section
    setTimeout(() => {
      const articlesSection = document.getElementById('articles-section');
      if (articlesSection) {
        articlesSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  // Calculate total pages
  const totalPages = Math.ceil(totalArticles / articlesPerPage);

  // Generate category badge color based on category
  const getCategoryBadgeColor = (category: string) => {
    const normalizedCategory = category.toLowerCase();
    const matchedCategory = categories.find(c => 
      normalizedCategory.includes(c.title.toLowerCase()) || 
      normalizedCategory.includes(c.slug.toLowerCase())
    );

    if (matchedCategory) {
      switch(matchedCategory.slug) {
        case 'porady-dla-kandydatow':
          return 'bg-blue-100 text-blue-800';
        case 'porady-dla-pracodawcow':
          return 'bg-green-100 text-green-800';
        case 'trendy-w-branzy':
          return 'bg-purple-100 text-purple-800';
        case 'wydarzenia-i-szkolenia':
          return 'bg-amber-100 text-amber-800';
        case 'edukacja-i-rozwoj':
          return 'bg-red-100 text-red-800';
        case 'innowacje':
          return 'bg-teal-100 text-teal-800';
      }
    }

    return 'bg-gray-100 text-gray-800';
  };

  // Generate dynamic SEO metadata
  const generateSeoMetadata = () => {
    const title = selectedCategory 
      ? `${categories.find(c => c.id === selectedCategory)?.title || 'Kategoria'} - Blog TirJob.pl`
      : "Blog TirJob – Wiedza i Trendy dla Branży Transportowej";
    
    const description = selectedCategory
      ? `Artykuły z kategorii ${categories.find(c => c.id === selectedCategory)?.title || 'Kategoria'} - najnowsze informacje i porady dla branży transportowej.`
      : "Najświeższe informacje, praktyczne porady i nowinki z rynku transportowego – wszystko w jednym miejscu!";
    
    const keywords = "blog transportowy, porady dla kierowców, trendy w transporcie, TSL blog";
    
    return { title, description, keywords };
  };
  
  const seoMetadata = generateSeoMetadata();

  return (
    <>
      <Helmet>
        <title>{seoMetadata.title}</title>
        <meta name="description" content={seoMetadata.description} />
        <meta name="keywords" content={seoMetadata.keywords} />
        
        {/* OpenGraph Tags */}
        <meta property="og:title" content={seoMetadata.title} />
        <meta property="og:description" content={seoMetadata.description} />
        <meta property="og:image" content="https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`https://tirjob.pl${location.pathname}`} />
        <meta property="og:site_name" content="TirJob.pl" />
        
        {/* Twitter Tags */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={seoMetadata.title} />
        <meta name="twitter:description" content={seoMetadata.description} />
        <meta name="twitter:image" content="https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3" />
        
        {/* Canonical URL */}
        <link rel="canonical" href={`https://tirjob.pl${location.pathname}`} />
        
        {/* Schema.org JSON-LD */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Blog",
            "name": "Blog TirJob.pl",
            "url": "https://tirjob.pl/blog",
            "description": "Blog o branży transportowej, poradach dla kierowców i trendach w TSL"
          })}
        </script>
      </Helmet>
      <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
        <BlogHero />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <BlogCategories onCategoryClick={handleCategoryClick} />
          
          <BlogArticleList 
            selectedCategory={selectedCategory}
            currentPage={currentPage}
            articles={selectedCategory ? articles : featuredArticles}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            onClearCategory={() => setSelectedCategory(null)}
            getCategoryBadgeColor={getCategoryBadgeColor}
            categories={categories}
            loading={loading}
          />

          <BlogCTA />
        </div>
      </div>
    </>
  );
}