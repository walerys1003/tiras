import React from 'react';
import type { BlogPost } from '../../../lib/blog';

interface SeoEditorProps {
  post: Partial<BlogPost>;
  updatePost: (updates: Partial<BlogPost>) => void;
}

export default function SeoEditor({ post, updatePost }: SeoEditorProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-medium text-navy-900 mb-4">Ustawienia SEO</h2>
      <p className="text-sm text-gray-500 mb-4">
        Te ustawienia wpływają na to, jak Twój artykuł będzie wyświetlany w wynikach wyszukiwania i mediach społecznościowych.
      </p>
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Meta Title
          </label>
          <input
            type="text"
            value={post.seo_title || ''}
            onChange={e => updatePost({ seo_title: e.target.value })}
            placeholder={post.title || ''}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
          <p className="mt-1 text-xs text-gray-500">
            {post.seo_title ? `${post.seo_title.length}/60 znaków` : `Domyślnie: ${post.title?.length || 0}/60 znaków`}
          </p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Meta Description
          </label>
          <textarea
            value={post.seo_description || ''}
            onChange={e => updatePost({ seo_description: e.target.value })}
            placeholder={post.excerpt || ''}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
          <p className="mt-1 text-xs text-gray-500">
            {post.seo_description ? `${post.seo_description.length}/160 znaków` : `Domyślnie: ${post.excerpt?.length || 0}/160 znaków`}
          </p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Meta Keywords
          </label>
          <input
            type="text"
            value={post.seo_keywords || ''}
            onChange={e => updatePost({ seo_keywords: e.target.value })}
            placeholder="słowo kluczowe 1, słowo kluczowe 2, słowo kluczowe 3"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
          <p className="mt-1 text-xs text-gray-500">
            Oddziel słowa kluczowe przecinkami
          </p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            OG Image URL (dla social media)
          </label>
          <input
            type="url"
            value={post.seo_image || ''}
            onChange={e => updatePost({ seo_image: e.target.value })}
            placeholder={post.featured_image || ''}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
          <p className="mt-1 text-xs text-gray-500">
            URL do obrazka wyświetlanego w social media
          </p>
        </div>
      </div>
    </div>
  );
}