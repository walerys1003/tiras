import React, { useState, useEffect } from 'react';
import RichTextEditor from '../../RichTextEditor';
import type { BlogPost } from '../../../lib/blog';

interface ContentEditorProps {
  post: Partial<BlogPost>;
  updatePost: (updates: Partial<BlogPost>) => void;
  categories: Array<{ id: string; title: string }>;
}

export default function ContentEditor({ post, updatePost, categories }: ContentEditorProps) {
  const [initialContentSet, setInitialContentSet] = useState(false);

  // Set initial content flag when post changes
  useEffect(() => {
    if (post.content && !initialContentSet) {
      setInitialContentSet(true);
    }
  }, [post.content, initialContentSet]);

  // Handle editor content change
  const handleEditorChange = (content: string) => {
    // Only update if initial content has been set to avoid infinite loops
    if (initialContentSet) {
      updatePost({ content });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-medium text-navy-900 mb-4">Podstawowe informacje</h2>
        <div className="grid grid-cols-1 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tytuł
            </label>
            <input
              type="text"
              value={post.title || ''}
              onChange={e => updatePost({ title: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Slug (URL)
            </label>
            <input
              type="text"
              value={post.slug || ''}
              onChange={e => updatePost({ slug: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              placeholder="Zostanie wygenerowany automatycznie jeśli pozostanie pusty"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kategoria
            </label>
            <select
              value={post.category_id || ''}
              onChange={e => updatePost({ category_id: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              required
            >
              <option value="">Wybierz kategorię</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              value={post.status || 'draft'}
              onChange={e => updatePost({ status: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
            >
              <option value="draft">Szkic</option>
              <option value="published">Opublikowany</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Zdjęcie główne (URL)
            </label>
            <input
              type="url"
              value={post.featured_image || ''}
              onChange={e => updatePost({ featured_image: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              placeholder="https://example.com/image.jpg"
            />
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_featured"
              checked={post.is_featured || false}
              onChange={e => updatePost({ is_featured: e.target.checked })}
              className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
            />
            <label htmlFor="is_featured" className="ml-2 block text-sm text-gray-900">
              Wyróżniony artykuł
            </label>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-medium text-navy-900 mb-4">Treść</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Wstęp
            </label>
            <textarea
              value={post.excerpt || ''}
              onChange={e => updatePost({ excerpt: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              placeholder="Krótki opis artykułu..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Treść artykułu
            </label>
            <RichTextEditor
              value={post.content || ''}
              onChange={handleEditorChange}
              placeholder="Wpisz treść artykułu..."
              required
            />
            <p className="mt-1 text-xs text-gray-500">
              Długość treści: {post.content?.length || 0} znaków
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}