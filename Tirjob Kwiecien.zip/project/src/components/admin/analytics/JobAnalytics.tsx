import React, { useEffect, useState } from 'react';
import { 
  BarChart, PieChart, TrendingUp, Calendar, Filter, 
  Download, Eye, FileText, Users, Search, 
  ChevronDown, ChevronUp
} from 'lucide-react';
import { objectsToCSV } from '../../../lib/csv';
import { supabase } from '../../../lib/supabase';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend);

// Types for analytics data
export interface JobAnalytics {
  totalJobs: number;
  activeJobs: number;
  totalApplications: number;
  totalViews: number;
  conversionRate: number;
  jobsByStatus: {
    status: string;
    count: number;
  }[];
  jobsByMonth: {
    month: string;
    count: number;
  }[];
  jobsByCategory: {
    category: string;
    count: number;
  }[];
  topJobs: {
    id: string;
    title: string;
    company: string;
    views: number;
    applications: number;
    conversionRate: number;
  }[];
}

interface JobAnalyticsProps {
  dateRange: string;
  startDate: string;
  endDate: string;
  onRefresh?: () => void;
}

export default function JobAnalyticsComponent({ 
  dateRange, 
  startDate, 
  endDate,
  onRefresh
}: JobAnalyticsProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedJob, setExpandedJob] = useState<string | null>(null);
  const [jobAnalytics, setJobAnalytics] = useState<JobAnalytics>({
    totalJobs: 0,
    activeJobs: 0,
    totalApplications: 0,
    totalViews: 0,
    conversionRate: 0,
    jobsByStatus: [],
    jobsByMonth: [],
    jobsByCategory: [],
    topJobs: []
  });

  useEffect(() => {
    fetchJobAnalytics();
  }, [dateRange, startDate, endDate]);

  // Add event listeners for parent component interactions
  useEffect(() => {
    const componentElement = document.getElementById('job-analytics-component');
    if (componentElement) {
      componentElement.addEventListener('refresh', fetchJobAnalytics);
      componentElement.addEventListener('export', exportJobAnalytics);
      
      return () => {
        componentElement.removeEventListener('refresh', fetchJobAnalytics);
        componentElement.removeEventListener('export', exportJobAnalytics);
      };
    }
  }, []);

  const fetchJobAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Prepare date filters
      const startDateTime = new Date(startDate);
      startDateTime.setHours(0, 0, 0, 0);
      
      const endDateTime = new Date(endDate);
      endDateTime.setHours(23, 59, 59, 999);
      
      // Fetch job data with filters
      let jobsQuery = supabase
        .from('job_posts')
        .select(`
          id,
          title,
          status,
          position_category,
          created_at,
          company:companies(name)
        `);
      
      // Apply date filter
      if (dateRange !== 'all') {
        jobsQuery = jobsQuery
          .gte('created_at', startDateTime.toISOString())
          .lte('created_at', endDateTime.toISOString());
      }
      
      const { data: jobs, error: jobsError } = await jobsQuery;
      
      if (jobsError) throw jobsError;
      
      // Fetch applications data
      let applicationsQuery = supabase
        .from('job_applications')
        .select(`
          id,
          job_post_id,
          created_at
        `);
      
      // Apply date filter
      if (dateRange !== 'all') {
        applicationsQuery = applicationsQuery
          .gte('created_at', startDateTime.toISOString())
          .lte('created_at', endDateTime.toISOString());
      }
      
      const { data: applications, error: applicationsError } = await applicationsQuery;
      
      if (applicationsError) throw applicationsError;
      
      // Calculate analytics
      const totalJobs = jobs?.length || 0;
      const activeJobs = jobs?.filter(job => job.status === 'active').length || 0;
      const totalApplications = applications?.length || 0;
      
      // For this example, we'll simulate view data
      // In a real app, you would have a table tracking job views
      const totalViews = totalJobs * Math.floor(Math.random() * 100) + 50;
      
      // Calculate conversion rate (applications / views)
      const conversionRate = totalViews > 0 ? (totalApplications / totalViews) * 100 : 0;
      
      // Group jobs by status
      const jobsByStatus = [
        { status: 'active', count: jobs?.filter(job => job.status === 'active').length || 0 },
        { status: 'inactive', count: jobs?.filter(job => job.status === 'inactive').length || 0 },
        { status: 'expired', count: jobs?.filter(job => job.status === 'expired').length || 0 }
      ];
      
      // Group jobs by month
      const jobsByMonth: { month: string; count: number }[] = [];
      const monthCounts: Record<string, number> = {};
      
      jobs?.forEach(job => {
        const date = new Date(job.created_at);
        const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        monthCounts[month] = (monthCounts[month] || 0) + 1;
      });
      
      // Sort months chronologically
      Object.keys(monthCounts)
        .sort()
        .forEach(month => {
          const [year, monthNum] = month.split('-');
          const monthName = new Date(parseInt(year), parseInt(monthNum) - 1, 1)
            .toLocaleString('pl-PL', { month: 'long', year: 'numeric' });
          
          jobsByMonth.push({
            month: monthName,
            count: monthCounts[month]
          });
        });
      
      // Group jobs by category
      const categoryMap: Record<string, number> = {};
      jobs?.forEach(job => {
        const category = job.position_category || 'unknown';
        categoryMap[category] = (categoryMap[category] || 0) + 1;
      });
      
      const jobsByCategory = Object.entries(categoryMap).map(([category, count]) => ({
        category: category === 'drivers' ? 'Kierowcy' : 
                 category === 'logistics' ? 'Spedycja i logistyka' : 
                 category === 'construction' ? 'Budownictwo i magazyny' : 
                 category,
        count
      }));
      
      // Calculate top performing jobs
      const jobApplicationCounts: Record<string, number> = {};
      applications?.forEach(app => {
        jobApplicationCounts[app.job_post_id] = (jobApplicationCounts[app.job_post_id] || 0) + 1;
      });
      
      const topJobs = jobs?.map(job => {
        const jobViews = Math.floor(Math.random() * 100) + 10; // Simulated views
        const jobApplications = jobApplicationCounts[job.id] || 0;
        const jobConversionRate = jobViews > 0 ? (jobApplications / jobViews) * 100 : 0;
        
        return {
          id: job.id,
          title: job.title,
          company: job.company?.name || 'Unknown Company',
          views: jobViews,
          applications: jobApplications,
          conversionRate: jobConversionRate
        };
      }).sort((a, b) => b.applications - a.applications).slice(0, 10) || [];
      
      setJobAnalytics({
        totalJobs,
        activeJobs,
        totalApplications,
        totalViews,
        conversionRate,
        jobsByStatus,
        jobsByMonth,
        jobsByCategory,
        topJobs
      });
      
      // Call onRefresh callback if provided
      if (onRefresh) {
        onRefresh();
      }
    } catch (error) {
      console.error('Error fetching job analytics:', error);
      setError('Failed to load job analytics data');
    } finally {
      setLoading(false);
    }
  };

  const exportJobAnalytics = () => {
    const headers = {
      id: 'ID',
      title: 'Tytuł',
      company: 'Firma',
      views: 'Wyświetlenia',
      applications: 'Aplikacje',
      conversionRate: 'Konwersja (%)'
    };
    
    const csv = objectsToCSV(jobAnalytics.topJobs, headers);
    
    // Create blob and download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `job-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  // Filter jobs by search query
  const filteredJobs = jobAnalytics.topJobs.filter(job => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
        {error}
      </div>
    );
  }

  return (
    <div className="job-analytics-content">
      {/* Search Filter */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Wyszukaj ogłoszenie
        </label>
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Szukaj po tytule lub firmie..."
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Ogłoszenia</h3>
            <FileText className="h-6 w-6 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{jobAnalytics.totalJobs}</p>
          <p className="text-sm text-navy-600 mt-1">
            Aktywne: {jobAnalytics.activeJobs}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Aplikacje</h3>
            <Users className="h-6 w-6 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{jobAnalytics.totalApplications}</p>
          <p className="text-sm text-navy-600 mt-1">
            Średnio {(jobAnalytics.totalJobs > 0 ? jobAnalytics.totalApplications / jobAnalytics.totalJobs : 0).toFixed(1)} na ogłoszenie
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Wyświetlenia</h3>
            <Eye className="h-6 w-6 text-purple-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{jobAnalytics.totalViews}</p>
          <p className="text-sm text-navy-600 mt-1">
            Średnio {(jobAnalytics.totalJobs > 0 ? jobAnalytics.totalViews / jobAnalytics.totalJobs : 0).toFixed(1)} na ogłoszenie
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Konwersja</h3>
            <TrendingUp className="h-6 w-6 text-accent-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{jobAnalytics.conversionRate.toFixed(2)}%</p>
          <p className="text-sm text-navy-600 mt-1">
            Aplikacje / Wyświetlenia
          </p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 gap-6 mb-8">
        {/* Jobs by Month Chart */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-medium text-navy-900 mb-4 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-gray-500" />
            Ogłoszenia według miesięcy ({jobAnalytics.jobsByMonth.length})
          </h3>
          <div className="h-64">
            {jobAnalytics.jobsByMonth.length > 0 ? (
              <Bar 
                data={{
                  labels: jobAnalytics.jobsByMonth.map(item => item.month),
                  datasets: [
                    {
                      label: 'Liczba ogłoszeń',
                      data: jobAnalytics.jobsByMonth.map(item => item.count),
                      backgroundColor: 'rgba(244, 63, 94, 0.7)',
                      borderColor: 'rgba(244, 63, 94, 1)',
                      borderWidth: 1,
                      borderRadius: 4,
                      hoverBackgroundColor: 'rgba(244, 63, 94, 0.9)',
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      display: false,
                    },
                    tooltip: {
                      callbacks: {
                        label: function(context) {
                          return `Liczba ogłoszeń: ${context.raw}`;
                        }
                      }
                    }
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      ticks: {
                        precision: 0
                      }
                    }
                  }
                }}
              />
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500">Brak danych dla wybranego okresu</p>
              </div>
            )}
          </div>
        </div>

        {/* Jobs by Category Chart */}
        <div className="bg-white rounded-xl shadow-sm p-6 mt-6">
          <h3 className="text-lg font-medium text-navy-900 mb-4 flex items-center">
            <PieChart className="w-5 h-5 mr-2 text-gray-500" />
            Ogłoszenia według kategorii ({jobAnalytics.jobsByCategory.length})
          </h3>
          <div className="h-64">
            {jobAnalytics.jobsByCategory.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
                <Pie
                  data={{
                    labels: jobAnalytics.jobsByCategory.map(item => item.category),
                    datasets: [
                      {
                        data: jobAnalytics.jobsByCategory.map(item => item.count),
                        backgroundColor: [
                          'rgba(244, 63, 94, 0.7)',  // accent-500
                          'rgba(59, 130, 246, 0.7)', // blue-500
                          'rgba(34, 197, 94, 0.7)',  // green-500
                          'rgba(168, 85, 247, 0.7)', // purple-500
                          'rgba(234, 179, 8, 0.7)',  // yellow-500
                          'rgba(239, 68, 68, 0.7)',  // red-500
                          'rgba(99, 102, 241, 0.7)', // indigo-500
                          'rgba(236, 72, 153, 0.7)', // pink-500
                        ],
                        borderColor: [
                          'rgba(244, 63, 94, 1)',
                          'rgba(59, 130, 246, 1)',
                          'rgba(34, 197, 94, 1)',
                          'rgba(168, 85, 247, 1)',
                          'rgba(234, 179, 8, 1)',
                          'rgba(239, 68, 68, 1)',
                          'rgba(99, 102, 241, 1)',
                          'rgba(236, 72, 153, 1)',
                        ],
                        borderWidth: 1,
                        hoverOffset: 4,
                      },
                    ],
                  }}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right',
                        labels: {
                          usePointStyle: true,
                          padding: 15,
                          font: {
                            size: 12
                          }
                        }
                      },
                      tooltip: {
                        callbacks: {
                          label: function(context) {
                            const label = context.label || '';
                            const value = context.raw as number;
                            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0) as number;
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value} (${percentage}%)`;
                          }
                        }
                      }
                    }
                  }}
                />
              </div>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500">Brak danych dla wybranego okresu</p>
              </div>
            )}
          </div>
        </div>

        {/* Top Jobs Table */}
        <div className="bg-white rounded-xl shadow-sm p-6 mt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-navy-900 flex items-center">
              <BarChart className="w-5 h-5 mr-2 text-gray-500" />
              Najlepiej performujące ogłoszenia
            </h3>
            <button
              onClick={exportJobAnalytics}
              className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center"
            >
              <Download className="w-5 h-5 mr-2" />
              Eksportuj do CSV
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tytuł
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Firma
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Wyświetlenia
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Aplikacje
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Konwersja
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Szczegóły
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredJobs.map((job, index) => (
                  <tr key={job.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-navy-900">
                      {job.title}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {job.company}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {job.views}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {job.applications}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {job.conversionRate.toFixed(2)}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <button
                        onClick={() => setExpandedJob(expandedJob === job.id ? null : job.id)}
                        className="text-accent-600 hover:text-accent-700"
                      >
                        {expandedJob === job.id ? (
                          <ChevronUp className="w-5 h-5" />
                        ) : (
                          <ChevronDown className="w-5 h-5" />
                        )}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}