import React, { useEffect, useState } from 'react';
import { 
  BarChart, PieChart, TrendingUp, CheckCircle2, Clock, 
  Download, CreditCard 
} from 'lucide-react';
import { objectsToCSV } from '../../../lib/csv';
import { supabase } from '../../../lib/supabase';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend);

interface PaymentAnalytics {
  totalPayments: number;
  totalRevenue: number;
  completedPayments: number;
  pendingPayments: number;
  failedPayments: number;
  revenueByMonth: {
    month: string;
    amount: number;
  }[];
  paymentsByStatus: {
    status: string;
    count: number;
  }[];
}

interface PaymentAnalyticsProps {
  dateRange: string;
  startDate: string;
  endDate: string;
  onRefresh?: () => void;
}

export default function PaymentAnalyticsComponent({ 
  dateRange, 
  startDate, 
  endDate,
  onRefresh 
}: PaymentAnalyticsProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [paymentAnalytics, setPaymentAnalytics] = useState<PaymentAnalytics>({
    totalPayments: 0,
    totalRevenue: 0,
    completedPayments: 0,
    pendingPayments: 0,
    failedPayments: 0,
    revenueByMonth: [],
    paymentsByStatus: []
  });

  useEffect(() => {
    fetchPaymentAnalytics();
  }, [dateRange, startDate, endDate]);

  // Add event listeners for parent component interactions
  useEffect(() => {
    const componentElement = document.getElementById('payment-analytics-component');
    if (componentElement) {
      componentElement.addEventListener('refresh', fetchPaymentAnalytics);
      componentElement.addEventListener('export', exportPaymentAnalytics);
      
      return () => {
        componentElement.removeEventListener('refresh', fetchPaymentAnalytics);
        componentElement.removeEventListener('export', exportPaymentAnalytics);
      };
    }
  }, []);

  const fetchPaymentAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Prepare date filters
      const startDateTime = new Date(startDate);
      startDateTime.setHours(0, 0, 0, 0);
      
      const endDateTime = new Date(endDate);
      endDateTime.setHours(23, 59, 59, 999);
      
      // Fetch payment data with filters
      let paymentsQuery = supabase
        .from('payments')
        .select(`
          id,
          amount,
          currency,
          status,
          created_at,
          job_post_id
        `);
      
      // Apply date filter
      if (dateRange !== 'all') {
        paymentsQuery = paymentsQuery
          .gte('created_at', startDateTime.toISOString())
          .lte('created_at', endDateTime.toISOString());
      }
      
      const { data: payments, error: paymentsError } = await paymentsQuery;
      
      if (paymentsError) throw paymentsError;
      
      // Calculate analytics
      const totalPayments = payments?.length || 0;
      const completedPayments = payments?.filter(p => p.status === 'completed').length || 0;
      const pendingPayments = payments?.filter(p => p.status === 'pending').length || 0;
      const failedPayments = payments?.filter(p => p.status === 'failed').length || 0;
      
      // Calculate total revenue
      let totalRevenue = 0;
      payments?.forEach(payment => {
        if (payment.status === 'completed') {
          // Convert all to PLN for simplicity
          const amount = payment.currency === 'PLN' 
            ? payment.amount 
            : payment.currency === 'EUR' 
              ? payment.amount * 4.3 // Example conversion rate
              : payment.amount * 3.9; // Example conversion rate
          
          totalRevenue += amount;
        }
      });
      
      // Group payments by month
      const revenueByMonth: { month: string; amount: number }[] = [];
      const monthRevenue: Record<string, number> = {};
      
      payments?.forEach(payment => {
        if (payment.status === 'completed') {
          const date = new Date(payment.created_at);
          const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
          
          // Convert to PLN
          const amount = payment.currency === 'PLN' 
            ? payment.amount 
            : payment.currency === 'EUR' 
              ? payment.amount * 4.3 
              : payment.amount * 3.9;
          
          monthRevenue[month] = (monthRevenue[month] || 0) + amount;
        }
      });
      
      // Sort months chronologically
      Object.keys(monthRevenue)
        .sort()
        .forEach(month => {
          const [year, monthNum] = month.split('-');
          const monthName = new Date(parseInt(year), parseInt(monthNum) - 1, 1)
            .toLocaleString('pl-PL', { month: 'long', year: 'numeric' });
          
          revenueByMonth.push({
            month: monthName,
            amount: monthRevenue[month]
          });
        });
      
      // Group payments by status
      const paymentsByStatus = [
        { status: 'completed', count: completedPayments },
        { status: 'pending', count: pendingPayments },
        { status: 'failed', count: failedPayments }
      ];
      
      setPaymentAnalytics({
        totalPayments,
        totalRevenue,
        completedPayments,
        pendingPayments,
        failedPayments,
        revenueByMonth,
        paymentsByStatus
      });
      
      // Call onRefresh callback if provided
      if (onRefresh) {
        onRefresh();
      }
    } catch (error) {
      console.error('Error fetching payment analytics:', error);
      setError('Failed to load payment analytics data');
    } finally {
      setLoading(false);
    }
  };

  const exportPaymentAnalytics = () => {
    const headers = {
      month: 'Miesiąc',
      amount: 'Przychód (PLN)'
    };
    
    const csv = objectsToCSV(paymentAnalytics.revenueByMonth, headers);
    
    // Create blob and download
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `payment-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
        {error}
      </div>
    );
  }

  return (
    <div className="payment-analytics-content">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Wszystkie płatności</h3>
            <CreditCard className="h-6 w-6 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{paymentAnalytics.totalPayments}</p>
          <p className="text-sm text-navy-600 mt-1">
            Łączna liczba transakcji
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Przychód</h3>
            <TrendingUp className="h-6 w-6 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">
            {paymentAnalytics.totalRevenue.toFixed(2)} PLN
          </p>
          <p className="text-sm text-navy-600 mt-1">
            Łączny przychód
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Zrealizowane</h3>
            <CheckCircle2 className="h-6 w-6 text-accent-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{paymentAnalytics.completedPayments}</p>
          <p className="text-sm text-navy-600 mt-1">
            Zakończone sukcesem
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-navy-600">Oczekujące</h3>
            <Clock className="h-6 w-6 text-yellow-500" />
          </div>
          <p className="text-3xl font-bold text-navy-900">{paymentAnalytics.pendingPayments}</p>
          <p className="text-sm text-navy-600 mt-1">
            W trakcie realizacji
          </p>
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-navy-900 flex items-center">
            <BarChart className="w-5 h-5 mr-2 text-gray-500" /> 
            Przychód według miesięcy ({paymentAnalytics.revenueByMonth.length})
          </h3>
          <button
            onClick={exportPaymentAnalytics}
            className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center"
          >
            <Download className="w-5 h-5 mr-2" />
            Eksportuj do CSV
          </button>
        </div>
        <div className="h-64">
          {paymentAnalytics.revenueByMonth.length > 0 ? (
            <Bar 
              data={{
                labels: paymentAnalytics.revenueByMonth.map(item => item.month),
                datasets: [
                  {
                    label: 'Przychód (PLN)',
                    data: paymentAnalytics.revenueByMonth.map(item => item.amount),
                    backgroundColor: 'rgba(16, 185, 129, 0.7)', // emerald-500
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 1,
                    borderRadius: 4,
                    hoverBackgroundColor: 'rgba(16, 185, 129, 0.9)',
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false,
                  },
                  tooltip: {
                    callbacks: {
                      label: function(context) {
                        const value = context.raw as number;
                        return `Przychód: ${value.toFixed(2)} PLN`;
                      }
                    }
                  }
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    ticks: {
                      callback: function(value) {
                        return value + ' PLN';
                      }
                    }
                  }
                }
              }}
            />
          ) : (
            <div className="h-full flex items-center justify-center">
              <p className="text-gray-500">Brak danych dla wybranego okresu</p>
            </div>
          )}
        </div>
      </div>

      {/* Payment Status Distribution */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-medium text-navy-900 mb-4 flex items-center">
          <PieChart className="w-5 h-5 mr-2 text-gray-500" />
          Rozkład statusów płatności ({paymentAnalytics.paymentsByStatus.length})
        </h3>
        <div className="h-64">
          {paymentAnalytics.paymentsByStatus.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
              <Pie
                data={{
                  labels: paymentAnalytics.paymentsByStatus.map(item => 
                    item.status === 'completed' ? 'Zrealizowane' :
                    item.status === 'pending' ? 'Oczekujące' :
                    'Nieudane'
                  ),
                  datasets: [
                    {
                      data: paymentAnalytics.paymentsByStatus.map(item => item.count),
                      backgroundColor: [
                        'rgba(34, 197, 94, 0.7)',  // green-500
                        'rgba(234, 179, 8, 0.7)',  // yellow-500
                        'rgba(239, 68, 68, 0.7)',  // red-500
                      ],
                      borderColor: [
                        'rgba(34, 197, 94, 1)',
                        'rgba(234, 179, 8, 1)',
                        'rgba(239, 68, 68, 1)',
                      ],
                      borderWidth: 1,
                      hoverOffset: 4,
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'right',
                      labels: {
                        usePointStyle: true,
                        padding: 15,
                        font: {
                          size: 12
                        }
                      }
                    },
                    tooltip: {
                      callbacks: {
                        label: function(context) {
                          const label = context.label || '';
                          const value = context.raw as number;
                          const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0) as number;
                          const percentage = Math.round((value / total) * 100);
                          return `${label}: ${value} (${percentage}%)`;
                        }
                      }
                    }
                  }
                }}
              />
            </div>
          ) : (
            <div className="h-full flex items-center justify-center">
              <p className="text-gray-500">Brak danych dla wybranego okresu</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}