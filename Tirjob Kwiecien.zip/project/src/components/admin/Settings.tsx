@@ .. @@
   // Insert default settings
   INSERT INTO admin_settings (key, value, setting_group)
   VALUES 
     -- Contact settings
     ('contact_email', 'kontakt@tirjob.pl', 'contact'),
     ('contact_phone', '+48 501 42 00 42', 'contact'),
     ('company_address', 'ul. Świeradowska 47\n02-662 Warszawa', 'contact'),
     
     -- Social media settings
     ('facebook_url', 'https://facebook.com/tirjob', 'social'),
     ('linkedin_url', 'https://linkedin.com/company/tirjob', 'social'),
     ('instagram_url', 'https://instagram.com/tirjob.pl', 'social'),
     
     -- Recruitment settings
     ('job_post_duration', '60', 'recruitment'),
+    ('job_post_premium_duration', '90', 'recruitment'),
     ('job_post_price', '500', 'recruitment'),
     ('job_post_premium_price', '750', 'recruitment'),
     
     -- SEO settings
     ('default_title', 'TirJob.pl - Portal pracy dla kierowców i specjalistów transportu', 'seo'),
     ('default_description', 'Znajdź pracę w branży transportowej. Oferty pracy dla kierowców, spedytorów i logistyków. Codziennie nowe ogłoszenia z całej Polski i Europy.', 'seo'),
     ('default_keywords', 'praca kierowca, praca transport, oferty pracy kierowca, kierowca C+E, praca spedytor', 'seo'),
     
     -- Branding settings
     ('logo_url', 'https://i.ibb.co/7NdqLD2G/2.png', 'branding'),
     ('favicon_url', '/vite.svg', 'branding'),
     ('primary_color', '#e11d48', 'branding')
   ON CONFLICT (key) DO UPDATE 
   SET 
     value = EXCLUDED.value,
     updated_at = now();