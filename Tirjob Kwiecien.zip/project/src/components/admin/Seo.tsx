@@ .. @@
                  <div>
                    <label htmlFor="schema_org" className="block text-sm font-medium text-gray-700 mb-1">
                      Schema.org JSON-LD
+                      <span className="text-xs text-gray-500 ml-2">(Zaawansowane)</span>
                    </label>
                    <div className="relative">
                      <textarea
@@ .. @@
                      {schemaOrgError ? (
                        <p className="mt-1 text-sm text-red-500 flex items-start">
                          <AlertCircle className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                          {schemaOrgError}
                        </p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
-                          Dane strukturalne w formacie JSON-LD
+                          Dane strukturalne w formacie JSON-LD dla wyszukiwarek. Pomaga w wyświetlaniu rozszerzonych wyników wyszukiwania.
                        </p>
                      )}
                      <div className="mt-4">
@@ .. @@
                          }}
                          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                        >
-                          Format JSON
+                          Formatuj JSON
                        </button>
+                        <button
+                          type="button"
+                          onClick={() => {
+                            // Generate a basic schema.org template based on page type
+                            let template = {};
+                            
+                            switch (formData.page_type) {
+                              case 'home':
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "WebSite",
+                                  "name": formData.title || "TirJob.pl",
+                                  "url": "https://tirjob.pl",
+                                  "description": formData.description || "Portal pracy dla kierowców i specjalistów transportu",
+                                  "potentialAction": {
+                                    "@type": "SearchAction",
+                                    "target": "https://tirjob.pl/search?q={search_term_string}",
+                                    "query-input": "required name=search_term_string"
+                                  }
+                                };
+                                break;
+                              case 'blog':
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "Blog",
+                                  "name": formData.title || "Blog TirJob.pl",
+                                  "url": "https://tirjob.pl/blog",
+                                  "description": formData.description || "Blog o branży transportowej"
+                                };
+                                break;
+                              case 'job-list':
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "ItemList",
+                                  "name": formData.title || "Oferty pracy",
+                                  "description": formData.description || "Lista ofert pracy w branży transportowej",
+                                  "itemListElement": [
+                                    {
+                                      "@type": "ListItem",
+                                      "position": 1,
+                                      "item": {
+                                        "@type": "JobPosting",
+                                        "title": "Przykładowa oferta pracy",
+                                        "description": "Opis przykładowej oferty pracy"
+                                      }
+                                    }
+                                  ]
+                                };
+                                break;
+                              case 'job-detail':
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "JobPosting",
+                                  "title": "Tytuł oferty pracy",
+                                  "description": "Opis oferty pracy",
+                                  "datePosted": new Date().toISOString(),
+                                  "employmentType": "FULL_TIME",
+                                  "hiringOrganization": {
+                                    "@type": "Organization",
+                                    "name": "Nazwa firmy",
+                                    "sameAs": "https://tirjob.pl"
+                                  },
+                                  "jobLocation": {
+                                    "@type": "Place",
+                                    "address": {
+                                      "@type": "PostalAddress",
+                                      "addressLocality": "Warszawa",
+                                      "addressCountry": "PL"
+                                    }
+                                  }
+                                };
+                                break;
+                              case 'contact':
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "Organization",
+                                  "name": "TirJob.pl",
+                                  "url": "https://tirjob.pl",
+                                  "contactPoint": {
+                                    "@type": "ContactPoint",
+                                    "telephone": "+48-501-420-042",
+                                    "contactType": "customer service",
+                                    "email": "kontakt@tirjob.pl"
+                                  }
+                                };
+                                break;
+                              default:
+                                template = {
+                                  "@context": "https://schema.org",
+                                  "@type": "WebPage",
+                                  "name": formData.title || "",
+                                  "description": formData.description || ""
+                                };
+                            }
+                            
+                            setSchemaOrgString(JSON.stringify(template, null, 2));
+                          }}
+                          className="px-4 py-2 ml-2 bg-accent-100 text-accent-700 rounded-lg hover:bg-accent-200 transition-colors text-sm"
+                        >
+                          Generuj szablon
+                        </button>
                      </div>
                    </div>
                  </div>