import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import type { UserRole } from '../../lib/types';
import { Alert, AlertTitle, AlertDescription } from '../../components/ui/Alert';

console.log('RequireRole component loaded');

interface RequireRoleProps {
  children: React.ReactNode;
  allowedRoles: UserRole[];
  redirectTo?: string;
}

export default function RequireRole({ children, allowedRoles, redirectTo }: RequireRoleProps) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const [renderCount, setRenderCount] = React.useState(0);
  
  React.useEffect(() => {
    setRenderCount(prev => prev + 1);
  }, []);
  
  console.log('RequireRole rendering with:', { 
    loading, 
    user: user ? { role: user.role, email: user.email } : null,
    allowedRoles, 
    path: location.pathname,
    renderCount
  });

  if (loading) {
    console.log('RequireRole: Still loading auth state');
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mb-4"></div>
          <p className="text-navy-600">Ładowanie...</p>
        </div>
      </div>
    );
  }

  // If user is not logged in, redirect to login
  if (!user) {
    console.log('RequireRole: No user, redirecting to login');
    return <Navigate to="/admin/login" state={{ from: location.pathname }} replace />;
  }
  
  // If user doesn't have required role
  if (!allowedRoles.includes(user.role)) {
    console.log('Access denied:', { userRole: user.role, allowedRoles });
    
    // If redirectTo is provided, redirect there
    if (redirectTo) {
      console.log('RequireRole: Redirecting to', redirectTo);
      return <Navigate to={redirectTo} replace />;
    }
    
    // Otherwise show access denied message
    return (
      <div className="min-h-screen bg-navy-50">
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <Alert variant="destructive" className="mb-6">
              <AlertTitle>Brak dostępu</AlertTitle>
              <AlertDescription>
                Nie masz uprawnień do wyświetlenia tej strony. Twoja rola: <strong>{user.role}</strong>
              </AlertDescription>
            </Alert>
            
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <h2 className="text-2xl font-bold text-navy-900 mb-4">Ograniczony dostęp</h2>
              <p className="text-navy-600 mb-6">
                Twoja rola ({user.role}) nie ma dostępu do tej sekcji panelu administracyjnego.
                Skontaktuj się z administratorem, jeśli uważasz, że powinieneś mieć dostęp.
              </p>
              
              {user.role === 'redaktor' && (
                <button
                  onClick={() => window.location.href = '/admin/blog'}
                  className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
                >
                  Przejdź do zarządzania blogiem
                </button>
              )}
              
              {user.role === 'moderator' && (
                <button
                  onClick={() => window.location.href = '/admin/jobs'}
                  className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
                >
                  Przejdź do zarządzania ogłoszeniami
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  console.log('RequireRole: Access granted, rendering children');
  return <>{children}</>;
}