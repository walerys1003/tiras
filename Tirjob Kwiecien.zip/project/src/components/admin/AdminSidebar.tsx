import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import {
  LayoutDashboard,
  FileText,
  Globe,
  BarChart,
  CreditCard,
  LogOut,
  Mail,
  BookOpen,
  Users,
  Settings
} from 'lucide-react';

interface MenuItem {
  name: string;
  icon: React.ElementType;
  path: string;
  color: string;
  roles: string[];
}

const menuItems: MenuItem[] = [
  {
    name: 'Dashboard',
    icon: LayoutDashboard,
    path: '/admin/dashboard',
    color: 'text-blue-600',
    roles: ['admin', 'redaktor', 'moderator']
  },
  {
    name: 'Ogłoszenia',
    icon: FileText,
    path: '/admin/jobs',
    color: 'text-green-600',
    roles: ['admin', 'moderator']
  },
  {
    name: 'Blog',
    icon: BookOpen,
    path: '/admin/blog',
    color: 'text-purple-600',
    roles: ['admin', 'redaktor']
  },
  {
    name: 'Newsletter',
    icon: Mail,
    path: '/admin/newsletter',
    color: 'text-pink-600',
    roles: ['admin']
  },
  {
    name: 'SEO',
    icon: Globe,
    path: '/admin/seo',
    color: 'text-blue-600',
    roles: ['admin']
  },
  {
    name: 'Analityka',
    icon: BarChart,
    path: '/admin/analytics',
    color: 'text-indigo-600',
    roles: ['admin', 'moderator']
  },
  {
    name: 'Płatności',
    icon: CreditCard,
    path: '/admin/payments',
    color: 'text-emerald-600',
    roles: ['admin', 'moderator']
  },
  {
    name: 'Użytkownicy',
    icon: Users,
    path: '/admin/users',
    color: 'text-teal-600',
    roles: ['admin']
  },
  {
    name: 'Ustawienia',
    icon: Settings,
    path: '/admin/settings',
    color: 'text-gray-600',
    roles: ['admin']
  }
];

export default function AdminSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      navigate('/admin/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-lg">
      <div className="flex flex-col h-full">
        <div className="px-6 py-8 border-b border-navy-100">
          <h1 className="text-2xl font-bold text-navy-900">Admin Panel</h1>
          <p className="text-sm text-navy-500 mt-1">TirJob.pl</p>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1">
          {menuItems.filter(item => user && item.roles.includes(user.role)).map((item) => (
            <a
              key={item.name}
              href={item.path}
              className={`flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors ${
                location.pathname === item.path
                  ? 'bg-navy-50 text-navy-900'
                  : ''
              }`}
            >
              <item.icon className={`h-5 w-5 mr-3 ${item.color}`} />
              {item.name}
            </a>
          ))}
        </nav>

        <div className="p-4 border-t border-navy-100">
          <div className="flex items-center">
            <div className="flex-1">
              <p className="text-sm font-medium text-navy-900">{user?.name || 'Użytkownik'}</p>
              <p className="text-xs text-navy-500">{user?.email}</p>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 text-navy-400 hover:text-navy-600 transition-colors"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}