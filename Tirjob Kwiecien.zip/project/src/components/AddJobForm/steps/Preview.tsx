import React from 'react';
import { Building2, MapPin, Banknote, Clock, Truck, Sparkles } from 'lucide-react';
import { JobFormData } from '..';
import { formatSalaryType } from '../../../lib/utils';
import { Link, useNavigate } from 'react-router-dom';
import { useSettings } from '../../../hooks/useSettings';

type PreviewProps = JobFormData & {
  acceptedTerms?: boolean;
  acceptedPrivacy?: boolean;
  setAcceptedTerms?: (accepted: boolean) => void;
  setAcceptedPrivacy?: (accepted: boolean) => void;
};

export default function Preview({
  position,
  country,
  voivodeship,
  city,
  workType,
  trailerType,
  schedule,
  duties,
  experience,
  languages,
  qualifications,
  benefits,
  companyName,
  salary,
  promotionOptions,
  acceptedTerms = false,
  acceptedPrivacy = false,
  setAcceptedTerms,
  setAcceptedPrivacy
}: PreviewProps) {
  const navigate = useNavigate();
  const [localAcceptedTerms, setLocalAcceptedTerms] = React.useState(acceptedTerms);
  const [localAcceptedPrivacy, setLocalAcceptedPrivacy] = React.useState(acceptedPrivacy);
  const { settings } = useSettings();
  
  // Get pricing information from settings
  const standardPrice = parseInt(settings.job_post_price || '500');
  const premiumPrice = parseInt(settings.job_post_premium_price || '750');
  const standardDuration = parseInt(settings.job_post_duration || '60');
  const premiumDuration = parseInt(settings.job_post_premium_duration || '90');

  // Update parent component state when local state changes
  React.useEffect(() => {
    if (setAcceptedTerms) {
      setAcceptedTerms(localAcceptedTerms);
    }
  }, [localAcceptedTerms, setAcceptedTerms]);

  React.useEffect(() => {
    if (setAcceptedPrivacy) {
      setAcceptedPrivacy(localAcceptedPrivacy);
    }
  }, [localAcceptedPrivacy, setAcceptedPrivacy]);

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-navy-900">
        Podgląd ogłoszenia
      </h2>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className={`p-6 border-b border-gray-200 ${
          promotionOptions.isPremium ? 'bg-gradient-to-r from-accent-50 to-white' : ''
        }`}>
          {promotionOptions.isPremium && (
            <div className="mb-4">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-500 text-white">
                <Sparkles className="w-4 h-4 mr-1" />
                Ogłoszenie Premium
              </span>
            </div>
          )}
          <h1 className="text-2xl font-bold text-navy-900 mb-2">
            {position.type ? `${position.type} – ${workType === 'domestic' ? 'Transport krajowy' : workType === 'international' ? 'Transport międzynarodowy' : '[Wybierz rodzaj pracy]'}` : '[Wybierz stanowisko]'}
          </h1>
          <div className="flex items-center text-gray-600">
            <Building2 className="w-4 h-4 mr-2" />
            <span>{companyName || '[Nazwa firmy]'}</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="p-6 space-y-6">
          {/* Key Details */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center text-gray-700">
              <MapPin className="w-4 h-4 mr-2 text-gray-500" />
              <div>
                {city && country ? (
                  <>
                    {city}, {country}
                    {country === 'Polska' && voivodeship && `, ${voivodeship}`}
                  </>
                ) : (
                  '[Wybierz lokalizację]'
                )}
              </div>
            </div>
            <div className="flex items-center text-gray-700">
              <Banknote className="w-4 h-4 mr-2 text-gray-500" />
              <div>
                {salary.amount && salary.type ? (
                  <>
                    {salary.amount} {salary.currency} ({formatSalaryType(salary.type)})
                  </>
                ) : (
                  '[Ustaw wynagrodzenie]'
                )}
              </div>
            </div>
            <div className="flex items-center text-gray-700">
              <Clock className="w-4 h-4 mr-2 text-gray-500" />
              <div>{schedule || '[Wybierz system pracy]'}</div>
            </div>
            <div className="flex items-center text-gray-700">
              <Truck className="w-4 h-4 mr-2 text-gray-500" />
              <div>{trailerType || '[Wybierz rodzaj naczepy]'}</div>
            </div>
          </div>

          {/* Requirements */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Wymagania</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              {experience && (
                <li>
                  Doświadczenie: {
                    experience === 'none' ? 'Brak wymagań' :
                    experience === '6m' ? 'Do 6 miesięcy' :
                    experience === '2y' ? 'Do 2 lat' :
                    experience === '5y' ? '2-5 lat' :
                    'Powyżej 5 lat'
                  }
                </li>
              )}
              {languages.length > 0 && (
                <li>Języki: {languages.join(', ')}</li>
              )}
              {qualifications.map((qual, index) => (
                <li key={index}>{qual}</li>
              ))}
              {!experience && languages.length === 0 && qualifications.length === 0 && (
                <li className="text-gray-400">[Dodaj wymagania]</li>
              )}
            </ul>
          </div>

          {/* Duties */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Zakres obowiązków</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              {duties.length > 0 ? (
                duties.map((duty, index) => (
                  <li key={index}>{duty}</li>
                ))
              ) : (
                <li className="text-gray-400">[Dodaj obowiązki]</li>
              )}
            </ul>
          </div>

          {/* Benefits */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Oferujemy</h3>
            <ul className="list-disc list-inside space-y-1 text-gray-600">
              {benefits.length > 0 ? (
                benefits.map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))
              ) : (
                <li className="text-gray-400">[Dodaj benefity]</li>
              )}
            </ul>
          </div>
        </div>
      </div>
      
      {/* Terms and Privacy Policy */}
      <div className="space-y-4 mt-8 border-t border-gray-200 pt-8">
        <div className="flex items-start">
          <div className="flex items-center h-5">
            <input
              id="terms"
              type="checkbox"
              checked={localAcceptedTerms}
              onChange={(e) => setLocalAcceptedTerms(e.target.checked)}
              className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
            />
          </div>
          <div className="ml-3">
            <label htmlFor="terms" className="text-sm text-gray-700">
              Akceptuję <Link to="/regulamin" className="text-accent-600 hover:text-accent-700" target="_blank">regulamin</Link> serwisu TirJob.pl
            </label>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="flex items-center h-5">
            <input
              id="privacy"
              type="checkbox"
              checked={localAcceptedPrivacy}
              onChange={(e) => setLocalAcceptedPrivacy(e.target.checked)}
              className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
            />
          </div>
          <div className="ml-3">
            <label htmlFor="privacy" className="text-sm text-gray-700">
              Akceptuję <Link to="/polityka-prywatnosci" className="text-accent-600 hover:text-accent-700" target="_blank">politykę prywatności</Link> serwisu TirJob.pl
            </label>
          </div>
        </div>
      </div>
      
      {/* Price Summary */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="font-semibold text-gray-900 mb-4">Podsumowanie płatności</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Standardowe ogłoszenie na ({standardDuration} dni)</span>
            <span>{standardPrice} PLN</span>
          </div>
          {promotionOptions.highlight && (
            <div className="flex justify-between text-accent-700">
              <span>Pakiet Premium (+{premiumDuration - standardDuration} dni)</span>
              <span>{premiumPrice - standardPrice} PLN</span>
            </div>
          )}
          <div className="pt-2 border-t border-accent-200">
            <div className="flex justify-between font-medium text-lg">
              <span>Razem brutto</span>
              <span>{promotionOptions.highlight ? premiumPrice : standardPrice} PLN</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}