import React from 'react';
import { ClipboardList, Award, Languages, Gift } from 'lucide-react';
import { JobFormData } from '..';
import { jobFormSchema } from '../../../lib/validations/job';
import { z } from 'zod';
import { languages, qualifications } from '../data';

type JobDetailsProps = JobFormData & {
  updateFields: (fields: Partial<JobFormData>) => void;
};

const jobDetailsSchema = jobFormSchema.pick({
  duties: true,
  experience: true,
  languages: true,
  qualifications: true,
  benefits: true
});

const defaultDuties = [
  'Transport krajowy/międzynarodowy',
  'Załadunek i rozładunek towarów',
  'Obsługa dokumentacji przewozowej',
  'Dbanie o powierzony pojazd'
];

const defaultBenefits = [
  'Nowoczesna flota pojazdów',
  'Premie za ekonomiczną jazdę',
  'Pokrycie kosztów podróży / noclegów',
  'Stałe trasy i przewidywalne godziny pracy'
];

export default function JobDetails({
  duties,
  experience,
  languages: selectedLanguages,
  qualifications: selectedQualifications,
  benefits,
  updateFields 
}: JobDetailsProps) {
  const [newDuty, setNewDuty] = React.useState('');
  const [newBenefit, setNewBenefit] = React.useState('');
  const [errors, setErrors] = React.useState<Partial<z.inferFormattedError<typeof jobDetailsSchema>>>({});

  const validateField = (field: keyof typeof errors, value: any) => {
    try {
      jobDetailsSchema.pick({ [field]: true }).parse({ [field]: value });
      setErrors(prev => ({ ...prev, [field]: undefined }));
    } catch (error) {
      if (error instanceof z.ZodError) {
        setErrors(prev => ({ ...prev, [field]: error.format()[field] }));
      }
    }
  };

  React.useEffect(() => {
    if (duties.length === 0) {
      updateFields({ duties: defaultDuties });
    }
    if (benefits.length === 0) {
      updateFields({ benefits: defaultBenefits });
    }
  }, []);

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-gray-900">
        Szczegóły stanowiska
      </h2>

      {/* Duties */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 flex items-center mb-4">
          <ClipboardList className="w-5 h-5 mr-2 text-gray-500" />
          Zakres obowiązków
        </h3>
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newDuty}
              onChange={e => setNewDuty(e.target.value)}
              placeholder="Dodaj nowy obowiązek"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
            />
            <button
              type="button"
              onClick={() => {
                if (newDuty.trim()) {
                  updateFields({ duties: [...duties, newDuty.trim()] });
                  setNewDuty('');
                }
              }}
              className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700"
            >
              Dodaj
            </button>
          </div>
          <div className="space-y-2">
            {duties.map((duty, index) => (
              <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                <span>{duty}</span>
                <button
                  type="button"
                  onClick={() => updateFields({
                    duties: duties.filter((_, i) => i !== index)
                  })}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Experience */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 flex items-center mb-4">
          <Award className="w-5 h-5 mr-2 text-gray-500" />
          Doświadczenie
        </h3>
        <div>
          <select
            value={experience}
            onChange={e => updateFields({ experience: e.target.value })}
            className={`w-full pl-3 pr-10 py-2.5 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
              errors.experience ? 'border-red-500' : 'border-gray-300'
            }`}
          >
            <option value="">Wybierz wymagane doświadczenie</option>
            <option value="none">Brak doświadczenia</option>
            <option value="6m">Do 6 miesięcy</option>
            <option value="2y">Do 2 lat</option>
            <option value="5y">2-5 lat</option>
            <option value="5y+">Powyżej 5 lat</option>
          </select>
          {errors.experience && (
            <p className="mt-1 text-sm text-red-500">{errors.experience._errors.join(', ')}</p>
          )}
        </div>
      </div>

      {/* Languages */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 flex items-center mb-4">
          <Languages className="w-5 h-5 mr-2 text-gray-500" />
          Wymagane języki
        </h3>
        {errors.languages && (
          <p className="mb-2 text-sm text-red-500">{errors.languages._errors.join(', ')}</p>
        )}
        <div className="flex flex-wrap gap-2">
          {languages.map(lang => (
            <label
              key={lang}
              className={`inline-flex items-center px-4 py-2 rounded-full border cursor-pointer transition-colors ${
                selectedLanguages.includes(lang)
                  ? 'bg-accent-50 border-accent-500 text-accent-700'
                  : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
              }`}
            >
              <input
                type="checkbox"
                className="sr-only"
                checked={selectedLanguages.includes(lang)}
                onChange={e => {
                  const newLanguages = e.target.checked
                    ? [...selectedLanguages, lang]
                    : selectedLanguages.filter(l => l !== lang);
                  updateFields({ languages: newLanguages });
                  validateField('languages', newLanguages);
                }}
              />
              <span>{lang}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Qualifications */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 flex items-center mb-4">
          <Award className="w-5 h-5 mr-2 text-gray-500" />
          Dodatkowe kwalifikacje
        </h3>
        <div className="flex flex-wrap gap-2">
          {qualifications.map(qual => (
            <label
              key={qual}
              className={`inline-flex items-center px-4 py-2 rounded-full border cursor-pointer transition-colors ${
                selectedQualifications.includes(qual)
                  ? 'bg-accent-50 border-accent-500 text-accent-700'
                  : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
              }`}
            >
              <input
                type="checkbox"
                className="sr-only"
                checked={selectedQualifications.includes(qual)}
                onChange={e => {
                  if (e.target.checked) {
                    updateFields({
                      qualifications: [...selectedQualifications, qual]
                    });
                  } else {
                    updateFields({
                      qualifications: selectedQualifications.filter(q => q !== qual)
                    });
                  }
                }}
              />
              <span>{qual}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Benefits */}
      <div>
        <h3 className="text-lg font-medium text-gray-900 flex items-center mb-4">
          <Gift className="w-5 h-5 mr-2 text-gray-500" />
          Benefity i warunki pracy
        </h3>
        {errors.benefits && (
          <p className="mb-2 text-sm text-red-500">{errors.benefits._errors.join(', ')}</p>
        )}
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={newBenefit}
              onChange={e => setNewBenefit(e.target.value)}
              placeholder="Dodaj nowy benefit"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
            />
            <button
              type="button"
              onClick={() => {
                if (newBenefit.trim()) {
                  updateFields({ benefits: [...benefits, newBenefit.trim()] });
                  setNewBenefit('');
                }
              }}
              className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700"
            >
              Dodaj
            </button>
          </div>
          <div className="space-y-2">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                <span>{benefit}</span>
                <button
                  type="button"
                  onClick={() => updateFields({
                    benefits: benefits.filter((_, i) => i !== index)
                  })}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}