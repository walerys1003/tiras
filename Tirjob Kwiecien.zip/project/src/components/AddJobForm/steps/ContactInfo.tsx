import React from 'react';
import { Building2, Mail, Phone, FileText, Receipt } from 'lucide-react';
import { JobFormData } from '..';
import { jobFormSchema } from '../../../lib/validations/job';
import { z } from 'zod';

type ContactInfoProps = JobFormData & {
  updateFields: (fields: Partial<JobFormData>) => void;
};

const contactInfoSchema = jobFormSchema.pick({
  companyName: true,
  email: true,
  phone: true,
  nip: true,
  invoiceData: true
});

export default function ContactInfo({
  companyName,
  email,
  phone,
  nip,
  invoiceData,
  updateFields
}: ContactInfoProps) {
  const [errors, setErrors] = React.useState<Partial<z.inferFormattedError<typeof contactInfoSchema>>>({});

  const validateField = (field: keyof typeof errors, value: any) => {
    try {
      contactInfoSchema.pick({ [field]: true }).parse({ [field]: value });
      setErrors(prev => ({ ...prev, [field]: undefined }));
    } catch (error) {
      if (error instanceof z.ZodError) {
        setErrors(prev => ({ ...prev, [field]: error.format()[field] }));
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Contact Details Section */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-gray-900">
          Dane kontaktowe
        </h2>

        {/* Company Name */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Nazwa firmy</h3>
          <input
            type="text"
            value={companyName}
            onChange={e => {
              const value = e.target.value;
              updateFields({ companyName: value });
              validateField('companyName', value);
            }}
            placeholder="Nazwa Twojej firmy"
            className={`w-full px-3 py-2.5 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
              errors.companyName ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.companyName && (
            <p className="mt-1 text-sm text-red-500">{errors.companyName._errors.join(', ')}</p>
          )}
        </div>

        {/* Email */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Email kontaktowy</h3>
          <input
            type="email"
            value={email}
            onChange={e => {
              const value = e.target.value;
              updateFields({ email: value });
              validateField('email', value);
            }}
            placeholder="email@firma.pl"
            className={`w-full px-3 py-2.5 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
              errors.email ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.email && (
            <p className="mt-1 text-sm text-red-500">{errors.email._errors.join(', ')}</p>
          )}
        </div>

        {/* Phone */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Numer telefonu</h3>
          <input
            type="tel"
            value={phone}
            onChange={e => {
              const value = e.target.value;
              updateFields({ phone: value });
              validateField('phone', value);
            }}
            placeholder="+48 123 456 789"
            className={`w-full px-3 py-2.5 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
              errors.phone ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.phone && (
            <p className="mt-1 text-sm text-red-500">{errors.phone._errors.join(', ')}</p>
          )}
        </div>
      </div>

      {/* Invoice Details Section */}
      <div className="pt-8 border-t border-gray-200 space-y-6">
        <h2 className="text-2xl font-bold text-gray-900 flex items-center">
          <Receipt className="w-6 h-6 mr-2 text-gray-500" />
          Dane do faktury (opcjonalnie)
        </h2>

        {/* Company Name */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Nazwa firmy</h3>
          <input
            type="text"
            value={invoiceData}
            onChange={e => updateFields({ invoiceData: e.target.value })}
            placeholder="Nazwa Twojej firmy"
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
        </div>

        {/* NIP */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">NIP (opcjonalnie)</h3>
          <input
            type="text"
            value={nip}
            onChange={e => updateFields({ nip: e.target.value })}
            placeholder="123-456-78-90"
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
        </div>

        {/* Email */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Email kontaktowy</h3>
          <input
            type="email"
            value={email}
            onChange={e => updateFields({ email: e.target.value })}
            placeholder="email@firma.pl"
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
        </div>

        {/* Phone */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-1">Numer telefonu</h3>
          <input
            type="tel"
            value={phone}
            onChange={e => updateFields({ phone: e.target.value })}
            placeholder="+48 123 456 789"
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          />
        </div>
      </div>
    </div>
  );
}