import React, { useEffect, useState } from 'react';
import { MapPin, Briefcase, Globe, Truck, Clock } from 'lucide-react';
import { JobFormData } from '..';
import { countries, positions, trailerTypes, scheduleTypes } from '../data'; 
import { supabase } from '../../../lib/supabase';

type BasicInfoProps = JobFormData & {
  updateFields: (fields: Partial<JobFormData>) => void;
};

interface Country {
  id: string;
  country_name: string;
}

interface Voivodeship {
  id: string;
  name: string;
}

interface City {
  id: string;
  city_name: string;
  country_id: string;
  voivodeship_id: string | null;
}

export default function BasicInfo({ 
  country,
  voivodeship,
  city,
  position,
  workType,
  trailerType,
  schedule,
  updateFields 
}: BasicInfoProps) {
  const [citySuggestions, setCitySuggestions] = useState<City[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showVoivodeship, setShowVoivodeship] = useState(true);
  const [showCity, setShowCity] = useState(false);
  const [countries, setCountries] = useState<Country[]>([]);
  const [voivodeships, setVoivodeships] = useState<Voivodeship[]>([]);
  const suggestionRef = React.useRef<HTMLDivElement>(null);
  const inputRef = React.useRef<HTMLInputElement>(null);

  // Fetch countries and voivodeships on mount
  useEffect(() => {
    const fetchData = async () => {
      const [countriesResponse, voivodeshipsResponse] = await Promise.all([
        supabase.from('job_countries').select('*').order('country_name'),
        supabase.from('job_voivodeships').select('*').order('name')
      ]);

      if (countriesResponse.data) {
        setCountries(countriesResponse.data);
      }
      if (voivodeshipsResponse.data) {
        setVoivodeships(voivodeshipsResponse.data);
      }
    };

    fetchData();
  }, []);

  // Handle country change
  useEffect(() => {
    const loadCities = async () => {
      if (!country) {
        setCitySuggestions([]);
        setShowVoivodeship(false);
        setShowCity(false);
        return;
      }

      const selectedCountry = countries.find(c => c.country_name === country);
      if (!selectedCountry) return;

      if (country === 'Polska') {
        setShowVoivodeship(true);
        setShowCity(false);
        setCitySuggestions([]);
      } else {
        setShowVoivodeship(false);
        setShowCity(true);

        const { data: cities } = await supabase
          .from('job_cities')
          .select('*')
          .eq('country_id', selectedCountry.id)
          .order('city_name');

        setCitySuggestions(cities || []);
      }
    };

    loadCities();
  }, [country, countries]);

  // Handle voivodeship change
  useEffect(() => {
    const loadCities = async () => {
      if (!country || !voivodeship || country !== 'Polska') return;

      const selectedVoivodeship = voivodeships.find(v => v.name === voivodeship);
      if (!selectedVoivodeship) return;

      const { data: cities } = await supabase
        .from('job_cities')
        .select('*')
        .eq('voivodeship_id', selectedVoivodeship.id)
        .order('city_name');

      setShowCity(true);
      setCitySuggestions(cities || []);
    };

    loadCities();
  }, [voivodeship, voivodeships, country]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node) &&
          inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleCityChange = (value: string) => {
    updateFields({ city: value });
    setShowSuggestions(true);
  };

  const handleCityFocus = () => {
    setShowSuggestions(true);
  };

  const handleSuggestionClick = (suggestion: City) => {
    updateFields({ city: suggestion.city_name });
    setShowSuggestions(false);
  };

  const getFilteredSuggestions = () => {
    if (!city) return citySuggestions;
    return citySuggestions.filter(suggestion => 
      suggestion.city_name.toLowerCase().includes(city.toLowerCase())
    );
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-navy-900">
        Podstawowe informacje
      </h2>

      {/* Location */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <MapPin className="w-5 h-5 mr-2 text-gray-500" />
          Lokalizacja
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <select
            value={country}
            onChange={e => updateFields({ country: e.target.value })}
            className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          >
            <option value="">Wybierz kraj</option>
            {countries.map(c => (
              <option key={c.id} value={c.country_name}>{c.country_name}</option>
            ))}
          </select>

          {showVoivodeship && (
            <select
              className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              value={voivodeship}
              onChange={e => updateFields({ voivodeship: e.target.value })}
            >
              <option value="">Wybierz województwo</option>
              {voivodeships.map(v => (
                <option key={v.id} value={v.name}>{v.name}</option>
              ))}
            </select>
          )}

          {showCity && (
            <div className="relative">
              <input
                ref={inputRef}
                type="text"
                value={city}
                onChange={e => handleCityChange(e.target.value)}
                onFocus={handleCityFocus}
                placeholder="Wpisz miasto"
                className="w-full px-3 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
              />
              {showSuggestions && citySuggestions.length > 0 && (
                <div
                  ref={suggestionRef}
                  className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-auto"
                >
                  {getFilteredSuggestions().map((suggestion) => (
                    <div
                      key={suggestion.id}
                      className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      {suggestion.city_name}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Position */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Briefcase className="w-5 h-5 mr-2 text-gray-500" />
          Stanowisko
        </h3>
        <div className="grid grid-cols-1 gap-4">
          <select
            value={position.category}
            onChange={e => updateFields({ 
              position: { ...position, category: e.target.value, type: '' }
            })}
            className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
          >
            <option value="">Wybierz kategorię</option>
            <option value="drivers">Kierowcy</option>
            <option value="logistics">Spedycja i logistyka</option>
            <option value="construction">Budownictwo i magazyny</option>
          </select>

          {position.category && (
            <select
              value={position.type}
              onChange={e => updateFields({
                position: { ...position, type: e.target.value }
              })}
              className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
            >
              <option value="">Wybierz stanowisko</option>
              {positions[position.category as keyof typeof positions].map(pos => (
                <option key={pos} value={pos}>{pos}</option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Work Type */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Globe className="w-5 h-5 mr-2 text-gray-500" />
          Rodzaj pracy
        </h3>
        <div className="flex gap-4">
          <button
            type="button"
            onClick={() => updateFields({ workType: 'domestic' })}
            className={`flex-1 py-2.5 px-4 rounded-lg border ${
              workType === 'domestic'
                ? 'bg-accent-50 border-accent-500 text-accent-700'
                : 'border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Krajowy
          </button>
          <button
            type="button"
            onClick={() => updateFields({ workType: 'international' })}
            className={`flex-1 py-2.5 px-4 rounded-lg border ${
              workType === 'international'
                ? 'bg-accent-50 border-accent-500 text-accent-700'
                : 'border-gray-300 text-gray-700 hover:bg-gray-50'
            }`}
          >
            Międzynarodowy
          </button>
        </div>
      </div>

      {/* Trailer Type */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Truck className="w-5 h-5 mr-2 text-gray-500" />
          Rodzaj naczepy
        </h3>
        <select
          value={trailerType}
          onChange={e => updateFields({ trailerType: e.target.value })}
          className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
        >
          <option value="">Wybierz rodzaj naczepy</option>
          {trailerTypes.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      {/* Schedule */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Clock className="w-5 h-5 mr-2 text-gray-500" />
          Tryb pracy
        </h3>
        <select
          value={schedule}
          onChange={e => updateFields({ schedule: e.target.value })}
          className="w-full pl-3 pr-10 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
        >
          <option value="">Wybierz system pracy</option>
          {scheduleTypes.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>
    </div>
  );
}