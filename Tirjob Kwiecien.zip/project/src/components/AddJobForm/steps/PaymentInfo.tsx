import React from 'react';
import { Banknote, Sparkles } from 'lucide-react';
import { JobFormData } from '..';
import { jobFormSchema } from '../../../lib/validations/job';
import { z } from 'zod';
import { useSettings } from '../../../hooks/useSettings';

type PaymentInfoProps = JobFormData & {
  updateFields: (fields: Partial<JobFormData>) => void;
};

const paymentInfoSchema = jobFormSchema.pick({
  salary: true,
  promotionOptions: true
});

export default function PaymentInfo({
  salary,
  promotionOptions,
  updateFields
}: PaymentInfoProps) {
  const [errors, setErrors] = React.useState<Partial<z.inferFormattedError<typeof paymentInfoSchema>>>({});
  const { settings } = useSettings();
  
  // Get pricing information from settings
  const standardPrice = parseInt(settings.job_post_price || '500');
  const premiumPrice = parseInt(settings.job_post_premium_price || '750');
  const standardDuration = parseInt(settings.job_post_duration || '60');
  const premiumDuration = parseInt(settings.job_post_premium_duration || '90');

  const validateField = (field: keyof typeof errors, value: any) => {
    try {
      paymentInfoSchema.pick({ [field]: true }).parse({ [field]: value });
      setErrors(prev => ({ ...prev, [field]: undefined }));
    } catch (error) {
      if (error instanceof z.ZodError) {
        setErrors(prev => ({ ...prev, [field]: error.format()[field] }));
      }
    }
  };

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-navy-900">
        Wynagrodzenie i promocja
      </h2>

      {/* Salary */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Banknote className="w-5 h-5 mr-2 text-gray-500" />
          Wynagrodzenie
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <select
            value={salary.type}
            onChange={e => {
              const newSalary = { ...salary, type: e.target.value };
              updateFields({ salary: newSalary });
              validateField('salary', newSalary);
            }}
            className={`w-full pl-3 pr-10 py-2.5 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
              errors.salary ? 'border-red-500' : 'border-gray-300'
            }`}
          >
            <option value="netto">Kwota netto</option>
            <option value="brutto">Kwota brutto</option>
            <option value="km">Stawka za kilometr</option>
            <option value="hour">Stawka godzinowa</option>
            <option value="month">Pensja miesięczna</option>
            <option value="day">Dzienna dieta</option>
          </select>

          <div className="flex">
            <input
              type="text"
              value={salary.amount}
              onChange={e => {
                // Allow only numbers and decimal point
                const value = e.target.value.replace(/[^\d.,]/g, '').replace(',', '.');
                if (!/^\d*\.?\d*$/.test(value) && value !== '') {
                  return;
                }
                const newSalary = { ...salary, amount: value };
                updateFields({ salary: newSalary });
                validateField('salary', newSalary);
              }}
              placeholder="Kwota"
              inputMode="decimal"
              pattern="[0-9]*[.,]?[0-9]*"
              className={`w-full pl-3 pr-3 py-2.5 border-y border-l rounded-l-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                errors.salary ? 'border-red-500' : 'border-gray-300'
              }`}
              aria-describedby="salary-error"
            />
            <select
              value={salary.currency}
              onChange={e => {
                const newSalary = { ...salary, currency: e.target.value };
                updateFields({ salary: newSalary });
                validateField('salary', newSalary);
              }}
              className={`px-3 py-2.5 border rounded-r-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent bg-gray-50 ${
                errors.salary ? 'border-red-500' : 'border-gray-300'
              }`}
            >
              <option value="PLN">PLN</option>
              <option value="EUR">EUR</option>
              <option value="GBP">GBP</option>
              <option value="USD">USD</option>
            </select>
          </div>
          {errors.salary && (
            <p id="salary-error" className="col-span-2 mt-1 text-sm text-red-500">
              {errors.salary._errors.join(', ')}
            </p>
          )}
        </div>
      </div>

      {/* Promotion Options */}
      <div>
        <h3 className="text-lg font-medium text-navy-900 flex items-center mb-4">
          <Sparkles className="w-5 h-5 mr-2 text-gray-500" />
          Wyróżnij swoje ogłoszenie
        </h3>
        <div className="bg-gradient-to-br from-accent-50 to-white rounded-lg p-6 border border-accent-100">
          <div className="flex items-start">
            <div className="flex items-center h-6">
              <input
                type="checkbox"
                checked={promotionOptions.highlight}
                onChange={e => updateFields({
                  promotionOptions: { 
                    ...promotionOptions, 
                    highlight: e.target.checked,
                    isPremium: e.target.checked 
                  }
                })}
                className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
              />
            </div>
            <div className="ml-3">
              <label className="font-medium text-gray-900">
                Ogłoszenie Premium
              </label>
              <p className="text-gray-600 mt-1">
                Zwiększ skuteczność swojego ogłoszenia:
              </p>
              <ul className="mt-2 space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-accent-500 mr-2" />
                  Wyróżnienie wizualne na liście ofert
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-accent-500 mr-2" />
                  Priorytetowa pozycja w wynikach wyszukiwania
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-accent-500 mr-2" />
                  Oznaczenie "Ogłoszenie Premium"
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 rounded-full bg-accent-500 mr-2" />
                  {premiumDuration} dni - większa skuteczność rekrutacji
                </li>
              </ul>
              <p className="mt-3 text-sm font-medium text-accent-700">
                Tylko +{premiumPrice - standardPrice} zł za {premiumDuration - standardDuration} dni więcej
              </p>
            </div>
          </div>
        </div>

        {/* Price Summary */}
        <div className="mt-6 bg-accent-50 rounded-lg p-6">
          <h4 className="font-medium text-accent-900 mb-4">Podsumowanie</h4>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Standardowe ogłoszenie na ({standardDuration} dni)</span>
              <span>{standardPrice} PLN</span>
            </div>
            {promotionOptions.highlight && (
              <div className="flex justify-between text-accent-700">
                <span>Pakiet Premium</span>
                <span>{premiumPrice - standardPrice} PLN</span>
              </div>
            )}
            <div className="pt-2 border-t border-accent-200">
              <div className="flex justify-between font-medium text-lg">
                <span>Razem brutto</span>
                <span>{promotionOptions.highlight ? premiumPrice : standardPrice} PLN</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}