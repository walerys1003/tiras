export const countries = [
  'Polska', 'Niemcy', 'Belgia', 'Holandia', 'Francja', 'Litwa', 
  'Norwegia', 'Czechy', 'Hiszpania', 'Włochy', 'Wielka Brytania'
];

export const voivodeships = [
  'Dolnośląskie', 'Kujawsko-pomorskie', 'Lubelskie', 'Lubuskie',
  'Łódzkie', 'Małopolskie', 'Mazowieckie', 'Opolskie', 'Podkarpackie',
  'Podlaskie', 'Pomorskie', 'Śląskie', 'Świętokrzyskie',
  'Warmińsko-mazurskie', 'Wielkopolskie', 'Zachodniopomorskie'
];

// Standardized driver license categories
export const driverLicenseCategories = [
  'kat. B', 'kat. B+E', 'kat. C', 'kat. C+E', 'kat. D', 'kat. D+E'
];

export const positions = {
  drivers: [
    'kat. B', 'kat. B+E', 'kat. C', 'kat. C+E', 'kat. D', 'kat. D+E',
    'Kierowca ADR', 'Kierowca transportu chłodniczego',
    'Kierowca transportu kontenerowego', 'Kierowca transportu specjalistycznego',
    'Kierowca transportu międzynarodowego', 'Kierowca transportu krajowego',
    'Kierowca autobusu'
  ],
  logistics: [
    'Spedytor', 'Spedytor międzynarodowy', 'Spedytor krajowy',
    'Dyspozytor', 'Planista transportu', 'Handlowiec w branży transportowej',
    'Opiekun floty', 'Referent ds. finansowo-księgowych'
  ],
  construction: [
    'Operator wózka widłowego', 'Operator maszyn budowlanych',
    'Magazynier', 'Inne stanowisko związane z transportem'
  ]
};

export const trailerTypes = [
  'Nie dotyczy',
  'Dowolny', 'Autotransporter', 'Bus < 3,5t', 'Chłodnia', 'Cysterna',
  'Hakowiec', 'Izoterma', 'Kłonicowa', 'Kontener', 'Mega',
  'Niskopodwoziowa', 'Plandeka', 'Platforma', 'Ponadgabaryt',
  'Silos', 'Tandem', 'Wywrotka'
];

export const scheduleTypes = [
  'kursy 1-dniowe', 'pn-pt', 'weekendy',
  '2/1', '2/2', '3/1', '4/1', '4/2', '6/2',
  'Inny system'
];

export const languages = [
  'Polski', 'Angielski', 'Niemiecki', 'Ukraiński', 'Rosyjski',
  'Rumuński', 'Litewski', 'Estoński', 'Czeski', 'Białoruski',
  'Słowacki', 'Włoski', 'Francuski', 'Hiszpański', 'Portugalski',
  'Norweski', 'Szwedzki', 'Turecki'
];

export const qualifications = [
  'ADR', 'Certyfikat kompetencji zawodowych', 'Dźwig (HDS)',
  'Karta kierowcy', 'Kurs na przewóz osób', 'Kurs na przewóz rzeczy',
  'Oferta otwarta dla obywateli Ukrainy', 'Umiejętność obsługi HDS',
  'Wózki widłowe', 'Znajomość procedur celnych', 'Znajomość tachografu'
];