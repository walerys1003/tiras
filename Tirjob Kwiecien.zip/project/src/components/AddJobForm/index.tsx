import React from 'react';
import { useMultiStepForm } from './useMultiStepForm';
import BasicInfo from './steps/BasicInfo';
import JobDetails from './steps/JobDetails';
import ContactInfo from './steps/ContactInfo';
import PaymentInfo from './steps/PaymentInfo';
import Preview from './steps/Preview';
import { ArrowLeft, ArrowRight, LayoutDashboard, FileText, Settings, BarChart, CreditCard, LogOut, Mail } from 'lucide-react';
import { jobFormSchema } from '../../lib/validations/job';
import { createJobListing } from '../../lib/jobs';
import type { z } from 'zod';
import { useNavigate, Link } from 'react-router-dom';

interface JobFormProps {
  admin?: boolean;
}

export type JobFormData = z.infer<typeof jobFormSchema> & {
  // Basic Info
  country: string;
  voivodeship: string;
  city: string;
  position: {
    category: string;
    type: string;
  };
  workType: string;
  trailerType: string;
  schedule: string;

  // Job Details
  duties: string[];
  experience: string;
  languages: string[];
  qualifications: string[];
  benefits: string[];

  // Contact Info
  companyName: string;
  email: string;
  phone: string;
  nip: string;
  invoiceData: string;

  // Payment Info
  salary: {
    type: string;
    amount: string;
    currency: string;
  };
  promotionOptions: {
    highlight: boolean;
    isPremium: boolean;
  };
}

const INITIAL_DATA: JobFormData = {
  country: '',
  voivodeship: '',
  city: '',
  position: {
    category: '',
    type: ''
  },
  workType: '',
  trailerType: '',
  schedule: '',
  duties: [],
  experience: '',
  languages: [],
  qualifications: [],
  benefits: [],
  companyName: '',
  email: '',
  phone: '',
  nip: '',
  invoiceData: '',
  salary: {
    type: 'netto',
    amount: '',
    currency: 'PLN'
  },
  promotionOptions: {
    highlight: false,
    isPremium: false
  }
};

export default function AddJobForm({ admin = false }: JobFormProps) {
  const [data, setData] = React.useState(INITIAL_DATA);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const navigate = useNavigate();

  const [acceptedTerms, setAcceptedTerms] = React.useState<boolean>(false);
  const [acceptedPrivacy, setAcceptedPrivacy] = React.useState<boolean>(false);

  function updateFields(fields: Partial<JobFormData>) {
    setData(prev => ({ ...prev, ...fields }));
  }

  const {
    steps,
    currentStepIndex,
    step,
    isFirstStep,
    isLastStep,
    back,
    next
  } = useMultiStepForm([
    <BasicInfo {...data} updateFields={updateFields} />,
    <JobDetails {...data} updateFields={updateFields} />,
    <ContactInfo {...data} updateFields={updateFields} />,
    <PaymentInfo {...data} updateFields={updateFields} />,
    <Preview 
      {...data} 
      acceptedTerms={acceptedTerms} 
      acceptedPrivacy={acceptedPrivacy} 
      setAcceptedTerms={setAcceptedTerms} 
      setAcceptedPrivacy={setAcceptedPrivacy} 
    />
  ]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    try {
      // Validate current step
      let validationResult;
      let fieldsToValidate = {};

      if (currentStepIndex === 0) {
        fieldsToValidate = {
          country: true,
          voivodeship: true,
          city: true,
          position: true,
          workType: true,
          trailerType: true,
          schedule: true
        };
      } else if (currentStepIndex === 1) {
        fieldsToValidate = {
          duties: true,
          experience: true,
          languages: true,
          qualifications: true,
          benefits: true
        };
      } else if (currentStepIndex === 2) {
        fieldsToValidate = {
          companyName: true,
          email: true,
          phone: true,
          nip: true,
          invoiceData: true
        };
      } else if (currentStepIndex === 3) {
        fieldsToValidate = {
          salary: true,
          promotionOptions: true
        };
      }

      validationResult = jobFormSchema.pick(fieldsToValidate).safeParse(data);

      if (!validationResult?.success) {
        const errors = validationResult.error.errors
          .map(err => `• ${err.message}`)
          .join('\n');
        alert(`Proszę uzupełnić wszystkie wymagane pola:\n\n${errors}`);
        return;
      }

      if (!isLastStep) {
        next();
        return;
      }

      // Check terms and privacy acceptance
      if (!acceptedTerms || !acceptedPrivacy) {
        alert('Proszę zaakceptować regulamin i politykę prywatności');
        return;
      }

      // Validate entire form before final submission
      const finalValidation = jobFormSchema.safeParse(data);
      if (!finalValidation.success) {
        const errors = finalValidation.error.errors
          .map(err => `• ${err.message}`)
          .join('\n');
        alert(`Proszę uzupełnić wszystkie wymagane pola:\n\n${errors}`);
        return;
      }

      // Handle final submission
      setIsSubmitting(true);
      try {
        const result = await createJobListing(data, false); // false means inactive
        if (result.success) {
          navigate(`/platnosc/${result.jobId}`);
        } else {
          const errorMessage = result.error?.message || 'Spróbuj ponownie później.';
          alert(`Wystąpił błąd podczas zapisywania ogłoszenia:\n\n${errorMessage}`);
        }
      } catch (error) {
        console.error('Error submitting form:', error);
        const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
        alert(`Wystąpił nieoczekiwany błąd podczas zapisywania ogłoszenia:\n\n${errorMessage}\n\nSpróbuj ponownie później.`);
      } finally {
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error('Validation error:', { error });
    }
  }

  if (admin) {
    return (
      <div className="min-h-screen bg-navy-50">
        <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-lg">
          <div className="flex flex-col h-full">
            <div className="px-6 py-8 border-b border-navy-100">
              <h1 className="text-2xl font-bold text-navy-900">Admin Panel</h1>
              <p className="text-sm text-navy-500 mt-1">TirJob.pl</p>
            </div>

            <nav className="flex-1 px-4 py-6 space-y-1">
              <a
                href="/admin/dashboard"
                className="flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors"
              >
                <LayoutDashboard className="h-5 w-5 mr-3 text-blue-600" />
                Dashboard
              </a>
              <a
                href="/admin/jobs"
                className="flex items-center px-4 py-3 text-navy-900 bg-navy-50 rounded-lg"
              >
                <FileText className="h-5 w-5 mr-3 text-green-600" />
                Ogłoszenia
              </a>
              <a
                href="/admin/newsletter"
                className="flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors"
              >
                <Mail className="h-5 w-5 mr-3 text-pink-600" />
                Newsletter
              </a>
              <a
                href="/admin/seo"
                className="flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors"
              >
                <Settings className="h-5 w-5 mr-3 text-orange-600" />
                SEO
              </a>
              <a
                href="/admin/analytics"
                className="flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors"
              >
                <BarChart className="h-5 w-5 mr-3 text-indigo-600" />
                Analityka
              </a>
              <a
                href="/admin/payments"
                className="flex items-center px-4 py-3 text-navy-600 rounded-lg hover:bg-navy-50 transition-colors"
              >
                <CreditCard className="h-5 w-5 mr-3 text-emerald-600" />
                Płatności
              </a>
            </nav>

            <div className="p-4 border-t border-navy-100">
              <div className="flex items-center">
                <div className="flex-1">
                  <p className="text-sm font-medium text-navy-900">Administrator</p>
                  <p className="text-xs text-navy-500">admin@tirjob.pl</p>
                </div>
                <button
                  onClick={() => navigate('/admin')}
                  className="p-2 text-navy-400 hover:text-navy-600 transition-colors"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="ml-64 p-8">
          <div className="max-w-3xl mx-auto">
            <div className="mb-8 flex items-center justify-between">
              <div className="flex items-center">
                <button
                  onClick={() => navigate('/admin/jobs')}
                  className="mr-4 p-2 hover:bg-white rounded-lg transition-colors"
                >
                  <ArrowLeft className="w-6 h-6 text-navy-600" />
                </button>
                <h1 className="text-2xl font-bold text-navy-900">Dodaj ogłoszenie</h1>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8">
               {/* Progress Bar */}
               <div className="mb-8">
                 <div className="flex justify-between mb-2">
                   {steps.map((_, index) => (
                     <div
                       key={index}
                       className={`flex-1 h-2 rounded-full mx-1 ${
                         index <= currentStepIndex ? 'bg-accent-500' : 'bg-gray-200'
                       }`}
                     />
                   ))}
                 </div>
                 <div className="flex justify-between text-sm text-gray-500">
                   <span>Podstawowe informacje</span>
                   <span>Szczegóły stanowiska</span>
                   <span>Kontakt</span>
                   <span>Płatność</span>
                   <span>Podgląd</span>
                 </div>
               </div>

               <form onSubmit={onSubmit}>
                 {step}

                 <div className="mt-8 flex justify-between">
                   {!isFirstStep && (
                     <button
                       type="button"
                       onClick={back}
                       className="flex items-center px-6 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                     >
                       <ArrowLeft className="w-4 h-4 mr-2" />
                       Wstecz
                     </button>
                   )}
                   <div className="ml-auto">
                     <button
                       type="submit"
                       disabled={isSubmitting}
                       className={`flex items-center px-8 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors ${
                         isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                       }`}
                     >
                       {isLastStep ? (
                         isSubmitting ? 'Zapisywanie...' : 'Przejdź do płatności'
                       ) : (
                         <>
                           Dalej
                           <ArrowRight className="w-4 h-4 ml-2" />
                         </>
                       )}
                     </button>
                   </div>
                 </div>
               </form>
             </div>
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`flex-1 h-2 rounded-full mx-1 ${
                    index <= currentStepIndex ? 'bg-accent-500' : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
            <div className="flex justify-between text-sm text-gray-500">
              <span>Podstawowe informacje</span>
              <span>Szczegóły stanowiska</span>
              <span>Kontakt</span>
              <span>Płatność</span>
              <span>Podgląd</span>
            </div>
          </div>

          <form onSubmit={onSubmit}>
            {step}

            <div className="mt-8 flex justify-between">
              {!isFirstStep && (
                <button
                  type="button"
                  onClick={back}
                  className="flex items-center px-6 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Wstecz
                </button>
              )}
              <div className="ml-auto">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`flex items-center px-8 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors ${
                    isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isLastStep ? (
                    isSubmitting ? 'Zapisywanie...' : 'Przejdź do płatności'
                  ) : (
                    <>
                      Dalej
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}