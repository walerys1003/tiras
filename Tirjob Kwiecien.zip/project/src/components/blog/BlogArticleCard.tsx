import React from 'react';
import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { BlogPostProps } from '../BlogPost';

interface BlogArticleCardProps {
  post: BlogPostProps;
  featured?: boolean;
  getCategoryBadgeColor: (category: string) => string;
}

export default function BlogArticleCard({ post, featured = false, getCategoryBadgeColor }: BlogArticleCardProps) {
  const navigate = useNavigate();

  // Function to strip HTML tags for excerpt display
  const stripHtml = (html: string) => {
    const tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  };

  // Get a clean excerpt from the content if needed
  const getExcerpt = () => {
    if (post.excerpt) return post.excerpt;
    
    const strippedContent = stripHtml(post.content);
    return strippedContent.length > 150 
      ? strippedContent.substring(0, 150) + '...' 
      : strippedContent;
  };

  return (
    <div 
      className={`
        relative bg-white rounded-3xl shadow-lg overflow-hidden 
        hover:shadow-xl transition-all duration-300 cursor-pointer 
        h-full flex flex-col transform hover:-translate-y-1
        z-10
      `}
      onClick={() => navigate(`/blog/${post.id}`)}
    >
      <div className={`relative ${featured ? 'h-[400px]' : 'h-48'} overflow-hidden`}>
        <img 
          src={post.image} 
          alt={post.title} 
          className="absolute inset-0 w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute top-4 left-4 z-20">
          <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getCategoryBadgeColor(post.category)}`}>
            {post.category}
          </span>
        </div>
      </div>
      <div className={`p-${featured ? '8' : '6'} flex flex-col flex-grow relative z-10`}>
        <div className="flex items-center text-sm text-navy-500 mb-3">
          <Calendar className="w-4 h-4 mr-1" />
          <span>{post.publishedAt}</span>
          <span className="mx-2">•</span>
          <Clock className="w-4 h-4 mr-1" />
          <span>{post.readTime} czytania</span>
        </div>
        <h3 className={`${featured ? 'text-3xl' : 'text-xl'} font-bold text-navy-900 mb-3 leading-tight hover:text-accent-600 transition-colors`}>
          {post.title}
        </h3>
        <p className={`text-navy-600 mb-4 ${featured ? 'text-lg' : 'line-clamp-3'} flex-grow`}>
          {getExcerpt()}
        </p>
        <div className="flex items-center justify-between mt-auto">
          <div className="flex items-center">
            <div className={`w-${featured ? '10' : '8'} h-${featured ? '10' : '8'} rounded-full bg-navy-100 flex items-center justify-center text-navy-700 font-bold ${featured ? '' : 'text-xs'}`}>
              {post.author.name.split(' ').map(name => name[0]).join('')}
            </div>
            <span className={`ml-${featured ? '3' : '2'} font-medium text-navy-800 ${featured ? '' : 'text-sm'}`}>{post.author.name}</span>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/blog/${post.id}`);
            }}
            className="text-accent-600 hover:text-accent-700 font-medium flex items-center text-sm"
          >
            {featured ? 'Czytaj dalej' : 'Czytaj'}
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>
        </div>
      </div>
    </div>
  );
}