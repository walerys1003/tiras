import React from 'react';
import { Mail, Phone, Truck } from 'lucide-react';

export default function BlogCTA() {
  return (
    <div className="relative bg-gradient-to-br from-navy-700 to-navy-800 rounded-3xl p-10 overflow-hidden mb-16 animate-on-scroll">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-60 h-60 bg-navy-600/30 rounded-br-[120px]"></div>
      <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-navy-600/20 rounded-tl-[160px]"></div>
      <div className="absolute top-1/3 right-1/4 w-20 h-20 bg-accent-500/10 rounded-full"></div>
      <div className="absolute bottom-1/4 left-1/4 w-16 h-16 bg-accent-500/10 rounded-full"></div>
      
      <div className="relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="lg:w-3/5 text-center lg:text-left">
            <h2 className="text-3xl font-bold text-white mb-6">
              📢 Bądź na bieżąco z branżą transportową!
            </h2>
            <p className="text-xl text-navy-100 mb-4">
              👉 Sprawdź najnowsze artykuły już teraz! 🚛
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <a href="mailto:kontakt@tirjob.pl" className="inline-flex items-center justify-center px-6 py-3 bg-white text-navy-800 rounded-xl hover:bg-navy-100 transition-colors shadow-lg">
                <Mail className="w-5 h-5 mr-2 text-navy-600" />
                kontakt@tirjob.pl
              </a>
              <a href="tel:+48501420042" className="inline-flex items-center justify-center px-6 py-3 bg-white text-navy-800 rounded-xl hover:bg-navy-100 transition-colors shadow-lg">
                <Phone className="w-5 h-5 mr-2 text-navy-600" />
                +48 501 42 00 42
              </a>
            </div>
          </div>
          <div className="lg:w-2/5 flex justify-center">
            <div className="w-32 h-32 lg:w-44 lg:h-44 bg-white/10 rounded-full flex items-center justify-center animate-pulse">
              <Truck className="w-24 h-24 lg:w-32 lg:h-32 text-white" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}