import React, { useEffect, useState } from 'react';
import { getBlogCategories, getCategoryIcon, getCategoryStyles, type BlogCategory } from '../../lib/blog';

interface BlogCategoriesProps {
  onCategoryClick: (categoryId: string) => void;
}

export default function BlogCategories({ onCategoryClick }: BlogCategoriesProps) {
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCategories = async () => {
      const data = await getBlogCategories();
      setCategories(data);
      setLoading(false);
    };

    loadCategories();
  }, []);

  if (loading) {
    return (
      <div className="mb-20">
        <h2 className="text-3xl font-bold text-navy-800 mb-8 text-center">
          Kategorie tematyczne
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-5 shadow-md border border-navy-100/50 flex items-center gap-4 animate-pulse"
            >
              <div className="w-12 h-12 rounded-full bg-navy-100/40"></div>
              <div className="flex-1">
                <div className="h-5 bg-navy-100/40 rounded w-3/4 mb-2"></div>
                <div className="h-1 bg-accent-700/40 rounded-full w-12"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-20">
      <h2 className="text-3xl font-bold text-navy-800 mb-8 text-center">
        Kategorie tematyczne
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category, index) => {
          const Icon = getCategoryIcon(category.slug);
          const styles = getCategoryStyles(category.slug);

          return (
            <div 
              key={category.id}
              className={`
                bg-white rounded-xl p-5 shadow-md hover:shadow-lg 
                transition-all duration-300 border border-navy-100/50 
                flex items-center gap-4 cursor-pointer 
                transform hover:-translate-y-1
                opacity-100 translate-y-0
              `}
              style={{
                transitionDelay: `${index * 100}ms`
              }}
              onClick={() => onCategoryClick(category.id)}
            >
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${styles.iconBg}`}>
                <Icon className={`w-6 h-6 ${styles.iconColor}`} />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-navy-800 mb-1">
                  {category.title}
                </h3>
                {category.description && (
                  <p className="text-sm text-navy-600 mb-2">{category.description}</p>
                )}
                <div className="flex items-center">
                  <span className="w-12 h-0.5 bg-accent-700/40 rounded-full"></span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}