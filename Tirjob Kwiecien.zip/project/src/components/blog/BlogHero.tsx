import React from 'react';
import { Truck } from 'lucide-react';

export default function BlogHero() {
  return (
    <div className="relative overflow-hidden pt-20 pb-16">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
        <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
        <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
        <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
      </div>
      
      {/* Animated Truck Icon */}
      <div className="absolute bottom-0 left-0 opacity-10 animate-float">
        <Truck className="w-64 h-64 text-navy-400" />
      </div>
      
      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
        <div className="text-center mb-12 animate-on-scroll">
          <span className="inline-block px-4 py-2 rounded-full bg-navy-100/50 text-navy-700 font-medium text-sm mb-4">
            NAJNOWSZE ARTYKUŁY I PORADY
          </span>
          <h1 className="text-5xl font-bold text-navy-900 mb-6">
            🚛 Blog TirJob – Wiedza i Trendy dla Branży Transportowej
          </h1>
          <p className="text-xl text-navy-600/90 max-w-3xl mx-auto">
            Najświeższe informacje, praktyczne porady i nowinki z rynku transportowego – wszystko w jednym miejscu!
          </p>
        </div>
      </div>
    </div>
  );
}