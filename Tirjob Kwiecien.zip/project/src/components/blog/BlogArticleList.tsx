import React from 'react';
import { ChevronLeft, ArrowRight } from 'lucide-react';
import BlogArticleCard from './BlogArticleCard';
import BlogPagination from './BlogPagination';
import type { BlogPostProps } from '../BlogPost';

interface BlogArticleListProps {
  selectedCategory: string | null;
  currentPage: number;
  articles: BlogPostProps[];
  totalPages: number;
  onPageChange: (page: number) => void;
  onClearCategory: () => void;
  getCategoryBadgeColor: (category: string) => string;
  categories: Array<{ id: string; title: string }>;
  loading: boolean;
}

export default function BlogArticleList({
  selectedCategory,
  currentPage,
  articles,
  totalPages,
  onPageChange,
  onClearCategory,
  getCategoryBadgeColor,
  categories,
  loading
}: BlogArticleListProps) {
  const selectedCategoryTitle = categories.find(c => c.id === selectedCategory)?.title;

  if (loading) {
    return (
      <div id="articles-section" className="mb-20">
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
        </div>
      </div>
    );
  }

  if (!loading && articles.length === 0) {
    return (
      <div id="articles-section" className="mb-20">
        <div className="text-center py-12">
          <p className="text-lg text-navy-600">
            {selectedCategory 
              ? 'Brak artykułów w tej kategorii.'
              : 'Brak dostępnych artykułów.'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div id="articles-section" className="relative z-10 mb-20">
      {selectedCategory ? (
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <button 
              onClick={onClearCategory}
              className="mr-4 p-2 rounded-full bg-navy-50 hover:bg-navy-100 transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-navy-600" />
            </button>
            <h2 className="text-3xl font-bold text-navy-800">
              {selectedCategoryTitle || 'Artykuły'}
            </h2>
          </div>
          <div className="text-accent-600 hover:text-accent-700 font-medium flex items-center">
            <span>{articles.length} artykułów</span>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-navy-800">
            Polecane artykuły
          </h2>
          <a href="#" className="text-accent-600 hover:text-accent-700 font-medium flex items-center">
            Zobacz wszystkie
            <ArrowRight className="w-4 h-4 ml-2" />
          </a>
        </div>
      )}

      {!selectedCategory && articles.length > 0 && (
        <>
          {/* Featured Article */}
          <div className="mb-12">
            <BlogArticleCard 
              post={articles[0]} 
              featured={true}
              getCategoryBadgeColor={getCategoryBadgeColor}
            />
          </div>

          {/* Regular Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {articles.slice(1, 4).map((post) => (
              <BlogArticleCard 
                key={post.id} 
                post={post}
                getCategoryBadgeColor={getCategoryBadgeColor}
              />
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {articles.slice(4, 7).map((post) => (
              <BlogArticleCard 
                key={post.id} 
                post={post}
                getCategoryBadgeColor={getCategoryBadgeColor}
              />
            ))}
          </div>
        </>
      )}

      {selectedCategory && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((post) => (
            <BlogArticleCard 
              key={post.id} 
              post={post}
              getCategoryBadgeColor={getCategoryBadgeColor}
            />
          ))}
        </div>
      )}

      {selectedCategory && totalPages > 1 && (
        <BlogPagination 
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={onPageChange}
        />
      )}
    </div>
  );
}