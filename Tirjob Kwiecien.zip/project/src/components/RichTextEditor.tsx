import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import TextAlign from '@tiptap/extension-text-align';
import Underline from '@tiptap/extension-underline';
import {
  Bold,
  Italic,
  Strikethrough,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Heading3,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Image as ImageIcon,
  Link as LinkIcon,
  Type
} from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
}

const MenuButton = ({ 
  icon: Icon, 
  title, 
  action,
  isActive = false
}: { 
  icon: any; 
  title: string; 
  action: () => void;
  isActive?: boolean;
}) => (
  <button
    type="button"
    onClick={action}
    className={`p-2 rounded-lg transition-colors ${
      isActive 
        ? 'bg-accent-100 text-accent-600' 
        : 'hover:bg-gray-100 text-gray-600'
    }`}
    title={title}
  >
    <Icon className="w-5 h-5" />
  </button>
);

const RichTextEditor = ({ value, onChange, placeholder, required }: Props) => {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3]
        }
      }),
      Image,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-accent-500 hover:text-accent-600 underline',
        },
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Underline,
    ],
    content: value,
    onUpdate: ({ editor }) => {
      const content = editor.getHTML();
      onChange(content);
    },
    editorProps: {
      attributes: {
        class: 'prose max-w-none focus:outline-none min-h-[200px] px-4 py-2',
        ...(placeholder && { 'data-placeholder': placeholder }),
      },
    },
  });

  // Update editor content when value prop changes
  React.useEffect(() => {
    if (editor && editor.isEditable && value !== editor.getHTML()) {
      editor.commands.setContent(value);
    }
  }, [value, editor]);

  // Cleanup editor on unmount
  React.useEffect(() => {
    return () => {
      // Safely destroy editor if it exists and has a destroy method
      try {
        if (editor && typeof editor.destroy === 'function') {
          editor.destroy();
        }
      } catch (error) {
        console.error('Error destroying editor:', error);
      }
    };
  }, [editor]);

  if (!editor) {
    return null;
  }

  const addImage = () => {
    const url = window.prompt('Enter image URL');
    if (url) {
      editor.chain().focus().setImage({ src: url }).run();
    }
  };

  const setLink = () => {
    const previousUrl = editor.getAttributes('link').href;
    const url = window.prompt('Enter link URL', previousUrl);

    if (url === null) {
      return;
    }

    if (url === '') {
      editor.chain().focus().unsetLink().run();
      return;
    }

    editor.chain().focus().setLink({ href: url }).run();
  };

  return (
    <div className="border border-gray-300 rounded-lg overflow-hidden">
      <style
        dangerouslySetInnerHTML={{
          __html: `
            .ProseMirror {
              min-height: 300px;
            }
            .ProseMirror:empty::before {
              color: #adb5bd;
              content: attr(data-placeholder);
              float: left;
              height: 0;
              pointer-events: none;
              position: absolute;
            }
            .ProseMirror:not(:empty)::before {
              content: none;
            }
            .ProseMirror h1 {
              font-size: 2em;
              font-weight: bold;
              margin-top: 0.67em;
              margin-bottom: 0.67em;
            }
            .ProseMirror h2 {
              font-size: 1.5em;
              font-weight: bold;
              margin-top: 0.83em;
              margin-bottom: 0.83em;
            }
            .ProseMirror h3 {
              font-size: 1.17em;
              font-weight: bold;
              margin-top: 1em;
              margin-bottom: 1em;
            }
            .ProseMirror p {
              margin-top: 1em;
              margin-bottom: 1em;
            }
            .ProseMirror ul, .ProseMirror ol {
              padding-left: 1.5em;
              margin-top: 1em;
              margin-bottom: 1em;
            }
            .ProseMirror ul {
              list-style-type: disc;
            }
            .ProseMirror ol {
              list-style-type: decimal;
            }
          `
        }}
      />

      {/* Menu Bar */}
      <div className="flex flex-wrap items-center gap-1 p-2 bg-gray-50 border-b border-gray-300 sticky top-0 z-10">
        <div className="flex items-center border-r border-gray-300 pr-2 mr-2">
          <MenuButton
            icon={Heading1}
            title="Heading 1"
            action={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
            isActive={editor.isActive('heading', { level: 1 })}
          />
          <MenuButton
            icon={Heading2}
            title="Heading 2"
            action={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
            isActive={editor.isActive('heading', { level: 2 })}
          />
          <MenuButton
            icon={Heading3}
            title="Heading 3"
            action={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
            isActive={editor.isActive('heading', { level: 3 })}
          />
          <MenuButton
            icon={Type}
            title="Paragraph"
            action={() => editor.chain().focus().setParagraph().run()}
            isActive={editor.isActive('paragraph')}
          />
        </div>

        <div className="flex items-center border-r border-gray-300 pr-2 mr-2">
          <MenuButton
            icon={Bold}
            title="Bold"
            action={() => editor.chain().focus().toggleBold().run()}
            isActive={editor.isActive('bold')}
          />
          <MenuButton
            icon={Italic}
            title="Italic"
            action={() => editor.chain().focus().toggleItalic().run()}
            isActive={editor.isActive('italic')}
          />
          <MenuButton
            icon={UnderlineIcon}
            title="Underline"
            action={() => editor.chain().focus().toggleUnderline().run()}
            isActive={editor.isActive('underline')}
          />
          <MenuButton
            icon={Strikethrough}
            title="Strikethrough"
            action={() => editor.chain().focus().toggleStrike().run()}
            isActive={editor.isActive('strike')}
          />
        </div>

        <div className="flex items-center border-r border-gray-300 pr-2 mr-2">
          <MenuButton
            icon={List}
            title="Bullet List"
            action={() => editor.chain().focus().toggleBulletList().run()}
            isActive={editor.isActive('bulletList')}
          />
          <MenuButton
            icon={ListOrdered}
            title="Numbered List"
            action={() => editor.chain().focus().toggleOrderedList().run()}
            isActive={editor.isActive('orderedList')}
          />
        </div>

        <div className="flex items-center border-r border-gray-300 pr-2 mr-2">
          <MenuButton
            icon={AlignLeft}
            title="Align Left"
            action={() => editor.chain().focus().setTextAlign('left').run()}
            isActive={editor.isActive({ textAlign: 'left' })}
          />
          <MenuButton
            icon={AlignCenter}
            title="Align Center"
            action={() => editor.chain().focus().setTextAlign('center').run()}
            isActive={editor.isActive({ textAlign: 'center' })}
          />
          <MenuButton
            icon={AlignRight}
            title="Align Right"
            action={() => editor.chain().focus().setTextAlign('right').run()}
            isActive={editor.isActive({ textAlign: 'right' })}
          />
        </div>

        <div className="flex items-center">
          <MenuButton
            icon={ImageIcon}
            title="Add Image"
            action={addImage}
          />
          <MenuButton
            icon={LinkIcon}
            title="Add Link"
            action={setLink} 
            isActive={editor.isActive('link')}
          />
        </div>
      </div>

      {/* Editor Content */}
      <EditorContent editor={editor} required={required} />
    </div>
  );
};

export default RichTextEditor;