import React, { useEffect, useRef, useState } from 'react';
import { 
  Calendar, Clock, User, Tag, Heart, 
  Share2, Facebook, Twitter, Linkedin, Copy, ArrowLeft,
  Bookmark, Eye, ChevronRight, Mail, Truck
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { sampleBlogPosts } from '../data/sampleBlogPosts';

// Sample data type for a blog post
export interface BlogPostProps {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  category: string;
  tags: string[];
  author: {
    name: string;
    avatar?: string;
    role?: string;
  };
  publishedAt: string;
  readTime: string;
  liked?: boolean;
  bookmarked?: boolean;
  views?: number;
  comments?: number;
}

export default function BlogPost({ post }: { post: BlogPostProps }) {
  const navigate = useNavigate();
  const contentRef = useRef<HTMLDivElement>(null);
  const [popularPosts, setPopularPosts] = useState<BlogPostProps[]>([]);
  
  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Get popular posts
  useEffect(() => {
    // In a real app, this would be fetched from an API
    // For now, we'll sort the sample data by views
    const sorted = [...sampleBlogPosts]
      .sort((a, b) => (b.views || 0) - (a.views || 0))
      .slice(0, 6); // Limit to 6 posts
    setPopularPosts(sorted);
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
      
      /* Table of contents highlight */
      .toc-highlight {
        position: absolute;
        left: 0;
        width: 3px;
        background-color: #3b5998;
        transition: top 0.2s ease, height 0.2s ease;
      }
      
      /* Progress bar */
      .reading-progress-bar {
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(to right, #3b5998, #f43f5e);
        z-index: 9999;
        transition: width 0.1s ease;
      }
      
      /* Blur effects */
      .blur-backdrop {
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
      }
      
      /* Sidebar fixed position */
      .sticky-sidebar {
        position: sticky;
        top: 80px;
      }
      
      /* Article typography enhancements */
      .article-content h2 {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1e3a8a;
        margin-top: 2rem;
        margin-bottom: 1rem;
        scroll-margin-top: 100px;
      }
      
      .article-content h3 {
        font-size: 1.5rem;
        font-weight: 600;
        color: #1e3a8a;
        margin-top: 1.75rem;
        margin-bottom: 0.75rem;
        scroll-margin-top: 100px;
      }
      
      .article-content p {
        font-size: 1.125rem;
        line-height: 1.8;
        color: #334155;
        margin-bottom: 1.25rem;
      }
      
      .article-content ul, .article-content ol {
        margin-bottom: 1.5rem;
        padding-left: 1.5rem;
      }
      
      .article-content li {
        font-size: 1.125rem;
        line-height: 1.7;
        margin-bottom: 0.5rem;
        color: #334155;
      }
      
      .article-content blockquote {
        border-left: 4px solid #3b5998;
        padding-left: 1rem;
        font-style: italic;
        color: #475569;
        margin: 1.5rem 0;
      }
      
      .article-content img {
        border-radius: 0.75rem;
        max-width: 100%;
        height: auto;
        margin: 1.5rem 0;
      }
      
      .article-content a {
        color: #3b5998;
        text-decoration: underline;
        text-decoration-color: rgba(59, 89, 152, 0.3);
        text-underline-offset: 3px;
        transition: text-decoration-color 0.2s ease;
      }
      
      .article-content a:hover {
        text-decoration-color: rgba(59, 89, 152, 1);
      }
      
      .article-content code {
        background-color: #f1f5f9;
        padding: 0.2rem 0.4rem;
        border-radius: 0.25rem;
        font-family: ui-monospace, monospace;
        font-size: 0.875rem;
        color: #1e293b;
      }
      
      .article-content pre {
        background-color: #1e293b;
        color: #e2e8f0;
        padding: 1rem;
        border-radius: 0.5rem;
        overflow-x: auto;
        margin: 1.5rem 0;
      }
      
      .article-content pre code {
        background-color: transparent;
        color: inherit;
        padding: 0;
        font-size: 0.875rem;
      }
      
      .article-content table {
        width: 100%;
        border-collapse: collapse;
        margin: 1.5rem 0;
      }
      
      .article-content th, .article-content td {
        padding: 0.75rem;
        border: 1px solid #cbd5e1;
      }
      
      .article-content th {
        background-color: #f1f5f9;
        font-weight: 600;
      }
    `;
    
    document.head.appendChild(styleElement);
    
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  // Reading progress tracking
  useEffect(() => {
    const updateReadingProgress = () => {
      if (!contentRef.current) return;
      
      const contentElement = contentRef.current;
      const contentHeight = contentElement.scrollHeight;
      const contentOffset = contentElement.offsetTop;
      const windowHeight = window.innerHeight;
      const scrollPosition = window.scrollY;
      
      // Calculate how much of the article has been read
      const visibleContent = (scrollPosition + windowHeight) - contentOffset;
      const progress = Math.min(100, Math.max(0, (visibleContent * 100) / contentHeight));
      
      // Update progress bar
      const progressBar = document.querySelector('.reading-progress-bar') as HTMLElement;
      if (progressBar) {
        progressBar.style.width = `${progress}%`;
      }
    };
    
    window.addEventListener('scroll', updateReadingProgress);
    updateReadingProgress(); // Initial calculation
    
    return () => window.removeEventListener('scroll', updateReadingProgress);
  }, []);

  // Copy URL to clipboard function
  const copyUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    
    // Show a temporary tooltip or notification
    const tooltip = document.createElement('div');
    tooltip.className = 'fixed top-4 right-4 bg-navy-800 text-white px-4 py-2 rounded-lg shadow-lg z-[9999] animate-fadeIn';
    tooltip.textContent = 'Link skopiowany do schowka!';
    document.body.appendChild(tooltip);
    
    setTimeout(() => {
      tooltip.classList.add('animate-fadeOut');
      setTimeout(() => document.body.removeChild(tooltip), 300);
    }, 2000);
  };

  // Calculate the estimated reading time if not provided
  const calculateReadingTime = (content: string): string => {
    const words = content.trim().split(/\s+/).length;
    const wordsPerMinute = 225;
    const minutes = Math.ceil(words / wordsPerMinute);
    return `${minutes} min`;
  };

  const readingTime = post.readTime || calculateReadingTime(post.content);

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white overflow-hidden">
      {/* Reading Progress Bar */}
      <div className="reading-progress-bar"></div>
      
      {/* Back Button - Fixed Position */}
      <div className="fixed top-20 left-4 z-40 lg:left-8">
        <button 
          onClick={() => navigate('/blog')}
          className="flex items-center justify-center w-10 h-10 bg-white/80 backdrop-blur-sm rounded-full shadow-md hover:shadow-lg transition-all duration-300 text-navy-700 hover:bg-navy-50"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
      </div>
      
      {/* Hero Section with Post Title and Image */}
      <header className="relative pt-20 pb-16">
        {/* Decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
          <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
          <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
          <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
        </div>
        
        {/* Animated Truck Icon */}
        <div className="absolute bottom-0 left-0 opacity-10 animate-float">
          <Truck className="w-64 h-64 text-navy-400" />
        </div>
        
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="animate-on-scroll">
            {/* Category and Tags */}
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-navy-100/70 text-navy-700">
                {post.category}
              </span>
              {post.tags.map((tag, index) => (
                <span key={index} className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-100/20 text-accent-700">
                  <Tag className="w-3.5 h-3.5 mr-1" />
                  {tag}
                </span>
              ))}
            </div>
            
            {/* Post Title */}
            <h1 className="text-4xl md:text-5xl font-bold text-navy-900 mb-6 leading-tight">
              {post.title}
            </h1>
            
            {/* Author and Date Info */}
            <div className="flex flex-wrap items-center gap-6 mb-8 text-navy-600">
              <div className="flex items-center">
                {post.author.avatar ? (
                  <img 
                    src={post.author.avatar} 
                    alt={post.author.name}
                    className="w-10 h-10 rounded-full object-cover mr-3"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-navy-100 flex items-center justify-center mr-3">
                    <User className="w-5 h-5 text-navy-600" />
                  </div>
                )}
                <div>
                  <div className="font-medium text-navy-800">{post.author.name}</div>
                  {post.author.role && <div className="text-sm text-navy-500">{post.author.role}</div>}
                </div>
              </div>
              
              <div className="flex items-center">
                <Calendar className="w-5 h-5 mr-2 text-navy-500/70" />
                <span>{post.publishedAt}</span>
              </div>
              
              <div className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-navy-500/70" />
                <span>{readingTime} czytania</span>
              </div>
              
              {post.views && (
                <div className="flex items-center">
                  <Eye className="w-5 h-5 mr-2 text-navy-500/70" />
                  <span>{post.views} wyświetleń</span>
                </div>
              )}
            </div>
            
            {/* Featured Image */}
            <div className="relative w-full aspect-[21/9] mb-8 rounded-2xl overflow-hidden shadow-xl">
              <img 
                src={post.image} 
                alt={post.title}
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content Area with Sidebar */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left Sidebar - Sharing Options and Actions */}
          <aside className="lg:w-16 order-2 lg:order-1">
            <div className="lg:sticky-sidebar flex lg:flex-col gap-4 justify-center">
              <div className="flex lg:flex-col gap-4">
                <button className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-navy-600 hover:bg-navy-50 transition-colors">
                  <Heart className="w-5 h-5" />
                </button>
                
                <button className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-navy-600 hover:bg-navy-50 transition-colors">
                  <Bookmark className="w-5 h-5" />
                </button>
                
                <button
                  onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank')}
                  className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-[#1877F2] hover:bg-[#1877F2]/10 transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </button>
                
                <button
                  onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(post.title)}`, '_blank')}
                  className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-[#1DA1F2] hover:bg-[#1DA1F2]/10 transition-colors"
                >
                  <Twitter className="w-5 h-5" />
                </button>
                
                <button
                  onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`, '_blank')}
                  className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-[#0A66C2] hover:bg-[#0A66C2]/10 transition-colors"
                >
                  <Linkedin className="w-5 h-5" />
                </button>
                
                <button
                  onClick={copyUrl}
                  className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-navy-600 hover:bg-navy-50 transition-colors"
                >
                  <Copy className="w-5 h-5" />
                </button>
              </div>
            </div>
          </aside>
          
          {/* Main Content */}
          <div className="lg:flex-1 order-1 lg:order-2" ref={contentRef}>
            <article className="bg-white rounded-2xl shadow-lg p-6 md:p-10 mb-8 animate-on-scroll">
              {/* Article Excerpt/Introduction */}
              <div className="text-xl text-navy-700 font-medium border-l-4 border-accent-500 pl-4 mb-8">
                {post.excerpt}
              </div>
              
              {/* Article Content */}
              <div 
                className="article-content"
                dangerouslySetInnerHTML={{ 
                  __html: post.content || '<p>No content available</p>' 
                }}
              ></div>
              
              {/* Tags at the end of article */}
              <div className="mt-10 pt-6 border-t border-navy-200">
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag, index) => (
                    <a 
                      key={index} 
                      href={`/blog/tag/${tag}`}
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-navy-50 text-navy-700 hover:bg-navy-100 transition-colors"
                    >
                      <Tag className="w-3.5 h-3.5 mr-1" />
                      {tag}
                    </a>
                  ))}
                </div>
              </div>
            </article>
            
            {/* Author Bio */}
            <div className="bg-navy-50/50 rounded-2xl p-8 mb-8 animate-on-scroll delay-1">
              <div className="flex items-start">
                {post.author.avatar ? (
                  <img 
                    src={post.author.avatar} 
                    alt={post.author.name}
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-navy-100 flex items-center justify-center mr-4">
                    <User className="w-8 h-8 text-navy-600" />
                  </div>
                )}
                <div>
                  <h3 className="text-xl font-bold text-navy-800 mb-2">O autorze</h3>
                  <p className="text-navy-600 mb-4">
                    {post.author.name} to ekspert w branży transportowej z wieloletnim doświadczeniem. 
                    Specjalizuje się w logistyce międzynarodowej i transporcie drogowym.
                  </p>
                  <div className="flex gap-2">
                    <a 
                      href="#" 
                      className="inline-flex items-center text-sm text-accent-600 hover:text-accent-700"
                    >
                      <span>Zobacz wszystkie artykuły</span>
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Newsletter Signup */}
            <div className="bg-gradient-to-br from-navy-700 to-navy-800 rounded-2xl p-8 text-white animate-on-scroll delay-2">
              <div className="flex flex-col md:flex-row md:items-center gap-6">
                <div className="md:flex-1">
                  <h3 className="text-xl font-bold mb-2">Chcesz otrzymywać podobne artykuły?</h3>
                  <p className="text-navy-100 mb-4">
                    Zapisz się do naszego newslettera, aby otrzymywać najnowsze artykuły i porady z branży transportowej.
                  </p>
                </div>
                <div className="md:flex-1">
                  <form className="flex gap-2">
                    <input
                      type="email"
                      placeholder="Twój adres email"
                      className="flex-1 px-4 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-white/30"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-white text-navy-800 rounded-lg font-medium hover:bg-navy-100 transition-colors"
                    >
                      Zapisz się
                    </button>
                  </form>
                </div>
              </div>
            </div>
            
            {/* Related Articles */}
            <div className="mt-12 animate-on-scroll delay-3">
              <h2 className="text-2xl font-bold text-navy-800 mb-6">Podobne artykuły</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Sample related articles - in a real app these would be dynamically generated */}
                {[1, 2, 3].map((i) => (
                  <a 
                    key={i}
                    href="#" 
                    className="group bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col h-full"
                  >
                    <div className="relative h-48">
                      <img 
                        src={`https://source.unsplash.com/random/400x300?truck&sig=${i}`}
                        alt="Related article" 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-5 flex-1 flex flex-col">
                      <div className="mb-2">
                        <span className="inline-block px-2 py-1 text-xs font-medium bg-navy-50 text-navy-700 rounded-md">
                          {post.category}
                        </span>
                      </div>
                      <h3 className="font-bold text-navy-800 mb-2 group-hover:text-accent-600 transition-colors">
                        Przykładowy powiązany artykuł {i}
                      </h3>
                      <p className="text-navy-600 text-sm mb-4 flex-1">
                        Krótki opis powiązanego artykułu, który może zainteresować czytelnika tego wpisu.
                      </p>
                      <div className="flex items-center justify-between text-sm text-navy-500 mt-auto pt-3 border-t border-navy-100">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>10 marca 2025</span>
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          <span>5 min</span>
                        </div>
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          {/* Right Sidebar - Table of Contents */}
          <aside className="lg:w-64 order-3">
            <div className="lg:sticky-sidebar">
              <div className="bg-white rounded-xl shadow-md p-6 mb-6">
                <h3 className="font-bold text-navy-800 mb-4">Spis treści</h3>
                <div className="relative">
                  <div className="toc-highlight"></div>
                  <ul className="space-y-3 text-navy-600">
                    <li className="pl-4 border-l-2 border-transparent hover:border-navy-300 transition-colors">
                      <a href="#introduction" className="hover:text-navy-800 transition-colors block py-1">Wprowadzenie</a>
                    </li>
                    <li className="pl-4 border-l-2 border-transparent hover:border-navy-300 transition-colors">
                      <a href="#requirements" className="hover:text-navy-800 transition-colors block py-1">Wymagania</a>
                    </li>
                    <li className="pl-4 border-l-2 border-navy-600 hover:border-navy-600 transition-colors">
                      <a href="#steps" className="text-navy-800 font-medium block py-1">Krok po kroku</a>
                    </li>
                    <li className="pl-4 border-l-2 border-transparent hover:border-navy-300 transition-colors">
                      <a href="#tips" className="hover:text-navy-800 transition-colors block py-1">Wskazówki</a>
                    </li>
                    <li className="pl-4 border-l-2 border-transparent hover:border-navy-300 transition-colors">
                      <a href="#conclusion" className="hover:text-navy-800 transition-colors block py-1">Podsumowanie</a>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-navy-50/70 rounded-xl p-6">
                <h3 className="font-bold text-navy-800 mb-4">Najpopularniejsze</h3>
                <div className="space-y-4">
                  {popularPosts.map((popularPost, index) => (
                    <a 
                      key={popularPost.id} 
                      href={`/blog/${popularPost.id}`} 
                      className="flex gap-3 group"
                    >
                      <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 text-navy-700 font-semibold border border-navy-200 group-hover:bg-accent-50 group-hover:text-accent-700 group-hover:border-accent-200 transition-all">
                        {index + 1}
                      </span>
                      <span className="text-navy-700 group-hover:text-navy-900 transition-colors">
                        {popularPost.title}
                      </span>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}