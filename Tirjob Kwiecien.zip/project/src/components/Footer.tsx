import React from 'react';
import { Mail, Truck, Facebook, Instagram, Linkedin, Youtube, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { subscribeToNewsletter } from '../lib/newsletter';
import { useSettings } from '../hooks/useSettings';

export default function Footer() {
  const navigate = useNavigate();
  const { settings } = useSettings();
  const [email, setEmail] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitStatus, setSubmitStatus] = React.useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);
  
  // Function to navigate and scroll to top
  const navigateAndScrollToTop = (path: string, e: React.MouseEvent) => {
    e.preventDefault();
    navigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);
    
    const result = await subscribeToNewsletter(email);
    
    if (result.success) {
      setEmail('');
      setSubmitStatus({ type: 'success', message: 'Dziękujemy za zapisanie się do newslettera!' });
    } else {
      setSubmitStatus({ type: 'error', message: result.error || 'Wystąpił błąd. Spróbuj ponownie później.' });
    }
    
    setIsSubmitting(false);
  };
  
  return (
    <footer className="bg-gradient-to-br from-navy-800 to-navy-900 text-navy-100 mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        {/* Top Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12 pb-12 border-b border-navy-700/50">
          {/* Logo Section */}
          <div className="flex flex-col justify-center">
            <h3 className="text-white text-xl font-semibold mb-2 flex items-center">
              <Truck className="h-6 w-6 text-accent-500 mr-2" />
              TIRJOB.pl
            </h3>
            <p className="text-sm text-navy-200 max-w-xs">
              Twój klucz do najlepszych ofert pracy w branży transportowej
            </p>
          </div>

          {/* Newsletter Section */}
          <div className="lg:col-span-1">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Newsletter TirJob.pl</h3>
              <p className="text-navy-200 mb-4">
                Dołącz do naszego newslettera i bądź na bieżąco z najlepszymi ofertami pracy dla kierowców!
              </p>
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md mx-auto">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Twój adres email"
                  className={`w-64 px-3 py-1.5 rounded-full bg-navy-700/30 border ${
                    submitStatus?.type === 'error' ? 'border-red-500' : 'border-navy-600/50'
                  } text-white placeholder-navy-300 focus:outline-none focus:ring-1 focus:ring-accent-400`}
                  required
                />
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`px-4 py-1.5 bg-accent-500/80 text-white text-sm rounded-full hover:bg-accent-600 transition-all duration-200 hover:shadow-sm flex items-center ${
                    isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white mr-2"></div>
                      Zapisywanie...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Aktywuj
                    </>
                  )}
                </button>
              </form>
              {submitStatus && (
                <p className={`mt-2 text-sm ${
                  submitStatus.type === 'success' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {submitStatus.message}
                </p>
              )}
            </div>
          </div>

          {/* Contact Section */}
          <div className="flex flex-col justify-center">
            <div className="text-right">
              <h4 className="text-white text-lg font-semibold mb-4">Kontakt</h4>
              <div className="flex items-center justify-end space-x-2 text-sm text-navy-200">
                <Mail className="w-4 h-4 text-accent-500" />
                <a href={`mailto:${settings.contact_email || 'kontakt@tirjob.pl'}`} className="hover:text-accent-400 transition-colors">
                  {settings.contact_email || 'kontakt@tirjob.pl'}
                </a>
              </div>
              <p className="mt-4 text-sm text-navy-200">
                Masz pytania? Chcesz z nami współpracować lub potrzebujesz pomocy? Skontaktuj się z nami!
              </p>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Information Column */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">Informacje</h4>
            <ul className="space-y-2">
              <li>
                <a 
                  href="/regulamin" 
                  onClick={(e) => navigateAndScrollToTop('/regulamin', e)}
                  className="text-navy-200 hover:text-accent-400 transition-colors"
                >
                  Regulamin
                </a>
              </li>
              <li>
                <a 
                  href="/polityka-prywatnosci" 
                  onClick={(e) => navigateAndScrollToTop('/polityka-prywatnosci', e)}
                  className="text-navy-200 hover:text-accent-400 transition-colors"
                >
                  Polityka prywatności
                </a>
              </li>
              <li>
                <a 
                  href="/blog" 
                  onClick={(e) => navigateAndScrollToTop('/blog', e)}
                  className="text-navy-200 hover:text-accent-400 transition-colors"
                >
                  Blog transportowy
                </a>
              </li>
              <li>
                <a 
                  href="/dodaj-ogloszenie" 
                  onClick={(e) => navigateAndScrollToTop('/dodaj-ogloszenie', e)}
                  className="text-navy-200 hover:text-accent-400 transition-colors"
                >
                  Dodaj ogłoszenie
                </a>
              </li>
              <li>
                <a 
                  href="/newsletter" 
                  onClick={(e) => navigateAndScrollToTop('/newsletter', e)}
                  className="text-navy-200 hover:text-accent-400 transition-colors"
                >
                  Newsletter
                </a>
              </li>
            </ul>
          </div>

          {/* Cities Column */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">Praca według miast</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Warszawa</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Kraków</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Poznań</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Wrocław</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Łódź</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Kierowcy - Katowice</a></li>
            </ul>
          </div>

          {/* Drivers Column */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">Kierowcy zawodowi</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. B</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. B+E</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. C</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. C+E</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. D</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">kat. D+E</a></li>
            </ul>
          </div>

          {/* Specialists Column */}
          <div>
            <h4 className="text-white text-lg font-semibold mb-4">Transport i Logistyka</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Spedytor</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Dyspozytor</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Planista</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Handlowiec</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Opiekun floty</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Referent FK</a></li>
              <li><a href="#" className="text-navy-200 hover:text-accent-400 transition-colors">Budownictwo</a></li>
            </ul>
          </div>
        </div>

        {/* Social Media */}
        <div className="flex flex-col items-center space-y-4 mb-8">
          <p className="text-navy-200">Śledź nas na:</p>
          <div className="flex justify-center items-center space-x-6">
          <a href={settings.facebook_url || "https://facebook.com/tirjob"} className="text-navy-300 hover:text-accent-400 transition-colors flex items-center">
            <Facebook className="w-6 h-6" />
            <span className="ml-2">Facebook</span>
          </a>
          <a href={settings.instagram_url || "https://instagram.com/tirjob.pl"} className="text-navy-300 hover:text-accent-400 transition-colors flex items-center">
            <Instagram className="w-6 h-6" />
            <span className="ml-2">Instagram</span>
          </a>
          <a href={settings.linkedin_url || "https://linkedin.com/company/tirjob"} className="text-navy-300 hover:text-accent-400 transition-colors flex items-center">
            <Linkedin className="w-6 h-6" />
            <span className="ml-2">LinkedIn</span>
          </a>
          <a href="#" className="text-navy-300 hover:text-accent-400 transition-colors flex items-center">
            <Youtube className="w-6 h-6" />
            <span className="ml-2">YouTube</span>
          </a>
          </div>
        </div>

        {/* Copyright */}
        <div className="text-sm text-center text-navy-300 pt-8 border-t border-navy-700/50">
          © 2025 TirJob.pl. Wszelkie prawa zastrzeżone.
        </div>
      </div>
    </footer>
  );
}