import React, { useEffect } from 'react';
import { FileText, Truck, Phone, Mail, BookOpen, Shield } from 'lucide-react';

export default function Terms() {
  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
    `;
    
    document.head.appendChild(styleElement);
    
    // Clean up on component unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
      {/* Hero Section with Animated Background */}
      <div className="relative overflow-hidden pt-16 pb-12">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
          <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
          <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
          <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
        </div>
        
        {/* Animated Truck Icon */}
        <div className="absolute bottom-0 left-0 opacity-10 animate-float">
          <Truck className="w-64 h-64 text-navy-400" />
        </div>
        
        {/* Content */}
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <div className="text-center mb-12 animate-on-scroll">
            <span className="inline-block px-4 py-2 rounded-full bg-navy-100/50 text-navy-700 font-medium text-sm mb-4">
              DOKUMENTY PRAWNE
            </span>
            <h1 className="text-4xl font-bold text-navy-900 mb-4">
              Regulamin serwisu TirJob.pl
            </h1>
            <p className="text-lg text-navy-600/90 max-w-3xl mx-auto">
              Obowiązuje od 01.03.2025
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-10 animate-on-scroll">
          <div className="prose prose-lg max-w-none text-navy-800">
            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <FileText className="w-4 h-4 text-navy-600" />
              </span>
              §1 Definicje
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>
                <strong>Administrator</strong> Administratorem serwisu jest W3 B2B SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą przy ul. Świeradowska 47, 02-662 Warszawa, Polska, wpisana do Krajowego Rejestru Sądowego pod numerem KRS: 0001115407, posiadająca NIP: 1133139476 oraz REGON: 529115601.
              </li>
              <li>
                <strong>Użytkownik</strong> – osoba fizyczna korzystająca z Serwisu w celu przeglądania opublikowanych ofert pracy i ewentualnego aplikowania do trwających procesów rekrutacyjnych lub zamieszczania ogłoszeń.
              </li>
              <li>
                <strong>Pracodawca</strong> – osoba fizyczna, osoba prawna lub jednostka organizacyjna nieposiadająca osobowości prawnej, zamieszczająca ogłoszenie rekrutacyjne w Serwisie.
              </li>
              <li>
                <strong>Kierowca / Kandydat</strong> – osoba fizyczna korzystająca z Serwisu w celu znalezienia pracy i aplikowania na oferty.
              </li>
              <li>
                <strong>Serwis</strong> – portal internetowy TirJob.pl, dostępny pod adresem <a href="https://tirjob.pl" className="text-accent-600 hover:text-accent-700">tirjob.pl</a>, umożliwiający zamieszczanie i przeglądanie ogłoszeń rekrutacyjnych.
              </li>
            </ol>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <Shield className="w-4 h-4 text-navy-600" />
              </span>
              §2 Postanowienia ogólne
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>Serwis TirJob.pl umożliwia Użytkownikom publikowanie i przeglądanie ofert pracy w branży transportowej.</li>
              <li>Korzystanie z Serwisu jest dobrowolne.</li>
              <li>Publikacja ogłoszenia wymaga wypełnienia formularza i dokonania opłaty zgodnie z cennikiem.</li>
              <li>Administrator świadczy usługi drogą elektroniczną zgodnie z obowiązującymi przepisami prawa.</li>
              <li>Administrator, prowadzi działalność gospodarczą w formie spółki z ograniczoną odpowiedzialnością zgodnie z przepisami ustawy Prawo Przedsiębiorców oraz innymi obowiązującymi przepisami prawa.</li>
            </ol>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <BookOpen className="w-4 h-4 text-navy-600" />
              </span>
              §3 Prawa własności intelektualnej
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>Treści zamieszczone w Serwisie, w tym ogłoszenia i materiały promocyjne, mogą stanowić utwory w rozumieniu ustawy o prawie autorskim i prawach pokrewnych.</li>
              <li>Kopiowanie i dalsze rozpowszechnianie treści Serwisu bez zgody Administratora jest zabronione.</li>
            </ol>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <FileText className="w-4 h-4 text-navy-600" />
              </span>
              §4 Publikacja i opłaty za ogłoszenia
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>Zamieszczenie ogłoszenia wymaga:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Wypełnienia formularza dodania ogłoszenia.</li>
                  <li>Zaakceptowania Regulaminu.</li>
                  <li>Dokonania płatności zgodnie z cennikiem.</li>
                </ul>
              </li>
              <li>Ogłoszenie zostanie opublikowane w Serwisie w ciągu 24 godzin od zaksięgowania płatności.</li>
              <li>Cennik publikacji ogłoszeń dostępny jest na stronie Serwisu.</li>
            </ol>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <Shield className="w-4 h-4 text-navy-600" />
              </span>
              §5 Reklamacje i odpowiedzialność
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>Administrator zobowiązuje się do prawidłowego działania Serwisu i realizacji płatnych usług zgodnie z opisem.</li>
              <li>Reklamacje dotyczące funkcjonowania Serwisu można zgłaszać na adres e-mail: kontakt@tirjob.pl.</li>
              <li>Administrator nie ponosi odpowiedzialności za treści zamieszczane przez Użytkowników oraz ich zgodność ze stanem faktycznym.</li>
            </ol>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <FileText className="w-4 h-4 text-navy-600" />
              </span>
              §6 Postanowienia końcowe
            </h2>
            
            <ol className="list-decimal pl-6 space-y-2">
              <li>Administrator zastrzega sobie prawo do zmiany Regulaminu w każdym czasie.</li>
              <li>Wszelkie zmiany wchodzą w życie w terminie 7 dni od ich publikacji w Serwisie.</li>
              <li>W sprawach nieuregulowanych niniejszym Regulaminem stosuje się przepisy prawa polskiego.</li>
              <li>Wszelkie spory wynikające z korzystania z Serwisu będą rozpatrywane przez właściwy sąd powszechny.</li>
            </ol>
          </div>
        </div>

        <div className="bg-navy-800 rounded-2xl shadow-lg p-8 text-white mb-10 animate-on-scroll delay-1">
          <h2 className="text-2xl font-bold mb-6">Masz pytania dotyczące regulaminu?</h2>
          <p className="text-navy-200 mb-6">Jeśli masz jakiekolwiek pytania odnośnie naszego regulaminu, skontaktuj się z nami:</p>
          
          <div className="flex flex-col sm:flex-row gap-4 text-navy-100">
            <a href="mailto:kontakt@tirjob.pl" className="flex items-center group">
              <div className="w-10 h-10 bg-navy-700 rounded-full flex items-center justify-center mr-3 group-hover:bg-accent-600 transition-colors">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <span className="group-hover:text-white transition-colors">kontakt@tirjob.pl</span>
            </a>
            <a href="tel:+48501420042" className="flex items-center group">
              <div className="w-10 h-10 bg-navy-700 rounded-full flex items-center justify-center mr-3 group-hover:bg-accent-600 transition-colors">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <span className="group-hover:text-white transition-colors">+48 501 42 00 42</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}