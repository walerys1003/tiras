import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { getSeoSettingsByPath, type SeoSettings } from '../lib/seo';
import { useSettings } from '../hooks/useSettings';

interface SeoHeadProps {
  path: string;
  defaultTitle?: string;
  defaultDescription?: string;
  dynamicData?: {
    title?: string;
    description?: string;
    image?: string;
    type?: string;
    keywords?: string;
    schemaData?: any;
  };
}

export default function SeoHead({ path, defaultTitle, defaultDescription, dynamicData }: SeoHeadProps) {
  const [seoData, setSeoData] = useState<SeoSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const { settings } = useSettings();
  const [schemaOrgData, setSchemaOrgData] = useState<any>(null);

  // Initialize metadata variables with default values
  const title = dynamicData?.title || seoData?.title || defaultTitle || settings.default_title || 'TirJob.pl';
  const description = dynamicData?.description || seoData?.description || defaultDescription || settings.default_description || 'Portal pracy dla kierowców i specjalistów transportu';
  const keywords = dynamicData?.keywords || seoData?.keywords || settings.default_keywords || '';
  
  const ogTitle = dynamicData?.title || seoData?.og_title || title;
  const ogDescription = dynamicData?.description || seoData?.og_description || description;
  const ogImage = dynamicData?.image || seoData?.og_image || 'https://i.ibb.co/7NdqLD2G/2.png';
  const ogType = dynamicData?.type || seoData?.og_type || 'website';

  useEffect(() => {
    const fetchSeoData = async () => {
      try {
        const data = await getSeoSettingsByPath(path);
        setSeoData(data);
      } catch (error) {
        console.error('Error fetching SEO data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchSeoData();
  }, [path]);
   
  // Process schema.org data when dependencies change
  useEffect(() => {
    if (seoData?.schema_org) {
      setSchemaOrgData(seoData.schema_org);
    } else if (path === '/') {
      // Default schema for homepage if none is set
      setSchemaOrgData({
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": settings.default_title || "TirJob.pl",
        "url": "https://tirjob.pl",
        "description": settings.default_description || "Portal pracy dla kierowców i specjalistów transportu"
      });
    } else {
      // Default schema for other pages
      setSchemaOrgData({
        "@context": "https://schema.org",
        "@type": "WebPage",
        "name": title,
        "description": description
      });
    }
  }, [seoData, path, settings, title, description]);

  if (loading) {
    return null;
  }

  // Use dynamic schema data if provided, otherwise use SEO settings
  const schemaOrg = dynamicData?.schemaData || schemaOrgData;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{title}</title>
      <meta name="description" content={description} />
      {keywords && <meta name="keywords" content={keywords} />}
      
      {/* OpenGraph Tags */}
      <meta property="og:title" content={ogTitle} />
      <meta property="og:description" content={ogDescription} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={`https://tirjob.pl${path}`} />
      <meta property="og:site_name" content="TirJob.pl" />
      
      {/* Twitter Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={ogTitle} />
      <meta name="twitter:description" content={ogDescription} />
      <meta name="twitter:image" content={ogImage} />
      
      {/* Canonical URL */}
      <link rel="canonical" href={`https://tirjob.pl${path}`} />
      
      {/* Schema.org JSON-LD */}
      {schemaOrg ? (
        <script type="application/ld+json">
          {JSON.stringify(schemaOrg)}
        </script>
      ) : (
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            "name": title,
            "description": description
          })}
        </script>
      )}
    </Helmet>
  );
}