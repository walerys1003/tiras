import React, { useEffect, useState } from 'react';
import { 
  Mail, CheckCircle2, Truck, Users, Star, ChevronRight, 
  TrendingUp, Bookmark, DollarSign, Gift, Award, Send,
  Shield, Heart, MessageSquare, BellRing
} from 'lucide-react';
import { subscribeToNewsletter } from '../lib/newsletter';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }

      @keyframes shimmer {
        0% {
          background-position: -100% 0;
        }
        100% {
          background-position: 200% 0;
        }
      }

      .btn-shimmer {
        position: relative;
        overflow: hidden;
      }

      .btn-shimmer::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          90deg,
          rgba(255, 255, 255, 0) 0%,
          rgba(255, 255, 255, 0.2) 50%,
          rgba(255, 255, 255, 0) 100%
        );
        background-size: 200% 100%;
        animation: shimmer 2.5s infinite;
      }
    `;
    
    document.head.appendChild(styleElement);
    
    // Clean up on component unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);
    
    const result = await subscribeToNewsletter(email);
    
    if (result.success) {
      setEmail('');
      setSubmitStatus({ type: 'success', message: 'Dziękujemy za zapisanie się do newslettera!' });
    } else {
      setSubmitStatus({ type: 'error', message: result.error || 'Wystąpił błąd. Spróbuj ponownie później.' });
    }
    
    setIsSubmitting(false);
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
        <div className="relative overflow-hidden pt-20 pb-16">
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
            <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
            <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
            <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
          </div>
          
          {/* Animated Truck Icon */}
          <div className="absolute bottom-0 left-0 opacity-10 animate-float">
            <Truck className="w-64 h-64 text-navy-400" />
          </div>
          
          {/* Content */}
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
            <div className="text-center mb-12 animate-on-scroll">
              <span className="inline-block px-4 py-2 rounded-full bg-navy-100/50 text-navy-700 font-medium text-sm mb-4">
                NEWSLETTER TIRJOB.PL
              </span>
              <h1 className="text-5xl font-bold text-navy-900 mb-6">
                📩 Dołącz do elity transportowego rynku pracy! 🚛
              </h1>
              <p className="text-xl text-navy-600/90 max-w-3xl mx-auto">
                Zdobądź przewagę w branży transportowej i bądź na bieżąco z najlepszymi ofertami!
              </p>
            </div>
          </div>
        </div>
        
        {/* Main Content Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Grid Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {/* Left Column - Benefits */}
            <div className="animate-on-scroll delay-1">
              <div className="bg-white rounded-3xl shadow-xl p-8 h-full border border-navy-100/40">
                <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
                  <span className="w-10 h-10 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                    <CheckCircle2 className="w-5 h-5 text-navy-600" />
                  </span>
                  Dlaczego warto dołączyć?
                </h2>
                
                <ul className="space-y-6">
                  <li className="flex items-start">
                    <div className="w-8 h-8 bg-navy-100/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-navy-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-navy-800 font-medium">🔵 Chcesz być na bieżąco z najlepszymi ofertami pracy dla kierowców i specjalistów transportu?</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="w-8 h-8 bg-navy-100/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-navy-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-navy-800 font-medium">🔵 Interesują Cię porady rekrutacyjne, stawki wynagrodzeń w transporcie oraz nowe możliwości kariery?</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="w-8 h-8 bg-navy-100/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-4 h-4 text-navy-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-navy-800 font-medium">🔵 Szukasz pracy na swoich warunkach – w renomowanych firmach transportowych?</p>
                    </div>
                  </li>
                </ul>
                
                <div className="mt-8 bg-navy-50/70 rounded-xl p-6">
                  <h3 className="font-bold text-navy-800 text-xl mb-3">📢 Zapisz się do newslettera TirJob i ZYSKAJ WIĘCEJ!</h3>
                  <p className="text-navy-700">
                    ✅ Zero spamu – tylko wartościowe treści, które pomogą Ci zdobyć najlepszą pracę!
                  </p>
                </div>
              </div>
            </div>

            {/* Right Column - Signup Form */}
            <div className="animate-on-scroll delay-2">
              <div className="bg-white rounded-3xl shadow-xl p-8 border border-navy-100/40 relative overflow-hidden">
                {/* Decorative elements */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-navy-50/30 rounded-bl-[60px]"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-accent-50/20 rounded-tr-[60px]"></div>
                
                <div className="relative z-10">
                  <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
                    <span className="w-10 h-10 bg-accent-100/40 rounded-full flex items-center justify-center mr-3">
                      <Mail className="w-5 h-5 text-accent-600" />
                    </span>
                    Zapisz się teraz!
                  </h2>
                  
                  <form onSubmit={handleSubscribe} className="space-y-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-navy-700 mb-1">
                        ✉ Adres e-mail:
                      </label>
                      <div className="mt-1 relative">
                        <input
                          id="email"
                          name="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="📌 Twój adres e-mail"
                          className={`w-full px-4 py-3 border ${
                            submitStatus?.type === 'error' ? 'border-red-500' : 'border-navy-200'
                          } rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-accent-500 shadow-sm`}
                          required
                        />
                      </div>
                    </div>
                    
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={`w-full flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-accent-600 hover:bg-accent-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-500 transition-colors shadow-lg hover:shadow-xl btn-shimmer ${
                        isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
                      }`}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                          Zapisywanie...
                        </>
                      ) : (
                        <>
                          🔵 Zapisz się teraz!
                        </>
                      )}
                    </button>
                    
                    {submitStatus && (
                      <div className={`mt-4 ${
                        submitStatus.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
                      } px-4 py-3 rounded-lg flex items-start`}>
                        <CheckCircle2 className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <p>{submitStatus.message}</p>
                      </div>
                    )}

                    <div className="mt-4">
                      <p className="text-sm text-navy-600">
                        Twoje dane są bezpieczne. Możesz zrezygnować z subskrypcji w każdej chwili. Więcej informacji w naszej <a href="#" className="text-accent-600 hover:text-accent-700">Polityce Prywatności</a>.
                      </p>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}