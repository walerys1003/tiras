import React, { useEffect } from 'react';
import { 
  Mail, Phone, MapPin, Clock, Building2, 
  MessageSquare, Heart, Truck,
  ArrowRight, CheckCircle2, Award
} from 'lucide-react';
import { useSettings } from '../hooks/useSettings';

export default function Contact() {
  const { settings } = useSettings();

  return (
    <div id="top" className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
      {/* Hero Section with Animated Background */}
      <div className="relative overflow-hidden pt-16 pb-20">
        {/* Soft, wavy background pattern */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
          <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
          <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
          <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
        </div>
        
        {/* Animated Truck Icon */}
        <div className="absolute bottom-0 left-0 opacity-10 animate-float">
          <Truck className="w-64 h-64 text-navy-400" />
        </div>
        
        {/* Content */}
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <div className="text-center mb-12 animate-on-scroll">
            <span className="inline-block px-4 py-2 rounded-full bg-navy-100/50 text-navy-700 font-medium text-sm mb-4">
              NAJNOWSZE ARTYKUŁY I PORADY
            </span>
            <h1 className="text-5xl font-bold text-navy-900 mb-6">
              <div className="flex items-center justify-center mb-4">
                <Truck className="w-16 h-16 text-accent-500/70 mr-4 animate-float" />
                <span className="opacity-0 animate-slideInRight" style={{ animation: 'slideInRight 0.8s 0.3s forwards' }}>
                  🚛 Zawsze otwarci na kontakt
                </span>
              </div>
              <span className="block text-accent-500/80 opacity-0 animate-slideInLeft" style={{ animation: 'slideInLeft 0.8s 0.6s forwards' }}>
                Twój sukces w transporcie zaczyna się tutaj!
              </span>
            </h1>
            <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-accent-400/60 rounded-full opacity-0 animate-expand" style={{ animation: 'expandAndFade 1.2s 1.2s forwards' }}></div>
          </div>
          
          <p className="text-xl text-navy-600/90 max-w-3xl mx-auto mt-8 leading-relaxed opacity-0 animate-fadeIn" style={{ animation: 'fadeIn 1s 1.5s forwards' }}>
            Jesteśmy czymś więcej niż tylko portalem rekrutacyjnym. Łączymy najlepszych kierowców i specjalistów transportu z firmami, które ich potrzebują. Naszą misją jest szybka, skuteczna i bezproblemowa rekrutacja.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Contact Section - Organic, flowing design */}
        <div className="relative rounded-[40px] bg-gradient-to-br from-white to-navy-50/40 shadow-lg p-12 mb-20 overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-navy-100/20 rounded-bl-[100px]"></div>
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-accent-100/10 rounded-tr-[50px]"></div>
          
          <div className="relative z-10">
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center p-2 bg-navy-100/50 rounded-full mb-4">
                <Building2 className="h-5 w-5 text-navy-600/80" />
                <span className="ml-2 text-navy-700 font-medium">Dane kontaktowe</span>
              </div>
              <h2 className="text-3xl font-bold text-navy-800 mb-2">Jak możesz się z nami skontaktować?</h2>
              <p className="text-navy-600/80 max-w-2xl mx-auto">Nasz zespół jest dostępny, aby odpowiedzieć na wszystkie Twoje pytania, pomóc w procesie rekrutacji i wsparcia technicznego.</p>
            </div>

            {/* Contact Cards - Flowing, organic layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Main Contact Card */}
              <div className="bg-white rounded-[30px] shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group transform hover:-translate-y-1 relative">
                <div className="absolute top-0 right-0 w-24 h-24 bg-navy-50/50 rounded-bl-[40px] group-hover:bg-navy-100/30 transition-all duration-300"></div>
                <div className="relative p-8 z-10">
                  <div className="w-14 h-14 bg-gradient-to-br from-navy-100 to-white rounded-2xl flex items-center justify-center mb-5 shadow-sm group-hover:shadow-md transition-all duration-300">
                    <Building2 className="w-7 h-7 text-navy-600/80" />
                  </div>
                  <h3 className="text-xl font-bold text-navy-800 mb-3">Siedziba firmy</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <MapPin className="w-5 h-5 text-navy-500/70 mr-3 mt-0.5" />
                      <div>
                        {settings.company_address ? (
                          settings.company_address.split('\n').map((line, i) => (
                            <p key={i} className={i === 0 ? "text-navy-700" : "text-navy-600/80"}>
                              {line}
                            </p>
                          ))
                        ) : (
                          <>
                            <p className="text-navy-700">ul. Świeradowska 47</p>
                            <p className="text-navy-600/80">02-662 Warszawa</p>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Mail className="w-5 h-5 text-navy-500/70 mr-3 mt-0.5" />
                      <div>
                        <a href={`mailto:${settings.contact_email || 'kontakt@tirjob.pl'}`} className="text-accent-500/90 hover:text-accent-600 transition-colors">
                          {settings.contact_email || 'kontakt@tirjob.pl'}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Phone className="w-5 h-5 text-navy-500/70 mr-3 mt-0.5" />
                      <div>
                        <a href={`tel:${settings.contact_phone || '+48501420042'}`} className="text-navy-700 hover:text-navy-800 transition-colors">
                          {settings.contact_phone || '(+48) 501 42 00 42'}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <Clock className="w-5 h-5 text-navy-500/70 mr-3 mt-0.5" />
                      <div>
                        <p className="text-navy-700">Poniedziałek - Piątek</p>
                        <p className="text-navy-600/80">8:00-16:00</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Technical Support Card */}
              <div className="bg-gradient-to-br from-navy-700/90 to-navy-800/90 rounded-[30px] shadow-md hover:shadow-xl overflow-hidden group transform hover:-translate-y-1 relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-navy-600/50 rounded-bl-[60px] group-hover:bg-navy-600/70 transition-all duration-300"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-navy-600/20 rounded-tr-[60px] group-hover:bg-navy-600/30 transition-all duration-300"></div>
                
                <div className="relative p-8 z-10">
                  <div className="w-14 h-14 bg-navy-600/50 rounded-2xl flex items-center justify-center mb-5 shadow-md group-hover:shadow-lg transition-all duration-300">
                    <MessageSquare className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Wsparcie techniczne</h3>
                  <p className="text-navy-100 mb-6">
                    Potrzebujesz pomocy z publikacją ogłoszeń lub masz problemy techniczne? Chętnie pomożemy!
                  </p>
                  <div className="space-y-4">
                    <a href={`mailto:${settings.contact_email || 'kontakt@tirjob.pl'}`} className="flex items-center group/link">
                      <div className="w-8 h-8 bg-navy-600 rounded-full flex items-center justify-center mr-3 group-hover/link:bg-accent-500/70 transition-all duration-300">
                        <Mail className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white group-hover/link:text-accent-200 transition-colors">
                        {settings.contact_email || 'kontakt@tirjob.pl'}
                      </span>
                    </a>
                    <a href={`tel:${settings.contact_phone || '+48501420042'}`} className="flex items-center group/link">
                      <div className="w-8 h-8 bg-navy-600 rounded-full flex items-center justify-center mr-3 group-hover/link:bg-accent-500/70 transition-all duration-300">
                        <Phone className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white group-hover/link:text-accent-200 transition-colors">
                        {settings.contact_phone || '(+48) 501 42 00 42'}
                      </span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Billing and Payments Card */}
              <div className="bg-gradient-to-br from-navy-700/90 to-navy-800/90 rounded-[30px] shadow-md hover:shadow-xl overflow-hidden group transform hover:-translate-y-1 relative">
                <div className="absolute top-0 left-0 w-24 h-24 bg-navy-600/50 rounded-br-[40px] group-hover:bg-navy-600/70 transition-all duration-300"></div>
                <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-navy-600/20 rounded-tl-[80px] group-hover:bg-navy-600/30 transition-all duration-300"></div>
                
                <div className="relative p-8 z-10">
                  <div className="w-14 h-14 bg-navy-600/50 rounded-2xl flex items-center justify-center mb-5 shadow-md group-hover:shadow-lg transition-all duration-300">
                    <Award className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">Faktury i płatności</h3>
                  <p className="text-navy-100 mb-6">
                    Pytania dotyczące rozliczeń, faktur lub informacji o cenach? Nasz dział finansowy pomoże!
                  </p>
                  <div className="space-y-4">
                    <a href={`mailto:${settings.contact_email || 'kontakt@tirjob.pl'}`} className="flex items-center group/link">
                      <div className="w-8 h-8 bg-navy-600 rounded-full flex items-center justify-center mr-3 group-hover/link:bg-accent-500/70 transition-all duration-300">
                        <Mail className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white group-hover/link:text-accent-200 transition-colors">
                        {settings.contact_email || 'kontakt@tirjob.pl'}
                      </span>
                    </a>
                    <a href={`tel:${settings.contact_phone || '+48501420042'}`} className="flex items-center group/link">
                      <div className="w-8 h-8 bg-navy-600 rounded-full flex items-center justify-center mr-3 group-hover/link:bg-accent-500/70 transition-all duration-300">
                        <Phone className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-white group-hover/link:text-accent-200 transition-colors">
                        {settings.contact_phone || '(+48) 501 42 00 42'}
                      </span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Why Contact Us Section - Flowing, organic design */}
        <div className="relative rounded-[40px] bg-white shadow-lg p-12 mb-20 overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-80 h-80 bg-navy-50/40 rounded-br-[200px]"></div>
          <div className="absolute bottom-0 right-0 w-60 h-60 bg-accent-50/20 rounded-tl-[120px]"></div>
          
          <div className="relative z-10">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-navy-800 mb-4">Dlaczego warto się z nami skontaktować?</h2>
              <p className="text-navy-600/80 max-w-2xl mx-auto">Nasza misja to łączenie najlepszych pracowników z najlepszymi pracodawcami w branży transportowej.</p>
            </div>
            
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Card 1 */}
              <div className="flex-1 bg-gradient-to-br from-white to-navy-50/60 rounded-[30px] p-8 shadow-md hover:shadow-xl transition-all duration-300 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-navy-100/30 rounded-bl-[40px] group-hover:bg-navy-100/40 transition-all duration-300"></div>
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-br from-navy-100/60 to-white rounded-2xl flex items-center justify-center mb-6 shadow-sm">
                    <CheckCircle2 className="w-8 h-8 text-navy-600/70" />
                  </div>
                  <h3 className="text-xl font-bold text-navy-800 mb-4">Profesjonalne wsparcie</h3>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Szukasz pracy? Doradzimy, jak znaleźć najlepszą ofertę dopasowaną do Twoich kwalifikacji.</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Rekrutujesz? Pomożemy Ci znaleźć idealnego kierowcę lub specjalistę transportu.</p>
                    </li>
                  </ul>
                </div>
              </div>
              
              {/* Card 2 */}
              <div className="flex-1 bg-gradient-to-br from-white to-navy-50/60 rounded-[30px] p-8 shadow-md hover:shadow-xl transition-all duration-300 relative overflow-hidden group">
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-navy-100/30 rounded-tr-[60px] group-hover:bg-navy-100/40 transition-all duration-300"></div>
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-br from-navy-100/60 to-white rounded-2xl flex items-center justify-center mb-6 shadow-sm">
                    <Truck className="w-8 h-8 text-navy-600/70" />
                  </div>
                  <h3 className="text-xl font-bold text-navy-800 mb-4">Indywidualne podejście</h3>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Każda firma transportowa jest inna – dostosowujemy nasze rozwiązania do Twoich potrzeb.</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Tworzymy rozwiązania skrojone na miarę Twojej organizacji i specyfiki Twojego biznesu.</p>
                    </li>
                  </ul>
                </div>
              </div>
              
              {/* Card 3 */}
              <div className="flex-1 bg-gradient-to-br from-white to-navy-50/60 rounded-[30px] p-8 shadow-md hover:shadow-xl transition-all duration-300 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-28 h-28 bg-navy-100/30 rounded-bl-[50px] group-hover:bg-navy-100/40 transition-all duration-300"></div>
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-br from-navy-100/60 to-white rounded-2xl flex items-center justify-center mb-6 shadow-sm">
                    <Clock className="w-8 h-8 text-navy-600/70" />
                  </div>
                  <h3 className="text-xl font-bold text-navy-800 mb-4">Szybka odpowiedź</h3>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Odpowiadamy na Twoje pytania w ciągu 24 godzin, bo wiemy, że czas to pieniądz.</p>
                    </li>
                    <li className="flex items-start">
                      <div className="w-6 h-6 rounded-full bg-accent-100/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-accent-600/80" />
                      </div>
                      <p className="ml-3 text-navy-600/90">Zapewniamy natychmiastowe wsparcie w sprawach wymagających pilnej interwencji.</p>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section - Flowing, organic design */}
        <div className="mb-20 relative">
          <div className="relative rounded-[40px] overflow-hidden">
            <div className="bg-gradient-to-br from-navy-700/90 to-navy-800/90 p-12 md:p-16">
              {/* Decorative elements */}
              <div className="absolute top-0 left-0 w-60 h-60 bg-navy-600/30 rounded-br-[120px]"></div>
              <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-navy-600/20 rounded-tl-[160px]"></div>
              <div className="absolute top-1/3 right-1/4 w-20 h-20 bg-accent-500/10 rounded-full"></div>
              <div className="absolute bottom-1/4 left-1/4 w-16 h-16 bg-accent-500/10 rounded-full"></div>
              
              {/* Truck Icon Decoration */}
              <div className="absolute top-10 right-10 opacity-10">
                <Truck className="w-40 h-40 text-accent-400/40" />
              </div>
              
              <div className="relative z-10 flex flex-col items-center text-center">
                <div className="inline-flex items-center justify-center p-3 bg-navy-600/50 rounded-2xl backdrop-blur-sm mb-6 shadow-lg">
                  <Heart className="h-6 w-6 text-accent-400/80" />
                </div>
                
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 max-w-2xl">
                  🚀 Twoje zaufane źródło rekrutacji transportowej
                </h2>
                
                <p className="text-xl text-navy-100 mb-10 max-w-2xl">
                  Z nami każda rekrutacja ma szansę stać się sukcesem. Nasz zespół ekspertów jest gotowy, aby pomóc Ci znaleźć idealnych kandydatów do Twojej firmy transportowej.
                </p>
                
                <button
                  onClick={() => window.location.href = '/dodaj-ogloszenie'}
                  className="group relative overflow-hidden px-10 py-4 bg-gradient-to-r from-accent-500/80 to-accent-600/80 hover:from-accent-500/90 hover:to-accent-600/90 text-white text-lg font-medium rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
                >
                  <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-accent-400/0 via-accent-400/30 to-accent-400/0 skew-x-[-20deg] translate-x-[-100%] group-hover:translate-x-[100%] transition-all duration-700 ease-in-out"></div>
                  <div className="relative flex items-center">
                    <span>👉 Dodaj ogłoszenie już teraz! 🚛</span>
                    <ArrowRight className="w-5 h-5 ml-3 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// CSS utility for animations
const styles = document.createElement('style');
styles.innerHTML = `
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  @keyframes slideInRight {
    from { 
      opacity: 0;
      transform: translateX(-20px);
    }
    to { 
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  @keyframes slideInLeft {
    from { 
      opacity: 0;
      transform: translateX(20px);
    }
    to { 
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  @keyframes expandAndFade {
    0% { 
      width: 0;
      opacity: 0;
    }
    20% {
      opacity: 0.8;
    }
    100% { 
      width: 20rem;
      opacity: 0.6;
    }
  }
  
  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0px); }
  }
  
  .animate-fadeIn {
    animation: fadeIn 1s forwards;
  }
  
  .animate-slideInRight {
    animation: slideInRight 0.8s forwards;
  }
  
  .animate-slideInLeft {
    animation: slideInLeft 0.8s forwards;
  }
  
  .animate-expand {
    animation: expandAndFade 1.2s forwards;
  }
  
  .animate-float {
    animation: float 3s ease-in-out infinite;
  }
`;
document.head.appendChild(styles);