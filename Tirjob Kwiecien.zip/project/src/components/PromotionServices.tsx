import React, { useEffect } from 'react';
import { 
  Sparkles, Target, Rocket, Film, MapPin, Search, Mail, Share2, 
  Phone, ArrowRight, CheckCircle2, Award, CreditCard, Youtube, Facebook, 
  Instagram, Linkedin, Globe, BarChart, UserCheck, MessageSquare, BellRing,
  Truck
} from 'lucide-react';

export default function PromotionServices() {
  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      @keyframes shimmer {
        0% {
          background-position: -100% 0;
        }
        100% {
          background-position: 200% 0;
        }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
      
      .card-hover {
        transition: all 0.3s ease;
      }
      
      .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 30px -10px rgba(0, 0, 0, 0.1);
      }
      
      .shimmer-effect {
        position: relative;
        overflow: hidden;
      }
      
      .shimmer-effect::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          90deg,
          rgba(255, 255, 255, 0) 0%,
          rgba(255, 255, 255, 0.2) 50%,
          rgba(255, 255, 255, 0) 100%
        );
        background-size: 200% 100%;
        animation: shimmer 2.5s infinite;
      }
    `;
    
    document.head.appendChild(styleElement);
    
    // Clean up on component unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50/70 via-white to-rose-50/30 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-12 animate-on-scroll">
          <h1 className="text-4xl font-bold text-indigo-900 mb-4 relative inline-block">
            🚛 USŁUGI PROMOCJI – Maksymalna Widoczność Twojego Ogłoszenia na TirJob.pl!
            <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-300 via-purple-400 to-pink-300 rounded-full"></div>
          </h1>
          <p className="text-lg text-indigo-700 max-w-3xl mx-auto mb-8">
            Chcesz, aby Twoje ogłoszenie wyróżniło się na tle konkurencji i trafiło dokładnie do kierowców oraz specjalistów transportu, których szukasz? Wyróżnij swoją ofertę i dotrzyj do najlepszych kandydatów szybciej niż kiedykolwiek!
          </p>
          
          {/* Stats */}
          <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 rounded-2xl p-8 shadow-xl mb-12 animate-on-scroll delay-1 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2575&q=80')] opacity-5"></div>
            <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl"></div>
            
            <h2 className="text-2xl font-bold text-white mb-6 relative z-10">📢 TirJob.pl w liczbach:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 border border-white/20">
                <div className="text-3xl font-bold text-white mb-2">50 000+</div>
                <div className="text-indigo-200">aktywnych kierowców i specjalistów</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 border border-white/20">
                <div className="text-3xl font-bold text-white mb-2">97%</div>
                <div className="text-indigo-200">skuteczność kampanii</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 border border-white/20">
                <div className="text-3xl font-bold text-white mb-2">100%</div>
                <div className="text-indigo-200">Cała Polska + międzynarodowy zasięg</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 transform hover:scale-105 transition-transform duration-300 border border-white/20">
                <div className="text-3xl font-bold text-white mb-2">48h</div>
                <div className="text-indigo-200">Średni czas rekrutacji</div>
              </div>
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-indigo-900 mb-8 animate-on-scroll delay-2">
            Wybierz usługę, która zapewni Ci przewagę w rekrutacji!
          </h3>
        </div>

        {/* Divider */}
        <div className="w-full h-1 bg-gradient-to-r from-transparent via-indigo-300 to-transparent mb-16"></div>

        {/* Services Cards - Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-16">
          {/* Advertising Campaigns */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-indigo-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <Rocket className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Kampanie reklamowe</h2>
                  </div>
                  <p className="mt-2 text-indigo-100">Skuteczna promocja Twojej oferty!</p>
                </div>
                <div className="text-2xl font-bold">
                  od 899 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-4 mb-6">
                <p className="text-indigo-700 font-medium">
                  💡 Skuteczna promocja Twojej oferty na Facebooku, Instagramie i Google Ads!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Reklamy w social mediach (Facebook, Instagram, LinkedIn)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Kampanie Google Ads i YouTube</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Precyzyjne targetowanie do kierowców i logistyków</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Profesjonalne projekty graficzne</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-indigo-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Raportowanie wyników kampanii</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i przyspiesz rekrutację
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>

          {/* Video Ad */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll delay-1">
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <Film className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Video ogłoszenie</h2>
                  </div>
                  <p className="mt-2 text-purple-100">Pokaż swoją ofertę w profesjonalnym wideo!</p>
                </div>
                <div className="text-2xl font-bold">
                  1 299 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4 mb-6">
                <p className="text-purple-700 font-medium">
                  🎥 Produkcja dynamicznego 30-60 sekundowego wideo reklamującego Twoją ofertę!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-purple-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Profesjonalny montaż i grafika</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-purple-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Publikacja w social mediach i na stronie</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-purple-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Min. 10 000 wyświetleń</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-purple-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Możliwość wykorzystania na stronie WWW</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i zwiększ zaangażowanie kandydatów
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Services Cards - Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-16">
          {/* Geo-targeted Ad */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll delay-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <MapPin className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Geo-targetowana reklama</h2>
                  </div>
                  <p className="mt-2 text-blue-100">Docieraj do kandydatów w konkretnej lokalizacji!</p>
                </div>
                <div className="text-2xl font-bold">
                  999 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 mb-6">
                <p className="text-blue-700 font-medium">
                  📌 Twoje ogłoszenie dotrze do kandydatów w konkretnej lokalizacji!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Zasięg reklam 1-5 km od Twojej bazy lub placówki</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Targetowanie po specjalizacji (np. kierowcy kat. C+E, spedytorzy, magazynierzy)</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Reklamy display oraz w social mediach</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Raportowanie wyników i optymalizacja kampanii</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i rekrutuj kandydatów z Twojego regionu
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>

          {/* Headhunting Premium */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll delay-3">
            <div className="bg-gradient-to-r from-teal-600 to-emerald-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-teal-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <Search className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Headhunting Premium</h2>
                  </div>
                  <p className="mt-2 text-teal-100">Najlepsi kandydaci wyszukani dla Ciebie!</p>
                </div>
                <div className="text-2xl font-bold">
                  3 499 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-teal-50 to-emerald-50 rounded-xl p-4 mb-6">
                <p className="text-teal-700 font-medium">
                  🎯 Do 10 wyselekcjonowanych kandydatów z rynku, dokładnie dopasowanych do Twoich potrzeb!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-teal-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Weryfikacja doświadczenia i umiejętności</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-teal-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Wstępne rozmowy kwalifikacyjne</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-teal-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Rekomendacje tylko najlepszych kierowców i specjalistów</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-teal-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Wsparcie w całym procesie rekrutacji</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i znajdź topowych specjalistów bez wysiłku
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Services Cards - Row 3 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-16">
          {/* Email Marketing */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll delay-2">
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-amber-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <Mail className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Email Marketing</h2>
                  </div>
                  <p className="mt-2 text-amber-100">Twoja oferta prosto do skrzynek e-mail kandydatów!</p>
                </div>
                <div className="text-2xl font-bold">
                  999 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl p-4 mb-6">
                <p className="text-amber-700 font-medium">
                  📩 Wysyłka do bazy aktywnych kierowców i specjalistów transportu!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Personalizowane wiadomości dla kandydatów</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Profesjonalnie zaprojektowany mailing</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Raport z wysyłki i efektywności kampanii</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Możliwość ponownego follow-upu</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i docieraj bezpośrednio do kandydatów
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>

          {/* Social Media Pack */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-indigo-100 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 card-hover animate-on-scroll delay-3">
            <div className="bg-gradient-to-r from-rose-600 to-pink-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-rose-500/20 rounded-tr-full"></div>
              <div className="flex items-center justify-between relative z-10">
                <div>
                  <div className="flex items-center">
                    <Share2 className="w-8 h-8 mr-3" />
                    <h2 className="text-2xl font-bold">Social Media Pack</h2>
                  </div>
                  <p className="mt-2 text-rose-100">Promocja Twojej oferty w mediach społecznościowych!</p>
                </div>
                <div className="text-2xl font-bold">
                  399 zł
                  <span className="text-sm font-normal block text-right">netto</span>
                </div>
              </div>
            </div>
            <div className="p-6">
              <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-xl p-4 mb-6">
                <p className="text-rose-700 font-medium">
                  📱 Publikacja i promocja Twojego ogłoszenia w mediach społecznościowych!
                </p>
              </div>
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Publikacja Twojego ogłoszenia na profilu TirJob.pl</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Promocja w branżowych grupach Facebook</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Minimum 10 000 wyświetleń</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Optymalizacja treści i grafiki</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="w-5 h-5 text-rose-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span>Raportowanie wyników kampanii</span>
                </li>
              </ul>
              <div className="flex justify-center">
                <a href="/kontakt#top" className="px-6 py-3 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white rounded-full font-medium transition-colors flex items-center shadow-lg hover:shadow-xl shimmer-effect">
                  Zamów teraz i wyróżnij swoje ogłoszenie na Facebooku
                  <ArrowRight className="w-5 h-5 ml-2" />
                </a>
              </div>
            </div>
          </div>
        </div>
        
        {/* Divider */}
        <div className="w-full h-1 bg-gradient-to-r from-transparent via-indigo-300 to-transparent mb-16"></div>

        {/* Contact Section */}
        <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-indigo-800 rounded-2xl shadow-2xl p-12 mb-16 animate-on-scroll delay-2 relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2575&q=80')] opacity-5"></div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl"></div>
          
          <div className="relative z-10 text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              📞 Zwiększ skuteczność swojej rekrutacji!
            </h2>
            <p className="text-lg text-indigo-200 mb-8 max-w-2xl mx-auto">
              Skontaktuj się z nami, aby dobrać najlepszą strategię promocji Twoich ofert pracy!
            </p>
            <div className="flex flex-col md:flex-row justify-center gap-6 mb-8">
              <a
                href="mailto:kontakt@tirjob.pl"
                className="inline-flex items-center justify-center px-6 py-4 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-colors shadow-lg border border-white/20"
              >
                <Mail className="w-6 h-6 mr-2 text-indigo-200" />
                kontakt@tirjob.pl
              </a>
              <a
                href="tel:+48501420042"
                className="inline-flex items-center justify-center px-6 py-4 bg-white/10 backdrop-blur-sm text-white rounded-xl hover:bg-white/20 transition-colors shadow-lg border border-white/20"
              >
                <Phone className="w-6 h-6 mr-2 text-indigo-200" />
                +48 501 42 00 42
              </a>
            </div>
            <p className="text-accent-400 font-medium text-lg">
              TirJob.pl – bo skuteczna rekrutacja w transporcie to podstawa sukcesu! 🚛
            </p>
          </div>
        </div>

        {/* Call to action */}
        <div className="text-center animate-on-scroll delay-3">
          <a href="/kontakt#top" className="inline-block px-10 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-lg font-medium rounded-full shadow-lg hover:shadow-xl transition-all shimmer-effect">
            👉 Zamów promocję już teraz!
          </a>
        </div>
      </div>
    </div>
  );
}