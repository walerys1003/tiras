import React, { useEffect, useState } from 'react';
import { Building2, Banknote, Calendar, ChevronLeft, ChevronRight, Sparkles, Truck } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { getJobListings, type JobListing, type PaginatedResult } from '../lib/jobs';
import { formatExperience, formatSalaryType } from '../lib/utils';
import type { SearchFilters } from './JobSearch';

interface JobListProps {
  searchFilters?: SearchFilters;
}

export default function JobList({ searchFilters }: JobListProps) {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const currentPage = parseInt(searchParams.get('page') || '1', 10);
  const pageSize = 20; // Fixed page size as per requirements
  
  const [jobsData, setJobsData] = useState<PaginatedResult<JobListing> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasInitialLoad, setHasInitialLoad] = useState(false);

  useEffect(() => {
    async function fetchJobs() {
      setIsLoading(true);
      setError(null);
      try {
        const result = await getJobListings(searchFilters, currentPage, pageSize);
        if (result.success && result.data) {
          setJobsData(result.data);
        } else {
          throw new Error('Nie udało się pobrać ofert pracy');
        }
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError('Wystąpił błąd podczas pobierania ofert pracy. Spróbuj ponownie później.');
        setJobsData(null);
      } finally {
        setIsLoading(false);
        setHasInitialLoad(true);
      }
    }

    fetchJobs();
  }, [searchFilters, currentPage, pageSize]);

  const handlePageChange = (newPage: number) => {
    // Update URL with new page number
    setSearchParams(prev => {
      const newParams = new URLSearchParams(prev);
      newParams.set('page', newPage.toString());
      return newParams;
    });
    
    // Scroll to top of the page
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading && !hasInitialLoad) {
    return (
      <div className="w-full text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Ładowanie ofert pracy...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full text-center py-12">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  if (hasInitialLoad && (!jobsData || jobsData.data.length === 0)) {
    return (
      <div className="w-full text-center py-12">
        <p className="text-gray-600">Brak aktualnych ofert pracy spełniających wybrane kryteria.</p>
      </div>
    );
  }

  return (
    <div className="w-full lg:mt-0 mt-4">
      <h2 className="text-xl font-semibold text-navy-900 mb-6 gap-2">
        Znaleźliśmy dla Ciebie
        <span className="text-accent-600"> {jobsData?.totalCount || 0} </span>
        ogłoszeń pracy
      </h2>
      
      <div className="space-y-4">
        {jobsData?.data?.map((job) => (
          <div 
            key={job.id} 
            className={`relative bg-white rounded-lg transition-all duration-200 cursor-pointer ${
              job.is_premium 
                ? 'shadow-lg hover:shadow-xl border-2 border-accent-200' 
                : 'shadow hover:shadow-lg'
            }`}
            onClick={() => navigate(`/oferty-pracy/${encodeURIComponent(job.id)}`)}
          >
            {job.is_premium && (
              <div className="absolute -top-3 left-4">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-500 text-white shadow-sm">
                  <Sparkles className="w-4 h-4 mr-1" />
                  Ogłoszenie Premium
                </span>
              </div>
            )}
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className={`text-lg font-semibold hover:text-accent-600 transition-colors ${
                    job.is_premium ? 'text-accent-700' : 'text-navy-900'
                  }`}>
                    {job.title}
                  </h3>
                  <div className="flex items-center text-gray-600 mt-1">
                    <Building2 className="w-4 h-4 mr-2" />
                    <span className="hover:text-accent-600 transition-colors">
                      {job.company.name}
                    </span>
                  </div>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(job.created_at).toLocaleDateString('pl-PL')}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center text-gray-700">
                  <Banknote className="w-4 h-4 mr-2 text-gray-500" />
                  {job.salary_amount} {job.salary_currency} ({formatSalaryType(job.salary_type)})
                </div>
                <div className="flex items-center text-gray-700">
                  <Calendar className="w-4 h-4 mr-2 text-gray-500" />
                  {job.schedule}
                </div>
                <div className="flex items-center text-gray-700">
                  <Truck className="w-4 h-4 mr-2 text-gray-500" />
                  {job.trailer_type}
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {Array.isArray(job.requirements) && job.requirements.map(req => (
                  <span
                    key={req.experience}
                    className="bg-navy-50 text-navy-700 text-sm px-3 py-1 rounded-full"
                  >
                    {formatExperience(req.experience)}
                  </span>
                ))}
                {Array.isArray(job.languages) && job.languages.map(lang => (
                  <span
                    key={lang.language}
                    className="bg-navy-50 text-navy-700 text-sm px-3 py-1 rounded-full"
                  >
                    {lang.language}
                  </span>
                ))}
                {Array.isArray(job.qualifications) && job.qualifications.map(qual => (
                  <span
                    key={qual.qualification}
                    className="bg-navy-50 text-navy-700 text-sm px-3 py-1 rounded-full"
                  >
                    {qual.qualification}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {jobsData?.totalPages > 1 && (
        <div className="mt-8 flex justify-center items-center">
          <nav className="flex items-center space-x-2" aria-label="Pagination">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent"
              aria-label="Poprzednia strona"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="flex items-center space-x-1">
              {/* Generate page numbers */}
              {Array.from({ length: jobsData?.totalPages || 0 }, (_, i) => i + 1).map((page) => {
                // Show first page, last page, current page, and pages around current page
                const shouldShowPage = 
                  page === 1 || 
                  page === jobsData?.totalPages || 
                  (page >= currentPage - 2 && page <= currentPage + 2);
                
                // Show ellipsis for gaps
                if (!shouldShowPage) {
                  // Show ellipsis only once for each gap
                  if (page === 2 || page === jobsData?.totalPages - 1) {
                    return (
                      <span key={`ellipsis-${page}`} className="px-2">
                        ...
                      </span>
                    );
                  }
                  return null;
                }
                
                return (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`w-10 h-10 rounded-lg text-sm font-medium flex items-center justify-center ${
                      currentPage === page
                        ? 'bg-accent-600 text-white'
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                    aria-current={currentPage === page ? 'page' : undefined}
                  >
                    {page}
                  </button>
                );
              })}
            </div>
            
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === jobsData?.totalPages}
              className="p-2 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-transparent"
              aria-label="Następna strona"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </nav>
        </div>
      )}
    </div>
  );
}