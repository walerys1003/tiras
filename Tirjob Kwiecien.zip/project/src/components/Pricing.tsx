import React from 'react';
import { 
  Clock, Users, Target, Truck, Building2, CheckCircle2, 
  Star, Sparkles, Award, Phone, Mail, ArrowRight, Rocket, Shield
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSettings } from '../hooks/useSettings';

export default function Pricing() {
  const navigate = useNavigate();
  const { settings } = useSettings();
  
  // Get pricing information from settings
  const standardPrice = settings.job_post_price || '500';
  const premiumPrice = settings.job_post_premium_price || '750';
  const standardDuration = settings.job_post_duration || '60';
  const premiumDuration = settings.job_post_premium_duration || '90';

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-50 to-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-navy-700 to-navy-900 py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2575&q=80')] opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <h1 className="text-5xl font-bold text-white mb-8">
              TirJob.pl – Twój klucz do najlepszych kierowców i specjalistów branży transportowej!
            </h1>
            <p className="text-xl text-navy-100 max-w-3xl mx-auto leading-relaxed">
              W branży transportowej czas to pieniądz, a sprawna rekrutacja to fundament działania każdej firmy logistycznej. TirJob.pl to platforma stworzona z myślą o transporcie – łączy pracodawców z najlepszymi kierowcami i ekspertami branży transportowej.
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-navy-900 mb-4">
            Dlaczego warto publikować oferty na TirJob.pl?
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 group">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Tworzony dla transportu
            </h3>
            <p className="text-navy-600">
              Trafiasz bezpośrednio do kierowców i specjalistów, którzy szukają pracy w Twojej branży.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 group">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Precyzyjne targetowanie
            </h3>
            <p className="text-navy-600">
              Filtruj kandydatów według kategorii prawa jazdy, doświadczenia i lokalizacji.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 group">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Szybka publikacja
            </h3>
            <p className="text-navy-600">
              Dodaj ogłoszenie w mniej niż 3 minuty – bez zbędnych formalności!
            </p>
          </div>
          
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200 group">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Rocket className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Maksymalna widoczność
            </h3>
            <p className="text-navy-600">
              Twoja oferta trafi do tysięcy aktywnych użytkowników i pojawi się w wynikach wyszukiwania Google.
            </p>
          </div>
        </div>
      </div>

      {/* Main Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Standard Plan */}
          <div className="bg-white rounded-3xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-navy-900">Ogłoszenie Standard</h2>
                <div className="flex items-center gap-2 mt-2">
                  <p className="text-2xl font-semibold text-accent-600">{standardPrice} zł z VAT</p>
                  <span className="text-navy-600 text-sm">/ {standardDuration} dni</span>
                </div>
              </div>
              <div className="w-16 h-16 bg-accent-100 text-accent-600 rounded-2xl flex items-center justify-center">
                <Truck className="w-8 h-8" />
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Długa ekspozycja</h3>
                  <p className="text-navy-600">{standardDuration} dni za jedyne {standardPrice} zł</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Dotarcie do specjalistów</h3>
                  <p className="text-navy-600">Kierowcy i eksperci transportu gotowi do pracy</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Target className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Precyzyjne targetowanie</h3>
                  <p className="text-navy-600">Filtruj kandydatów według kategorii i doświadczenia</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => navigate('/dodaj-ogloszenie')}
              className="w-full bg-accent-600 text-white px-8 py-4 rounded-xl text-lg font-medium hover:bg-accent-700 transition-all duration-200 flex items-center justify-center gap-2"
            >
              Dodaj ogłoszenie
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          {/* Premium Plan */}
          <div className="bg-gradient-to-br from-accent-50 to-white rounded-3xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border-2 border-accent-200">
            <div className="flex items-center justify-between mb-8">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-6 h-6 text-accent-600" />
                  <span className="text-accent-600 font-medium">Rekomendowane</span>
                </div>
                <h2 className="text-3xl font-bold text-navy-900">Ogłoszenie Premium</h2>
                <div className="flex items-center gap-2 mt-2">
                  <p className="text-2xl font-semibold text-accent-600">{premiumPrice} zł z VAT</p>
                  <span className="text-navy-600 text-sm">/ {premiumDuration} dni</span>
                </div>
              </div>
              <div className="w-16 h-16 bg-accent-100 text-accent-600 rounded-2xl flex items-center justify-center">
                <Sparkles className="w-8 h-8" />
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Wszystkie funkcje Standard</h3>
                  <p className="text-navy-600">{premiumDuration} dni ekspozycji (+{parseInt(premiumDuration) - parseInt(standardDuration)} dni więcej), targetowanie, dotarcie do specjalistów</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Star className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Wyróżnienie wizualne</h3>
                  <p className="text-navy-600">Specjalna ramka i oznaczenie "Premium" przyciągające uwagę</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-accent-100 text-accent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Rocket className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-medium text-navy-900">Priorytetowa pozycja</h3>
                  <p className="text-navy-600">Wyższa pozycja w wynikach wyszukiwania</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => navigate('/dodaj-ogloszenie')}
              className="w-full bg-accent-600 text-white px-8 py-4 rounded-xl text-lg font-medium hover:bg-accent-700 transition-all duration-200 flex items-center justify-center gap-2"
            >
              Dodaj ogłoszenie Premium i zwiększ skuteczność
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="text-center mt-8 text-navy-600">
          <p className="text-lg">
            Wybierz plan odpowiedni dla Twoich potrzeb i zacznij rekrutować najlepszych specjalistów transportu już dziś!
          </p>
        </div>
      </div>

      {/* Distinguishing Features */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 bg-gradient-to-br from-navy-50 to-white rounded-3xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-navy-900 mb-4">
            Co nas wyróżnia?
          </h2>
          <p className="text-lg text-navy-600 max-w-3xl mx-auto">
            Jesteśmy ekspertami w branży transportowej, oferując najwyższej jakości usługi dla naszych klientów
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Knowledge */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Wiedza
            </h3>
            <p className="text-navy-600">
              Jesteśmy portalem skupionym na branży transportowo-spedycyjnej. Wiemy jakie są potrzeby i trudności.
            </p>
          </div>

          {/* Flexibility */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Elastyczność
            </h3>
            <p className="text-navy-600">
              Dostosowywujemy nasze funkcjonalności do potrzeb naszych klientów oraz użytkowników.
            </p>
          </div>

          {/* Communication */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Phone className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Komunikacja
            </h3>
            <p className="text-navy-600">
              Nasz dział techninczny oraz sprzedaży jest do Twojej dyspozycji. Masz pytania? Skontaktuj się z nami!
            </p>
          </div>

          {/* Offer Updates */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Aktualizacja ofert
            </h3>
            <p className="text-navy-600">
              Na bierząco powiadamiamy Cię o terminie wygaśnięcia Twojej oferty, aby zachować dla naszych użytkowników wyłącznie aktualne możliwości rozwoju.
            </p>
          </div>

          {/* Verification */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Weryfikacja
            </h3>
            <p className="text-navy-600">
              Wyróżnij swoją firmę na tle konkurencji. Z nami otrzymasz dodatkową wiarygodność i zaufanie.
            </p>
          </div>

          {/* Security */}
          <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
            <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-semibold text-navy-900 mb-3">
              Gwarancja bezpieczeństwa
            </h3>
            <p className="text-navy-600">
              Przetwarzamy dane naszych klientów oraz użytkowników zgodnie z obowiązującymi przepisami.
            </p>
          </div>
        </div>
      </div>

      {/* How it Works Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-navy-900 mb-20 text-center">
          Jak działa TirJob.pl?
        </h2>
        
        <div className="relative pb-24">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-accent-200" />
          
          <div className="relative">
            {/* Step 1 */}
            <div className="flex items-center justify-center mb-32">
              <div className="w-1/2 pr-20 text-right">
                <h3 className="text-xl font-semibold text-navy-900 mb-2">Dodajesz ogłoszenie</h3>
                <p className="text-navy-600">Wybierasz stanowisko, wymagania i wynagrodzenie – to proste i intuicyjne!</p>
              </div>
              <div className="relative flex-shrink-0">
                <div className="w-14 h-14 bg-accent-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                  1
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-center justify-center mb-32">
              <div className="w-1/2 pr-20 opacity-0" />
              <div className="relative flex-shrink-0">
                <div className="w-14 h-14 bg-accent-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                  2
                </div>
              </div>
              <div className="w-1/2 pl-20">
                <h3 className="text-xl font-semibold text-navy-900 mb-2">Twoja oferta dociera do najlepszych kandydatów</h3>
                <p className="text-navy-600">Publikujemy Twoje ogłoszenie i promujemy je w odpowiednich miejscach.</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-center justify-center mb-32">
              <div className="w-1/2 pr-20 text-right">
                <h3 className="text-xl font-semibold text-navy-900 mb-2">Otrzymujesz aplikacje</h3>
                <p className="text-navy-600">Kandydaci aplikują bezpośrednio przez portal lub kontaktują się telefonicznie.</p>
              </div>
              <div className="relative flex-shrink-0">
                <div className="w-14 h-14 bg-accent-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                  3
                </div>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-center justify-center mb-32">
              <div className="w-1/2 pr-20 opacity-0" />
              <div className="relative flex-shrink-0">
                <div className="w-14 h-14 bg-accent-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                  4
                </div>
              </div>
              <div className="w-1/2 pl-20">
                <h3 className="text-xl font-semibold text-navy-900 mb-2">Zatrudniasz najlepszych pracowników</h3>
                <p className="text-navy-600">Szybko i skutecznie znajdujesz idealnego kierowcę lub specjalistę do swojej firmy.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Target Audience */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="bg-gradient-to-br from-navy-50 to-white rounded-3xl shadow-xl p-12">
          <h2 className="text-3xl font-bold text-navy-900 mb-12 text-center">
            Dla kogo jest TirJob.pl?
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
              <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">
                Firmy transportowe i spedycyjne
              </h3>
              <p className="text-navy-600">
                Znajdź najlepszych kierowców i spedytorów.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
              <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">
                Operatorzy flot
              </h3>
              <p className="text-navy-600">
                Rekrutuj doświadczonych opiekunów floty i referentów FK.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
              <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">
                Firmy logistyczne i magazynowe
              </h3>
              <p className="text-navy-600">
                Znajdź planistów, dyspozytorów i handlowców.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-200">
              <div className="w-12 h-12 bg-accent-100 text-accent-600 rounded-xl flex items-center justify-center mb-6">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-navy-900 mb-3">
                Branża budowlana
              </h3>
              <p className="text-navy-600">
                Zatrudnij kierowców ciężarówek i specjalistów budowlanych.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="bg-white rounded-3xl shadow-xl p-12 text-center">
          <h2 className="text-3xl font-bold text-navy-900 mb-8">
            Masz pytania? Skontaktuj się z nami!
          </h2>
          <div className="flex justify-center gap-12">
            <a
              href={`mailto:${settings.contact_email || 'kontakt@tirjob.pl'}`}
              className="flex items-center gap-3 text-lg text-navy-700 hover:text-accent-600 transition-colors"
            >
              <Mail className="w-6 h-6" />
              {settings.contact_email || 'kontakt@tirjob.pl'}
            </a>
            <a
              href={`tel:${settings.contact_phone || '+48501420042'}`}
              className="flex items-center gap-3 text-lg text-navy-700 hover:text-accent-600 transition-colors"
            >
              <Phone className="w-6 h-6" />
              {settings.contact_phone || '+48 501 42 00 42'}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}