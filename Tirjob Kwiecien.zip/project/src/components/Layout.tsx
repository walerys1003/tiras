import React from 'react';
import { useLocation } from 'react-router-dom';
import SeoHead from './SeoHead';

interface LayoutProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  dynamicData?: {
    title?: string;
    description?: string;
    image?: string;
    type?: string;
    keywords?: string;
    schemaData?: any;
  };
}

export default function Layout({ children, title, description, dynamicData }: LayoutProps) {
  const location = useLocation();
  
  return (
    <>
      <SeoHead 
        path={location.pathname} 
        defaultTitle={title}
        defaultDescription={description}
        dynamicData={dynamicData}
      />
      {children}
    </>
  );
}