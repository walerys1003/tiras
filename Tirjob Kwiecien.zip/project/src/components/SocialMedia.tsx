import React, { useEffect } from 'react';
import { Facebook, Instagram, Linkedin, Users, CheckCircle2, ExternalLink, Share2, MessageSquare, Truck, ArrowRight, Globe } from 'lucide-react';
import { useSettings } from '../hooks/useSettings';

export default function SocialMedia() {
  const { settings } = useSettings();
  
  // Add animation classes on component mount
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes scaleX {
        from { transform: scaleX(0); }
        to { transform: scaleX(1); }
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-scale-x {
        animation: scaleX 1.5s ease-out forwards;
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .fade-up {
        opacity: 0;
        transform: translateY(30px);
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
    `;
    
    document.head.appendChild(styleElement);
    
    // Clean up on component unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
      {/* Hero Section with Animated Background */}
      <div className="relative overflow-hidden pt-24 pb-16">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
          <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
          <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
          <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
        </div>
        
        {/* Animated Truck Icon */}
        <div className="absolute bottom-0 left-0 opacity-10 animate-float">
          <Truck className="w-64 h-64 text-navy-400" />
        </div>
        
        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <div className="text-center mb-8 animate-on-scroll fade-up">
            <h1 className="text-5xl font-bold text-navy-800 mb-6">
              <span className="relative inline-block">
                TirJob.pl w Social Media
                <div className="absolute bottom-0 left-0 w-full h-1 bg-accent-400/30 rounded-full transform scale-x-0 animate-scale-x origin-left"></div>
              </span>
            </h1>
            <p className="text-xl text-navy-600/90 max-w-3xl mx-auto">
              Dołącz do naszej społeczności i bądź na bieżąco z najnowszymi informacjami z branży transportowej
            </p>
          </div>
          
          {/* Visual banner with message */}
          <div className="relative bg-white rounded-3xl shadow-xl p-8 max-w-5xl mx-auto animate-on-scroll fade-up delay-1">
            <div className="absolute top-0 right-0 w-32 h-32 bg-navy-50/40 rounded-bl-[60px]"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-accent-50/30 rounded-tr-[40px]"></div>
            
            <div className="relative flex items-center gap-6 z-10">
              <div className="hidden md:block">
                <div className="w-24 h-24 bg-gradient-to-br from-navy-100/40 to-white rounded-2xl flex items-center justify-center shadow-soft">
                  <Truck className="w-14 h-14 text-navy-600/80" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-navy-800 mb-3">
                  Szukasz pracy jako kierowca, spedytor lub logistyk?
                </h2>
                <p className="text-navy-600/90">
                  Sprawdź najnowsze ogłoszenia, które są dopasowane do Twoich kwalifikacji i preferencji!
                  TIRJOB.PL to miejsce, gdzie profesjonalni kierowcy oraz specjaliści z branży TSL znajdują 
                  sprawdzone oferty pracy od renomowanych firm transportowych i logistycznych.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Join Our Community Section */}
        <div className="relative mb-20 animate-on-scroll fade-up">
          <div className="absolute inset-0 bg-gradient-to-br from-navy-700/90 to-navy-800/90 rounded-3xl transform rotate-1 scale-105 opacity-30 blur-lg"></div>
          <div className="relative bg-gradient-to-br from-navy-700/90 to-navy-800/90 rounded-3xl shadow-xl p-10 overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 left-0 w-60 h-60 bg-navy-600/30 rounded-br-[120px]"></div>
            <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-navy-600/20 rounded-tl-[160px]"></div>
            <div className="absolute top-1/3 right-1/4 w-20 h-20 bg-accent-500/10 rounded-full"></div>
            <div className="absolute bottom-1/4 left-1/4 w-16 h-16 bg-accent-500/10 rounded-full"></div>
            
            <div className="relative z-10 text-center">
              <div className="inline-flex items-center justify-center p-3 bg-navy-600/50 rounded-2xl backdrop-blur-sm mb-6 shadow-lg">
                <Users className="h-6 w-6 text-accent-400/80" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                📌 Dołącz do naszej społeczności!
              </h2>
              <p className="text-xl text-navy-100 max-w-3xl mx-auto">
                Bądź na bieżąco i śledź nas w mediach społecznościowych, aby nie przegapić najlepszych ofert pracy, 
                porad dla kierowców i informacji branżowych!
              </p>
            </div>
          </div>
        </div>

        {/* Social Media Cards - Staggered Layout */}
        <div className="mb-20">
          {/* Facebook Card */}
          <div className="group relative mb-16 animate-on-scroll fade-up">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#1877F2]/20 to-[#1877F2]/5 rounded-3xl blur-lg transform rotate-1 scale-105 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
            <div className="relative bg-white rounded-3xl shadow-soft overflow-hidden flex flex-col md:flex-row">
              {/* Left Side - Colorful */}
              <div className="md:w-2/5 bg-gradient-to-br from-[#1877F2]/90 to-[#0e6edb]/90 p-10 flex flex-col justify-center">
                <div className="mb-8">
                  <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
                    <Facebook className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-3">Facebook</h3>
                  <p className="text-xl text-blue-100">
                    Grupa dla Profesjonalnych Kierowców
                  </p>
                </div>
                <div className="mt-auto hidden md:block">
                  <a 
                    href={settings.facebook_url || "https://www.facebook.com/groups/kierowcyciezarowekpraca"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-white/20 hover:bg-white/30 text-white py-3 px-6 rounded-xl transition-all duration-300 backdrop-blur-sm"
                  >
                    <span>Dołącz do grupy</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
              
              {/* Right Side - Content */}
              <div className="md:w-3/5 p-10">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-[#1877F2]/10 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-[#1877F2]" />
                  </div>
                  <h4 className="ml-4 text-xl font-bold text-navy-800">
                    „Kierowcy Zawodowi – Praca i Oferty w TSL"
                  </h4>
                </div>
                
                <div className="mb-8">
                  <p className="font-medium text-navy-800 mb-4">💬 W grupie znajdziesz:</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#1877F2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#1877F2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Codziennie aktualizowane oferty pracy dla kierowców kat. B, C, C+E i D.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#1877F2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#1877F2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Wymianę doświadczeń i porady dotyczące pracy w branży transportowej.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#1877F2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#1877F2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Informacje o wynagrodzeniach, warunkach zatrudnienia i trendach w TSL.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#1877F2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#1877F2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Możliwość kontaktu z pracodawcami i rekruterami.</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-auto block md:hidden">
                  <a 
                    href={settings.facebook_url || "https://www.facebook.com/groups/kierowcyciezarowekpraca"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-[#1877F2] text-white py-3 px-6 rounded-xl hover:bg-[#0e6edb] transition-colors duration-300"
                  >
                    <span>Dołącz do grupy</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* LinkedIn Card */}
          <div className="group relative mb-16 animate-on-scroll fade-up delay-1">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#0A66C2]/20 to-[#0A66C2]/5 rounded-3xl blur-lg transform -rotate-1 scale-105 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
            <div className="relative bg-white rounded-3xl shadow-soft overflow-hidden flex flex-col md:flex-row-reverse">
              {/* Right Side - Colorful (reverse layout) */}
              <div className="md:w-2/5 bg-gradient-to-br from-[#0A66C2]/90 to-[#084b8e]/90 p-10 flex flex-col justify-center">
                <div className="mb-8">
                  <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
                    <Linkedin className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-3">LinkedIn</h3>
                  <p className="text-xl text-blue-100">
                    Profesjonalna Sieć dla Branży Transportowej
                  </p>
                </div>
                <div className="mt-auto hidden md:block">
                  <a 
                    href={settings.linkedin_url || "https://linkedin.com/company/tirjob"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-white/20 hover:bg-white/30 text-white py-3 px-6 rounded-xl transition-all duration-300 backdrop-blur-sm"
                  >
                    <span>Przejdź do LinkedIn</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
              
              {/* Left Side - Content (reverse layout) */}
              <div className="md:w-3/5 p-10">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-[#0A66C2]/10 rounded-xl flex items-center justify-center">
                    <Globe className="w-6 h-6 text-[#0A66C2]" />
                  </div>
                  <h4 className="ml-4 text-xl font-bold text-navy-800">
                    TIRJOB.PL na LinkedIn
                  </h4>
                </div>
                
                <div className="mb-8">
                  <p className="font-medium text-navy-800 mb-4">🌍 Dołącz, jeśli:</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#0A66C2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#0A66C2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Szukasz nowych ofert pracy w logistyce, spedycji lub transporcie.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#0A66C2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#0A66C2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Chcesz rozwijać swoją karierę i być na bieżąco z nowinkami z branży.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#0A66C2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#0A66C2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Jesteś rekruterem i chcesz dotrzeć do najlepszych kierowców i specjalistów TSL.</p>
                    </div>
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-[#0A66C2]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-[#0A66C2]" />
                      </div>
                      <p className="ml-3 text-navy-700">Chcesz otrzymywać ekskluzywne porady dotyczące zatrudnienia i pracy w transporcie.</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-auto block md:hidden">
                  <a 
                    href={settings.linkedin_url || "https://linkedin.com/company/tirjob"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-[#0A66C2] text-white py-3 px-6 rounded-xl hover:bg-[#084b8e] transition-colors duration-300"
                  >
                    <span>Przejdź do LinkedIn</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Instagram Card */}
          <div className="group relative animate-on-scroll fade-up delay-2">
            <div className="absolute -inset-1 bg-gradient-to-r from-[#833AB4]/20 via-[#E1306C]/20 to-[#F77737]/20 rounded-3xl blur-lg transform rotate-1 scale-105 opacity-0 group-hover:opacity-100 transition-all duration-700"></div>
            <div className="relative bg-white rounded-3xl shadow-soft overflow-hidden flex flex-col md:flex-row">
              {/* Left Side - Colorful */}
              <div className="md:w-2/5 bg-gradient-to-br from-[#833AB4]/90 via-[#E1306C]/90 to-[#F77737]/90 p-10 flex flex-col justify-center">
                <div className="mb-8">
                  <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
                    <Instagram className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-3">Instagram</h3>
                  <p className="text-xl text-pink-100">
                    Życie Kierowców od Kuchni 🚛📸
                  </p>
                </div>
                <div className="mt-auto hidden md:block">
                  <a 
                    href={settings.instagram_url || "https://www.instagram.com/tirjob.pl"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-white/20 hover:bg-white/30 text-white py-3 px-6 rounded-xl transition-all duration-300 backdrop-blur-sm"
                  >
                    <span>Przejdź do Instagrama</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
              
              {/* Right Side - Content */}
              <div className="md:w-3/5 p-10">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-pink-500/10 rounded-xl flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-pink-500" />
                  </div>
                  <h4 className="ml-4 text-xl font-bold text-navy-800">
                    Obserwuj nas na Instagramie
                  </h4>
                </div>
                
                <div className="mb-8">
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-y-8 gap-x-4">
                      <div className="bg-gradient-to-br from-pink-50/80 to-white rounded-2xl p-6 shadow-soft transform transition-transform hover:scale-105">
                        <div className="w-12 h-12 bg-pink-500/10 rounded-xl flex items-center justify-center mb-4">
                          <CheckCircle2 className="w-6 h-6 text-pink-500" />
                        </div>
                        <h5 className="font-bold text-navy-800 mb-2">Kulisy pracy kierowców</h5>
                        <p className="text-navy-600">Zobacz, jak wygląda codzienne życie w trasie - spektakularne widoki i wyzwania.</p>
                      </div>
                      
                      <div className="bg-gradient-to-br from-orange-50/80 to-white rounded-2xl p-6 shadow-soft transform transition-transform hover:scale-105">
                        <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mb-4">
                          <CheckCircle2 className="w-6 h-6 text-orange-500" />
                        </div>
                        <h5 className="font-bold text-navy-800 mb-2">Inspiracje i porady</h5>
                        <p className="text-navy-600">Praktyczne wskazówki dotyczące stylu życia w trasie i rozwoju kariery kierowcy.</p>
                      </div>
                      
                      <div className="md:col-span-2 bg-gradient-to-br from-purple-50/80 to-white rounded-2xl p-6 shadow-soft transform transition-transform hover:scale-105">
                        <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center mb-4">
                          <CheckCircle2 className="w-6 h-6 text-purple-500" />
                        </div>
                        <h5 className="font-bold text-navy-800 mb-2">Codzienne relacje z najlepszymi ofertami pracy</h5>
                        <p className="text-navy-600">Śledź nasze InstaStories z najnowszymi ofertami pracy i wydarzeniami z branży transportowej.</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-auto block md:hidden">
                  <a 
                    href={settings.instagram_url || "https://www.instagram.com/tirjob.pl"} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-gradient-to-r from-[#833AB4] via-[#E1306C] to-[#F77737] text-white py-3 px-6 rounded-xl hover:opacity-90 transition-opacity duration-300"
                  >
                    <span>Przejdź do Instagrama</span>
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer CTA */}
        <div className="relative mb-16 animate-on-scroll fade-up delay-3">
          <div className="absolute inset-0 bg-white rounded-3xl shadow-xl transform rotate-1 scale-105 opacity-30 blur-md"></div>
          <div className="relative bg-white rounded-3xl shadow-xl p-12 overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 left-0 w-40 h-40 bg-navy-50/40 rounded-br-[80px]"></div>
            <div className="absolute bottom-0 right-0 w-60 h-60 bg-accent-50/30 rounded-tl-[120px]"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
              <div className="flex-shrink-0">
                <div className="w-24 h-24 bg-gradient-to-br from-navy-100/40 to-white rounded-2xl flex items-center justify-center shadow-soft">
                  <Share2 className="w-12 h-12 text-accent-600/80" />
                </div>
              </div>
              <div className="flex-grow text-center md:text-left">
                <h2 className="text-2xl font-bold text-navy-800 mb-3">
                  TIRJOB.PL to więcej niż portal ogłoszeń
                </h2>
                <p className="text-xl text-navy-700 mb-4">
                  To społeczność dla kierowców i specjalistów TSL!
                </p>
                <button className="bg-accent-600/90 hover:bg-accent-600 text-white py-3 px-8 rounded-full text-lg font-medium transition-colors flex items-center mx-auto md:mx-0 group">
                  <span>Dołącz do nas w mediach społecznościowych!</span>
                  <ArrowRight className="w-5 h-5 ml-2 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}