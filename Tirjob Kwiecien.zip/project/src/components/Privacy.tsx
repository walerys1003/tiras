import React, { useEffect } from 'react';
import { Shield, Truck, Phone, Mail, Lock, Key, Cookie, Database, UserCheck, FileText } from 'lucide-react';

export default function Privacy() {
  // Add animation for elements
  useEffect(() => {
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
        }
      });
    }, { threshold: 0.1 });
    
    animatedElements.forEach(el => observer.observe(el));
    
    return () => animatedElements.forEach(el => observer.unobserve(el));
  }, []);

  // Add the animation styles to the document head
  useEffect(() => {
    const styleElement = document.createElement('style');
    styleElement.textContent = `
      @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .animate-on-scroll {
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.8s ease-out, transform 0.8s ease-out;
      }
      
      .animate-visible {
        opacity: 1;
        transform: translateY(0);
      }
      
      .animate-float {
        animation: float 4s ease-in-out infinite;
      }
      
      .animate-pulse {
        animation: pulse 3s ease-in-out infinite;
      }
      
      .delay-1 {
        transition-delay: 0.2s;
      }
      
      .delay-2 {
        transition-delay: 0.4s;
      }
      
      .delay-3 {
        transition-delay: 0.6s;
      }
      
      .delay-4 {
        transition-delay: 0.8s;
      }
      
      .shadow-soft {
        box-shadow: 0 10px 25px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
      }
    `;
    
    document.head.appendChild(styleElement);
    
    // Clean up on component unmount
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-50/70 to-white">
      {/* Hero Section with Animated Background */}
      <div className="relative overflow-hidden pt-16 pb-12">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-64 bg-navy-100/20 rounded-bl-[100px] rounded-br-[40px]"></div>
          <div className="absolute top-40 -left-20 w-80 h-80 bg-navy-100/10 rounded-full"></div>
          <div className="absolute top-20 right-10 w-40 h-40 bg-accent-100/20 rounded-full"></div>
          <div className="absolute -bottom-10 right-0 w-[500px] h-[300px] bg-navy-50/30 rounded-tl-[120px]"></div>
        </div>
        
        {/* Animated Truck Icon */}
        <div className="absolute bottom-0 left-0 opacity-10 animate-float">
          <Truck className="w-64 h-64 text-navy-400" />
        </div>
        
        {/* Content */}
        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 z-10">
          <div className="text-center mb-12 animate-on-scroll">
            <span className="inline-block px-4 py-2 rounded-full bg-navy-100/50 text-navy-700 font-medium text-sm mb-4">
              DOKUMENTY PRAWNE
            </span>
            <h1 className="text-4xl font-bold text-navy-900 mb-4">
              Polityka prywatności i cookies – TirJob.pl
            </h1>
            <p className="text-lg text-navy-600/90 max-w-3xl mx-auto">
              Obowiązuje od 01.03.2025
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-10 animate-on-scroll">
          <div className="prose prose-lg max-w-none text-navy-800">
            <p className="text-center text-navy-700 font-medium mb-8">
              🛡️ Dbamy o Twoją prywatność i transparentność przetwarzania danych osobowych
            </p>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <Shield className="w-4 h-4 text-navy-600" />
              </span>
              📌 Administrator danych
            </h2>
            
            <p className="mb-4">
              Administratorem danych osobowych jest W3 B2B SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą przy ul. Świeradowska 47, 02-662 Warszawa, Polska, wpisana do Krajowego Rejestru Sądowego pod numerem KRS: 0001115407, posiadająca NIP: 1133139476 oraz REGON: 529115601.
            </p>
            <p>
              Wszelkie pytania dotyczące ochrony danych osobowych można kierować na adres e-mail: <a href="mailto:kontakt@tirjob.pl" className="text-accent-600 hover:text-accent-700">kontakt@tirjob.pl</a>
            </p>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <Database className="w-4 h-4 text-navy-600" />
              </span>
              📌 Cele przetwarzania danych
            </h2>
            
            <h3 className="text-xl font-bold text-navy-800 mb-3">A. Świadczenie usług</h3>
            <p className="mb-4">
              Dane osobowe Użytkowników są przetwarzane w celu umożliwienia korzystania z Serwisu TirJob.pl, w tym:
            </p>
            <ul className="list-none pl-5 space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Publikacji i zarządzania ogłoszeniami o pracę w branży transportowej.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Aplikowania przez kandydatów na dostępne oferty pracy.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Realizacji umowy o świadczenie usług drogą elektroniczną (art. 6 ust. 1 lit. b RODO).</span>
              </li>
            </ul>
            <p className="mb-4">
              Dane będą przechowywane do czasu realizacji usługi.
            </p>

            <h3 className="text-xl font-bold text-navy-800 mb-3">B. Marketing i promocja</h3>
            <p className="mb-4">
              Dane mogą być przetwarzane w celach marketingowych i promocyjnych Serwisu TirJob.pl, które stanowią uzasadniony interes Administratora (art. 6 ust. 1 lit. f RODO).
            </p>
            <p className="mb-4">
              Obejmuje to m.in.:
            </p>
            <ul className="list-none pl-5 space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">📩</span>
                <span>Wysyłkę newslettera i ofert pracy.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">📢</span>
                <span>Kampanie reklamowe i remarketingowe.</span>
              </li>
            </ul>
            <p className="mb-4">
              Dane będą przetwarzane do czasu wyrażenia sprzeciwu wobec ich przetwarzania.
            </p>

            <h3 className="text-xl font-bold text-navy-800 mb-3">C. Obowiązki prawne</h3>
            <p className="mb-4">
              W określonych przypadkach dane mogą być przetwarzane w celu wypełnienia obowiązków prawnych, np. dotyczących księgowości i podatków (art. 6 ust. 1 lit. c RODO).
            </p>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <Cookie className="w-4 h-4 text-navy-600" />
              </span>
              📌 Pliki cookies 🍪
            </h2>
            
            <p className="mb-4">
              Cookies to małe pliki tekstowe zapisywane na Twoim urządzeniu, które pomagają w działaniu Serwisu.
            </p>

            <h3 className="text-xl font-bold text-navy-800 mb-3">📌 Rodzaje wykorzystywanych plików cookies:</h3>
            <ul className="list-none pl-5 space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">🔹</span>
                <span><strong>Niezbędne (techniczne)</strong> – umożliwiają prawidłowe działanie Serwisu.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">🔹</span>
                <span><strong>Funkcjonalne</strong> – zapamiętują Twoje preferencje i ustawienia.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">🔹</span>
                <span><strong>Analityczne</strong> – pozwalają analizować ruch na stronie i optymalizować jej działanie.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">🔹</span>
                <span><strong>Marketingowe</strong> – umożliwiają wyświetlanie dopasowanych reklam.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">🔹</span>
                <span><strong>Cookies portali społecznościowych</strong> – umożliwiają integrację z mediami społecznościowymi.</span>
              </li>
            </ul>

            <h3 className="text-xl font-bold text-navy-800 mb-3">📌 Czas przechowywania plików cookies:</h3>
            <ul className="list-none pl-5 space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">📌</span>
                <span><strong>Sesyjne</strong> – usuwane po zamknięciu przeglądarki.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">📌</span>
                <span><strong>Stałe</strong> – przechowywane na urządzeniu użytkownika przez określony czas lub do momentu ich usunięcia.</span>
              </li>
            </ul>

            <div className="my-8 border-t border-navy-200"></div>

            <h2 className="text-2xl font-bold text-navy-800 mb-6 flex items-center">
              <span className="w-8 h-8 bg-navy-100/40 rounded-full flex items-center justify-center mr-3">
                <UserCheck className="w-4 h-4 text-navy-600" />
              </span>
              📌 Twoje prawa
            </h2>
            
            <ul className="list-none pl-5 space-y-2 mb-6">
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo dostępu do przetwarzanych danych osobowych.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do sprostowania nieprawidłowych danych.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do usunięcia danych („prawo do bycia zapomnianym").</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do ograniczenia przetwarzania.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do przenoszenia danych.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do cofnięcia zgody na przetwarzanie.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do sprzeciwu wobec przetwarzania danych.</span>
              </li>
              <li className="flex items-start">
                <span className="text-accent-600 mr-2">✅</span>
                <span>Prawo do wniesienia skargi do organu nadzorczego (Prezes Urzędu Ochrony Danych Osobowych).</span>
              </li>
            </ul>
            <p className="mb-4">
              Jeśli chcesz skorzystać ze swoich praw, napisz do nas na: <a href="mailto:kontakt@tirjob.pl" className="text-accent-600 hover:text-accent-700">kontakt@tirjob.pl</a>
            </p>

            <div className="my-8 border-t border-navy-200"></div>

            <p className="mb-4">
              <span className="text-accent-600 mr-2">📢</span>
              Zastrzegamy sobie prawo do aktualizacji niniejszej polityki prywatności, aby dostosować ją do zmian prawnych lub technologicznych.
            </p>

            <p className="text-center font-medium text-navy-700 mt-8">
              📌 Więcej informacji? Skontaktuj się z nami!
            </p>
          </div>
        </div>

        <div className="bg-navy-800 rounded-2xl shadow-lg p-8 text-white mb-10 animate-on-scroll delay-1">
          <h2 className="text-2xl font-bold mb-6">Potrzebujesz wyjaśnień dotyczących prywatności?</h2>
          <p className="text-navy-200 mb-6">Jeśli masz jakiekolwiek pytania odnośnie przetwarzania Twoich danych, skontaktuj się z nami:</p>
          
          <div className="flex flex-col sm:flex-row gap-4 text-navy-100">
            <a href="mailto:kontakt@tirjob.pl" className="flex items-center group">
              <div className="w-10 h-10 bg-navy-700 rounded-full flex items-center justify-center mr-3 group-hover:bg-accent-600 transition-colors">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <span className="group-hover:text-white transition-colors">kontakt@tirjob.pl</span>
            </a>
            <a href="tel:+48501420042" className="flex items-center group">
              <div className="w-10 h-10 bg-navy-700 rounded-full flex items-center justify-center mr-3 group-hover:bg-accent-600 transition-colors">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <span className="group-hover:text-white transition-colors">+48 501 42 00 42</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}