import React, { useState, useCallback, useEffect, useMemo } from 'react';
import { Briefcase, Building2, Users, Truck, Clock, Globe, GraduationCap, Languages, Banknote, Award, SlidersHorizontal, X } from 'lucide-react';
import { debounce } from '../lib/utils';
import { supabase } from '../lib/supabase';

const trailerTypes = [
  'Dowolny', 'Autotransporter', 'Bus < 3,5t', 'Chłodnia', 'Cysterna', 'Hakowiec',
  'Izoterma', 'Kłonicowa', 'Kontener', 'Mega', 'Niskopodwoziowa', 'Plandeka',
  'Platforma', 'Ponadgabaryt', 'Silos', 'Tandem', 'Wywrotka'
];

const scheduleTypes = [
  'kursy 1-dniowe', 'pn-pt', 'weekendy',
  '2/1', '2/2', '3/1', '4/1', '4/2', '6/2',
  'Inny system'
];

const languages = [
  'Polski', 'Angielski', 'Niemiecki', 'Ukraiński', 'Rosyjski', 'Rumuński',
  'Litewski', 'Estoński', 'Czeski', 'Białoruski', 'Słowacki', 'Włoski',
  'Francuski', 'Hiszpański', 'Portugalski', 'Norweski', 'Szwedzki', 'Turecki'
];

const qualifications = [
  'ADR', 'Certyfikat kompetencji zawodowych', 'Dźwig (HDS)', 'Karta kierowcy',
  'Kurs na przewóz osób', 'Kurs na przewóz rzeczy', 'Oferta otwarta dla obywateli Ukrainy',
  'Umiejętność obsługi HDS', 'Wózki widłowe', 'Znajomość procedur celnych',
  'Znajomość tachografu'
];

const positions = {
  drivers: [
    'kat. B', 'kat. B+E', 'kat. C', 'kat. C+E', 'kat. D', 'kat. D+E',
    'Kierowca ADR', 'Kierowca transportu chłodniczego',
    'Kierowca transportu kontenerowego', 'Kierowca transportu specjalistycznego',
    'Kierowca transportu międzynarodowego', 'Kierowca transportu krajowego',
    'Kierowca autobusu'
  ],
  logistics: [
    'Spedytor', 'Spedytor międzynarodowy', 'Spedytor krajowy',
    'Dyspozytor', 'Planista transportu', 'Handlowiec w branży transportowej',
    'Opiekun floty', 'Referent ds. finansowo-księgowych'
  ],
  construction: [
    'Operator wózka widłowego', 'Operator maszyn budowlanych',
    'Magazynier', 'Inne stanowisko związane z transportem'
  ]
};

const driverLicenseCategories = [
  { id: 'kat. B', label: 'kat. B' },
  { id: 'kat. B+E', label: 'kat. B+E' },
  { id: 'kat. C', label: 'kat. C' },
  { id: 'kat. C+E', label: 'kat. C+E' },
  { id: 'kat. D', label: 'kat. D' },
  { id: 'kat. D+E', label: 'kat. D+E' }
];

export interface SearchFilters {
  country_id: string;
  position: {
    category: string;
    type: string;
  };
  workType: string;
  salary: {
    type: string;
    amount: string;
    currency: string;
  };
  companyType: string;
  crewType: string;
  trailerType: string;
  schedule: string;
  selectedRoute: string;
  experience: string;
  language: string;
  qualifications: string[];
  driverLicenses: string[];
  selectedTrailerTypes: string[];
}

interface JobSearchProps {
  onSearch: (filters: SearchFilters) => void;
}

export default function JobSearch({ onSearch }: JobSearchProps) {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    country_id: '',
    position: {
      category: '',
      type: ''
    },
    workType: '',
    salary: {
      type: '',
      amount: '',
      currency: ''
    },
    companyType: '',
    crewType: '',
    trailerType: '',
    schedule: '',
    selectedRoute: '',
    experience: '',
    language: '',
    qualifications: [],
    driverLicenses: [],
    selectedTrailerTypes: []
  });

  const [countries, setCountries] = useState<Array<{ id: string; country_name: string }>>([]);

  // Fetch all countries from job_countries table
  useEffect(() => {
    const fetchCountries = async () => {
      const { data, error } = await supabase
        .from('job_countries')
        .select('id, country_name')
        .order('country_name');

      if (error) {
        console.error('Error fetching countries:', error);
        return;
      }

      setCountries(data || []);
    };

    fetchCountries();
  }, []);

  // Debounce the search callback
  const debouncedSearch = useCallback(
    debounce((filters: SearchFilters) => {
      onSearch(filters);
    }, 300),
    [onSearch]
  );

  // Update filters and trigger search
  const updateFilters = (newFilters: Partial<SearchFilters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    debouncedSearch(updatedFilters);
  };

  // Toggle a driver's license selection
  const toggleDriverLicense = (license: string) => {
    const newDriverLicenses = filters.driverLicenses.includes(license)
      ? filters.driverLicenses.filter(l => l !== license)
      : [...filters.driverLicenses, license];
    
    updateFilters({ driverLicenses: newDriverLicenses });
  };

  // Toggle a trailer type selection
  const toggleTrailerType = (type: string) => {
    const newTrailerTypes = filters.selectedTrailerTypes.includes(type)
      ? filters.selectedTrailerTypes.filter(t => t !== type)
      : [...filters.selectedTrailerTypes, type];
    
    updateFilters({ selectedTrailerTypes: newTrailerTypes });
  };

  // Toggle qualification selection
  const toggleQualification = (qualification: string) => {
    const newQualifications = filters.qualifications.includes(qualification)
      ? filters.qualifications.filter(q => q !== qualification)
      : [...filters.qualifications, qualification];
    
    updateFilters({ qualifications: newQualifications });
  };

  return (
    <>
      {/* Mobile filter toggle button */}
      <div className="lg:hidden fixed bottom-4 right-4 z-50">
        <button
          onClick={() => setIsFilterOpen(true)}
          className="bg-accent-600 text-white p-4 rounded-full shadow-lg hover:bg-accent-700 transition-colors"
        >
          <SlidersHorizontal className="w-6 h-6" />
        </button>
      </div>

      {/* Mobile filter sidebar */}
      <div className={`
        fixed inset-0 z-50 lg:hidden transform transition-transform duration-300
        ${isFilterOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        {/* Overlay */}
        <div 
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          onClick={() => setIsFilterOpen(false)}
        ></div>

        {/* Sidebar content */}
        <div className="absolute right-0 top-0 h-full w-full max-w-sm bg-white shadow-xl overflow-y-auto">
          <div className="sticky top-0 bg-white z-10 p-4 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-navy-900">Filtry wyszukiwania</h2>
            <button
              onClick={() => setIsFilterOpen(false)}
              className="p-2 text-gray-500 hover:text-gray-700"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <div className="p-4">
            {/* Filter content */}
            <FilterContent
              filters={filters}
              updateFilters={updateFilters}
              toggleDriverLicense={toggleDriverLicense}
              toggleTrailerType={toggleTrailerType}
              toggleQualification={toggleQualification}
              countries={countries}
            />
          </div>
        </div>
      </div>

      {/* Desktop filters */}
      <div className="hidden lg:block w-full bg-white rounded-lg p-6">
        <FilterContent
          filters={filters}
          updateFilters={updateFilters}
          toggleDriverLicense={toggleDriverLicense}
          toggleTrailerType={toggleTrailerType}
          toggleQualification={toggleQualification}
          countries={countries}
        />
      </div>
    </>
  );
}

interface FilterContentProps {
  filters: SearchFilters;
  updateFilters: (newFilters: Partial<SearchFilters>) => void;
  toggleDriverLicense: (license: string) => void;
  toggleTrailerType: (type: string) => void;
  toggleQualification: (qualification: string) => void;
  countries: Array<{ id: string; country_name: string }>;
}

function FilterContent({
  filters,
  updateFilters,
  toggleDriverLicense,
  toggleTrailerType,
  toggleQualification,
  countries
}: FilterContentProps) {
  return (
    <div className="space-y-6">
      {/* Category Tabs */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-gray-800">
          🔎 Wyszukiwarka ofert
        </h2>
      </div>

      {/* Country Selection */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Globe className="w-4 h-4 mr-2 text-gray-500" />
          Lokalizacja
        </h3>
        <select
          className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          value={filters.country_id}
          onChange={(e) => updateFilters({ country_id: e.target.value })}
        >
          <option value="">Wszystkie kraje</option>
          {countries.map(country => (
            <option key={country.id} value={country.id}>
              {country.country_name}
            </option>
          ))}
        </select>
      </div>

      {/* Driver's License Categories */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <GraduationCap className="w-4 h-4 mr-2 text-gray-500" />
          Prawo jazdy
        </h3>
        <div className="flex flex-wrap gap-2">
          {driverLicenseCategories.map((category) => (
            <label
              key={category.id}
              className={`inline-flex items-center ${
                filters.driverLicenses.includes(category.id) 
                  ? 'bg-blue-50 border-blue-200 text-blue-700' 
                  : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-100'
              } px-4 py-2 rounded-full cursor-pointer transition-colors border`}
            >
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                checked={filters.driverLicenses.includes(category.id)}
                onChange={() => toggleDriverLicense(category.id)}
              />
              <span className="ml-2 text-sm">{category.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Position Selection */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Briefcase className="w-4 h-4 mr-2 text-gray-500" />
          Stanowisko
        </h3>
        <div className="grid grid-cols-1 gap-3">
          <select
            className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            value={filters.position.category}
            onChange={(e) => updateFilters({
              position: { ...filters.position, category: e.target.value, type: '' }
            })}
          >
            <option value="">Wybierz kategorię</option>
            <option value="drivers">Kierowcy</option>
            <option value="logistics">Spedycja i logistyka</option>
            <option value="construction">Budownictwo i magazyny</option>
          </select>

          {filters.position.category && (
            <select
              className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.position.type}
              onChange={(e) => updateFilters({
                position: { ...filters.position, type: e.target.value }
              })}
            >
              <option value="">Wybierz stanowisko</option>
              {positions[filters.position.category as keyof typeof positions].map(pos => (
                <option key={pos} value={pos}>{pos}</option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Work Type */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Globe className="w-4 h-4 mr-2 text-gray-500" />
          Rodzaj pracy
        </h3>
        <div className="flex gap-2">
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${
              filters.workType === 'domestic' 
                ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
            }`}
            onClick={() => updateFilters({ workType: filters.workType === 'domestic' ? '' : 'domestic' })}
          >
            Krajowy
          </button>
          <button 
            className={`px-6 py-2 rounded-full text-sm transition-colors ${
              filters.workType === 'international' 
                ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
            }`}
            onClick={() => updateFilters({ workType: filters.workType === 'international' ? '' : 'international' })}
          >
            Międzynarodowy
          </button>
        </div>
      </div>

      {/* Salary */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Banknote className="w-4 h-4 mr-2 text-gray-500" />
          Wynagrodzenie
        </h3>
        <div className="grid grid-cols-2 gap-2">
          <select
            className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            value={filters.salary.type}
            onChange={(e) => updateFilters({
              salary: { ...filters.salary, type: e.target.value }
            })}
          >
            <option value="">Wybierz rodzaj</option>
            <option value="netto">Kwota netto</option>
            <option value="brutto">Kwota brutto</option>
            <option value="km">Stawka za kilometr</option>
            <option value="hour">Stawka godzinowa</option>
            <option value="month">Pensja miesięczna</option>
            <option value="day">Dzienna dieta</option>
          </select>
          <div className="flex">
            <input
              type="text"
              placeholder="Minimalna stawka"
              className="w-full pl-3 pr-3 py-2.5 border border-gray-200 rounded-l-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.salary.amount}
              onChange={(e) => updateFilters({
                salary: { ...filters.salary, amount: e.target.value }
              })}
            />
            <select
              className="w-20 pl-2 pr-8 py-2.5 border-y border-r border-gray-200 rounded-r-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              value={filters.salary.currency}
              onChange={(e) => updateFilters({
                salary: { ...filters.salary, currency: e.target.value }
              })}
            >
              <option value="">-</option>
              <option value="PLN">PLN</option>
              <option value="EUR">EUR</option>
              <option value="GBP">GBP</option>
              <option value="USD">USD</option>
            </select>
          </div>
        </div>
      </div>

      {/* Trailer Type */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Truck className="w-4 h-4 mr-2 text-gray-500" />
          Rodzaj naczepy
        </h3>
        <div className="flex flex-wrap gap-2">
          {trailerTypes.map((type) => (
            <label
              key={type}
              className={`inline-flex items-center ${
                filters.selectedTrailerTypes.includes(type) 
                  ? 'bg-blue-50 border-blue-200 text-blue-700' 
                  : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-100'
              } px-4 py-2 rounded-full cursor-pointer transition-colors border`}
            >
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                checked={filters.selectedTrailerTypes.includes(type)}
                onChange={() => toggleTrailerType(type)}
              />
              <span className="ml-2 text-sm text-gray-700">{type}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Work Schedule */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center"> 
          <Clock className="w-4 h-4 mr-2 text-gray-500" />
          Tryb pracy
        </h3>
        <select
          className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          value={filters.schedule}
          onChange={(e) => updateFilters({ schedule: e.target.value })}
        >
          <option value="">Wybierz system pracy</option>
          {scheduleTypes.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      {/* Experience */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Award className="w-4 h-4 mr-2 text-gray-500" />
          Doświadczenie
        </h3>
        <select
          className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          value={filters.experience}
          onChange={(e) => updateFilters({ experience: e.target.value })}
        >
          <option value="">Wybierz doświadczenie</option>
          <option value="none">Brak doświadczenia</option>
          <option value="6m">Do 6 miesięcy</option>
          <option value="2y">Do 2 lat</option>
          <option value="5y">2-5 lat</option>
          <option value="5y+">Powyżej 5 lat</option>
        </select>
      </div>

      {/* Languages */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Languages className="w-4 h-4 mr-2 text-gray-500" />
          Języki wymagane
        </h3>
        <select
          className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-full text-sm focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          value={filters.language}
          onChange={(e) => updateFilters({ language: e.target.value })}
        >
          <option value="">Wybierz język</option>
          {languages.map(lang => (
            <option key={lang} value={lang.toLowerCase()}>{lang}</option>
          ))}
        </select>
      </div>

      {/* Additional Qualifications */}
      <div className="mb-6">
        <h3 className="text-gray-700 font-medium mb-3 flex items-center">
          <Award className="w-4 h-4 mr-2 text-gray-500" />
          Dodatkowe kwalifikacje
        </h3>
        <div className="flex flex-wrap gap-2">
          {qualifications.map((qual) => (
            <label
              key={qual}
              className={`inline-flex items-center ${
                filters.qualifications.includes(qual) 
                  ? 'bg-blue-50 border-blue-200 text-blue-700' 
                  : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-100'
              } px-4 py-2 rounded-full cursor-pointer transition-colors border`}
            >
              <input
                type="checkbox"
                className="form-checkbox h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                checked={filters.qualifications.includes(qual)}
                onChange={() => toggleQualification(qual)}
              />
              <span className="ml-2 text-sm text-gray-700">{qual}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}