import React, { useEffect, useState } from 'react';
import { Building2, MapPin, Banknote, Clock, Truck, Calendar, Globe, Award, Languages, Gift, Mail, Phone, Sparkles } from 'lucide-react';
import { useLocation, useParams } from 'react-router-dom';
import ApplicationForm from './ApplicationForm'; 
import SimilarJobs from './SimilarJobs'; 
import { formatExperience, formatSalaryType } from '../../lib/utils';
import { supabase } from '../../lib/supabase';
import type { JobListing as JobListingType } from '../../lib/jobs';
import { recordJobView } from '../../lib/analytics';
import { Helmet } from 'react-helmet';

interface JobListingProps {
  id: string;
}

export default function JobListing({ id }: JobListingProps) {
  const [jobData, setJobData] = useState<JobListingType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const location = useLocation();
  const params = useParams();
  
  // Record job view
  useEffect(() => {
    if (jobData && !isLoading) {
      recordJobView(id);
    }
  }, [id, jobData, isLoading]);

  useEffect(() => {
    async function fetchJobData() {
      try {
        // Validate UUID format
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (!uuidRegex.test(id)) {
          setError('Nieprawidłowy identyfikator ogłoszenia');
          setIsLoading(false);
          return;
        }

        const { data: jobPosts, error: jobError } = await supabase
          .from('job_posts')
          .select(`
            *,
            company:companies(name, email, phone),
            requirements:job_requirements(*),
            languages:job_languages(*),
            qualifications:job_qualifications(*),
            duties:job_duties(*),
            benefits:job_benefits(*)
          `)
          .eq('id', id)
          .eq('status', 'active')
          .gt('expires_at', new Date().toISOString())
          .single();

        if (jobError) throw jobError;
        if (!jobPosts) throw new Error('Nie znaleziono ogłoszenia');

        setJobData(jobPosts as JobListingType);
      } catch (error) {
        console.error('Error fetching job data:', error);
        setError('Nie udało się załadować ogłoszenia. Spróbuj ponownie później.');
      } finally {
        setIsLoading(false);
      }
    }

    fetchJobData();
  }, [id]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mx-auto"></div>
          <p className="text-center mt-4 text-gray-600">Ładowanie ogłoszenia...</p>
        </div>
      </div>
    );
  }

  if (error || !jobData) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-red-600">{error || 'Nie znaleziono ogłoszenia'}</p>
          </div>
        </div>
      </div>
    );
  }

  // Generate dynamic SEO metadata directly from job data
  const generateSeoMetadata = () => {
    if (!jobData) return null;
    
    // Generate title
    const title = `${jobData.title} - ${jobData.company.name} | Oferta pracy | TirJob.pl`;
    
    // Generate description
    let description = `Oferta pracy: ${jobData.title} w firmie ${jobData.company.name}. `;
    description += `Lokalizacja: ${jobData.city}, ${jobData.country}. `;
    description += `Wynagrodzenie: ${jobData.salary_amount} ${jobData.salary_currency} (${formatSalaryType(jobData.salary_type)}). `;
    
    // Add experience if available
    if (jobData.requirements && jobData.requirements.length > 0) {
      description += `Wymagane doświadczenie: ${formatExperience(jobData.requirements[0].experience)}. `;
    }
    
    // Add languages if available (max 2)
    if (jobData.languages && jobData.languages.length > 0) {
      const languagesList = jobData.languages.slice(0, 2).map(l => l.language).join(', ');
      description += `Języki: ${languagesList}. `;
    }
    
    description += 'Sprawdź szczegóły i aplikuj teraz!';
    
    // Generate keywords
    let keywords = `praca kierowca, oferta pracy, ${jobData.position_type}, `;
    keywords += `${jobData.work_type === 'domestic' ? 'transport krajowy' : 'transport międzynarodowy'}, `;
    keywords += `${jobData.city}, ${jobData.country}, `;
    
    // Add trailer type if available
    if (jobData.trailer_type) {
      keywords += `${jobData.trailer_type}, `;
    }
    
    // Add qualifications if available (max 3)
    if (jobData.qualifications && jobData.qualifications.length > 0) {
      const qualsList = jobData.qualifications.slice(0, 3).map(q => q.qualification).join(', ');
      keywords += `${qualsList}, `;
    }
    
    keywords += `praca ${jobData.company.name}`;
    
    // Generate Schema.org JSON-LD
    const schemaData = {
      "@context": "https://schema.org",
      "@type": "JobPosting",
      "title": jobData.title,
      "description": description,
      "datePosted": new Date(jobData.created_at).toISOString(),
      "validThrough": new Date(jobData.expires_at).toISOString(),
      "employmentType": "FULL_TIME",
      "hiringOrganization": {
        "@type": "Organization",
        "name": jobData.company.name,
        "sameAs": "https://tirjob.pl"
      },
      "jobLocation": {
        "@type": "Place",
        "address": {
          "@type": "PostalAddress",
          "addressLocality": jobData.city,
          "addressCountry": jobData.country
        }
      },
      "baseSalary": {
        "@type": "MonetaryAmount",
        "currency": jobData.salary_currency,
        "value": {
          "@type": "QuantitativeValue",
          "value": jobData.salary_amount,
          "unitText": formatSalaryType(jobData.salary_type)
        }
      },
      "skills": jobData.qualifications?.map(q => q.qualification).join(', ') || '',
      "jobBenefits": jobData.benefits?.map(b => b.benefit).join(', ') || '',
      "responsibilities": jobData.duties?.map(d => d.duty).join(', ') || '',
      "qualifications": jobData.languages?.map(l => l.language).join(', ') || '',
      "experienceRequirements": {
        "@type": "OccupationalExperienceRequirements",
        "monthsOfExperience": jobData.requirements && jobData.requirements.length > 0 ? 
          (jobData.requirements[0].experience === 'none' ? 0 : 
           jobData.requirements[0].experience === '6m' ? 6 : 
           jobData.requirements[0].experience === '2y' ? 24 : 
           jobData.requirements[0].experience === '5y' ? 60 : 72) : 0
      }
    };
    
    // Get a suitable image for the job
    const image = "https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3";
    
    return { title, description, keywords, schemaData, image };
  };

  const seoMetadata = generateSeoMetadata();

  return (
    <div>
      {seoMetadata && (
        <Helmet>
          <title>{seoMetadata.title}</title>
          <meta name="description" content={seoMetadata.description} />
          <meta name="keywords" content={seoMetadata.keywords} />
          <meta name="robots" content="index, follow" />
          
          {/* OpenGraph Tags */}
          <meta property="og:title" content={seoMetadata.title} />
          <meta property="og:description" content={seoMetadata.description} />
          <meta property="og:image" content={seoMetadata.image} />
          <meta property="og:type" content="website" />
          <meta property="og:url" content={`https://tirjob.pl${location.pathname}`} />
          <meta property="og:site_name" content="TirJob.pl" />
          <meta property="og:locale" content="pl_PL" />
          
          {/* Twitter Tags */}
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content={seoMetadata.title} />
          <meta name="twitter:description" content={seoMetadata.description} />
          <meta name="twitter:image" content={seoMetadata.image} />
          
          {/* Canonical URL */}
          <link rel="canonical" href={`https://tirjob.pl${location.pathname}`} />
          
          {/* Schema.org JSON-LD */}
          <script type="application/ld+json">
            {JSON.stringify(seoMetadata.schemaData)}
          </script>
        </Helmet>
      )}
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Job Header */}
              <div className={`relative bg-white rounded-xl shadow-lg p-6 ${
                jobData.is_premium ? 'border-2 border-accent-200' : ''
              }`}>
                {jobData.is_premium && (
                  <div className="absolute -top-3 left-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-accent-500 text-white shadow-sm">
                      <Sparkles className="w-4 h-4 mr-1" />
                      Ogłoszenie Premium
                    </span>
                  </div>
                )}
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className={`text-2xl font-bold mb-2 ${
                      jobData.is_premium ? 'text-accent-700' : 'text-navy-900'
                    }`}>
                      {jobData.title}
                    </h1>
                    <div className="flex items-center text-gray-600 mb-4">
                      <Building2 className="w-5 h-5 mr-2 text-gray-500" />
                      <span className="font-medium">{jobData.company.name}</span>
                    </div>
                  </div>
                  <span className="text-sm text-gray-500">
                    Opublikowano: {new Date(jobData.created_at).toLocaleDateString('pl-PL')}
                  </span>
                </div>

                {/* Key Details Grid */}
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center text-gray-700">
                    <MapPin className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.city}, {jobData.country}</div>
                      {jobData.voivodeship && <div className="text-sm text-gray-500">Województwo: {jobData.voivodeship}</div>}
                    </div>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Banknote className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.salary_amount} {jobData.salary_currency}</div>
                      <div className="text-sm text-gray-500">{formatSalaryType(jobData.salary_type)}</div>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Calendar className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.work_type === 'domestic' ? 'Transport krajowy' : 'Transport międzynarodowy'}</div>
                      <div className="text-sm text-gray-500">Stała współpraca</div>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Clock className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.schedule}</div>
                      <div className="text-sm text-gray-500">Weekendy w domu</div>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Truck className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.trailer_type}</div>
                      <div className="text-sm text-gray-500">Transport międzynarodowy</div>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-700">
                    <Globe className="w-5 h-5 mr-2 text-gray-500" />
                    <div>
                      <div>{jobData.work_type === 'domestic' ? 'Polska' : 'Europa'}</div>
                      <div className="text-sm text-gray-500">{jobData.work_type === 'domestic' ? 'Transport krajowy' : 'Transport międzynarodowy'}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Job Description */}
              <div className={`space-y-8 ${
                jobData.is_premium ? 'bg-gradient-to-br from-accent-50/50 to-white rounded-xl p-6 border border-accent-100' : ''
              }`}>
                {/* Requirements */}
                <div className={`bg-white rounded-xl shadow-sm p-6 ${
                  jobData.is_premium ? 'border border-accent-200' : ''
                }`}>
                  <h2 className="text-lg font-semibold text-navy-900 flex items-center mb-4">
                    <Award className="w-5 h-5 mr-2 text-gray-500" />
                    Wymagania
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Doświadczenie</h3>
                      <p className="text-gray-600">{formatExperience(jobData.requirements[0]?.experience)}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Języki</h3>
                      <div className="flex flex-wrap gap-2">
                        {jobData.languages.map((lang, index) => (
                          <span
                            key={index}
                            className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-navy-50 text-navy-700"
                          >
                            <Languages className="w-4 h-4 mr-1" />
                            {lang.language}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">Kwalifikacje</h3>
                      <ul className="list-disc list-inside space-y-1 text-gray-600">
                        {jobData.qualifications.map((qual, index) => (
                          <li key={index}>{qual.qualification}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Duties */}
                <div className={`bg-white rounded-xl shadow-sm p-6 ${
                  jobData.is_premium ? 'border border-accent-200' : ''
                }`}>
                  <h2 className="text-lg font-semibold text-navy-900 flex items-center mb-4">
                    <Truck className="w-5 h-5 mr-2 text-gray-500" />
                    Zakres obowiązków
                  </h2>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {jobData.duties.map((duty, index) => (
                      <li key={index}>{duty.duty}</li>
                    ))}
                  </ul>
                </div>

                {/* Benefits */}
                <div className={`bg-white rounded-xl shadow-sm p-6 ${
                  jobData.is_premium ? 'border border-accent-200' : ''
                }`}>
                  <h2 className="text-lg font-semibold text-navy-900 flex items-center mb-4">
                    <Gift className="w-5 h-5 mr-2 text-gray-500" />
                    Oferujemy
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {jobData.benefits.map((benefit, index) => (
                      <div
                        key={index}
                        className="flex items-start"
                      >
                        <span className="w-2 h-2 mt-2 rounded-full bg-accent-500 mr-2" />
                        <span className="text-gray-600">{benefit.benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Contact */}
                <div className={`bg-white rounded-xl shadow-sm p-6 ${
                  jobData.is_premium ? 'border border-accent-200' : ''
                }`}>
                  <h2 className="text-lg font-semibold text-navy-900 flex items-center mb-4">
                    <Building2 className="w-5 h-5 mr-2 text-gray-500" />
                    Kontakt
                  </h2>
                  <div className="space-y-4">
                    <div>
                      <p className="font-medium text-gray-900">{jobData.company.name}</p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <a
                        href={`mailto:${jobData.company.email}`}
                        className="inline-flex items-center text-navy-600 hover:text-navy-800"
                      >
                        <Mail className="w-5 h-5 mr-2" />
                        {jobData.company.email}
                      </a>
                      <a
                        href={`tel:${jobData.company.phone}`}
                        className="inline-flex items-center text-navy-600 hover:text-navy-800"
                      >
                        <Phone className="w-5 h-5 mr-2" />
                        {jobData.company.phone}
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <ApplicationForm 
                  jobId={jobData.id} 
                  jobTitle={jobData.title}
                  companyEmail={jobData.company.email}
                />
              </div>
            </div>
          </div>

          {/* Similar Jobs */}
          <div className="mt-12">
            <SimilarJobs currentJobId={id} />
          </div>
        </div>
      </div>
    </div>
  );
}