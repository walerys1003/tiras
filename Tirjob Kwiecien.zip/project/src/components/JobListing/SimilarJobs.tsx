import React from 'react';
import { Building2, MapPin, Banknote } from 'lucide-react';
import { formatSalaryType } from '../../lib/utils';

interface SimilarJobsProps {
  currentJobId: string;
}

// Sample similar jobs data - in production this would come from an API
const similarJobs = [
  {
    id: '2',
    title: 'Kierowca C+E – transport międzynarodowy',
    company: 'ABC Logistics',
    location: 'Berlin, Niemcy',
    salary: '4000-4500 EUR',
    salaryType: 'month',
    publishedAt: '2025-02-19'
  },
  {
    id: '3',
    title: 'Kierowca kat. B – dostawy lokalne',
    company: 'FastDelivery Sp. z o.o.',
    location: 'Warszawa, Polska',
    salary: '5000-6000 PLN',
    salaryType: 'brutto',
    publishedAt: '2025-02-18'
  },
  {
    id: '4',
    title: 'Spedytor międzynarodowy',
    company: 'Global Transport Solutions',
    location: 'Praca zdalna',
    salary: '7000-9000 PLN',
    salaryType: 'netto',
    publishedAt: '2025-02-17'
  }
];

export default function SimilarJobs({ currentJobId }: SimilarJobsProps) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-navy-900 mb-6">
        Podobne oferty pracy
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {similarJobs.map(job => (
          <a
            key={job.id}
            href={`/oferty-pracy/${job.id}`}
            className="block bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-navy-900 hover:text-accent-600 transition-colors">
                    {job.title}
                  </h3>
                  <div className="flex items-center text-gray-600 mt-1">
                    <Building2 className="w-4 h-4 mr-2" />
                    <span>{job.company}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center text-gray-700">
                  <MapPin className="w-4 h-4 mr-2 text-gray-500" />
                  {job.location}
                </div>
                <div className="flex items-center text-gray-700">
                  <Banknote className="w-4 h-4 mr-2 text-gray-500" />
                  {job.salary} ({formatSalaryType(job.salaryType)})
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100 text-sm text-gray-500">
                Opublikowano: {job.publishedAt}
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}