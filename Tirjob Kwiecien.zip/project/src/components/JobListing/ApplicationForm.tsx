import React, { useState } from 'react';
import { Upload, Send } from 'lucide-react';
import { z } from 'zod';
import { supabase } from '../../lib/supabase';
import { applicationFormSchema } from '../../lib/validations/application';
import { sendApplicationEmails } from '../../lib/email';

interface ApplicationFormProps {
  jobId: string;
  jobTitle: string;
  companyEmail: string;
}

type FormErrors = {
  [K in keyof z.infer<typeof applicationFormSchema>]?: string[];
};

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB in bytes
const ALLOWED_FILE_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

export default function ApplicationForm({ jobId, jobTitle, companyEmail }: ApplicationFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: 'Dzień dobry,\n\nChciałbym/Chciałabym aplikować na to stanowisko.\n\nPozdrawiam',
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileError, setFileError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string>('');
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  const validateFile = (file: File): boolean => {
    setFileError('');

    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      setFileError('Dozwolone formaty plików: PDF, DOC, DOCX');
      return false;
    }

    if (file.size > MAX_FILE_SIZE) {
      setFileError('Maksymalny rozmiar pliku to 5MB');
      return false;
    }

    return true;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (validateFile(file)) {
        setSelectedFile(file);
      } else {
        e.target.value = '';
        setSelectedFile(null);
      }
    }
  };

  const validateField = (field: keyof z.infer<typeof applicationFormSchema>, value: any) => {
    try {
      applicationFormSchema.pick({ [field]: true }).parse({ [field]: value });
      setErrors(prev => ({ ...prev, [field]: undefined }));
      return true;
    } catch (error) {
      if (error instanceof z.ZodError) {
        setErrors(prev => ({
          ...prev,
          [field]: error.errors.map(e => e.message)
        }));
        return false;
      }
    }
    return false;
  };

  const handleInputChange = (
    field: keyof z.infer<typeof applicationFormSchema>,
    value: string
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Validate on change but with a slight delay to avoid interrupting typing
    setTimeout(() => validateField(field, value), 300);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSubmitting) return;
    
    setSubmitError('');
    setSubmitSuccess(false);
    setIsSubmitting(true);
    
    // Validate all fields before submission
    const validationResult = applicationFormSchema.safeParse({
      ...formData,
      cv: selectedFile
    });

    if (!validationResult.success) {
      const newErrors: FormErrors = {};
      validationResult.error.errors.forEach(error => {
        if (error.path[0]) {
          newErrors[error.path[0] as keyof FormErrors] = [error.message];
        }
      });
      setErrors(newErrors);
      setIsSubmitting(false);
      setSubmitError('Proszę poprawić błędy w formularzu przed wysłaniem.');
      return;
    }
    
    try {
      // Create job application
      const { error: applicationError } = await supabase
        .from('job_applications')
        .insert({
          job_post_id: jobId,
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          message: formData.message
        });
      
      if (applicationError) throw applicationError;

      // Send confirmation emails
      const emailsSent = await sendApplicationEmails({
        candidateName: formData.name,
        candidateEmail: formData.email,
        candidatePhone: formData.phone,
        message: formData.message,
        jobTitle: jobTitle,
        employerEmail: companyEmail,
        cvFile: selectedFile!
      });

      if (!emailsSent) {
        throw new Error('Failed to send confirmation emails');
      }
      
      // Reset form on success
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: 'Dzień dobry,\n\nChciałbym/Chciałabym aplikować na to stanowisko.\n\nPozdrawiam'
      });
      setSelectedFile(null);
      setSubmitSuccess(true);
      
    } catch (error) {
      console.error('Error submitting application:', error);
      setSubmitError('Wystąpił błąd podczas zapisywania aplikacji. Spróbuj ponownie później.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      {submitSuccess ? (
        <div className="text-center py-8 bg-green-50 rounded-lg p-6">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Aplikacja wysłana pomyślnie!</h2>
          <p className="text-gray-600 mb-6">
            Twoje zgłoszenie zostało zapisane. Pracodawca otrzyma powiadomienie o Twojej aplikacji i skontaktuje się z Tobą wkrótce.
          </p>
          <p className="text-sm text-gray-500">
            Życzymy powodzenia w procesie rekrutacji! 🚛
          </p>
        </div>
      ) : (
        <>
          <h2 className="text-lg font-semibold text-navy-900 mb-6">
            Aplikuj na to stanowisko
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Imię i nazwisko
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={e => handleInputChange('name', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                  errors.name ? 'border-red-500' : 'border-gray-300'
                }`}
                required
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-500">{errors.name[0]}</p>
              )}
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={e => handleInputChange('email', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                  errors.email ? 'border-red-500' : 'border-gray-300'
                }`}
                required
              />
              {errors.email && (
                <p className="mt-1 text-sm text-red-500">{errors.email[0]}</p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Telefon
              </label>
              <input
                type="tel"
                id="phone"
                value={formData.phone}
                onChange={e => handleInputChange('phone', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                  errors.phone ? 'border-red-500' : 'border-gray-300'
                }`}
                required
              />
              {errors.phone && (
                <p className="mt-1 text-sm text-red-500">{errors.phone[0]}</p>
              )}
            </div>

            {/* CV Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                CV
              </label>
              <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-lg hover:border-accent-500 transition-colors ${
                errors.cv ? 'border-red-500' : 'border-gray-300'
              }`}>
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex flex-col items-center text-sm text-gray-600">
                    <label
                      htmlFor="cv"
                      className="relative cursor-pointer rounded-md font-medium text-accent-600 hover:text-accent-500 focus-within:outline-none"
                    >
                      <span>{selectedFile ? selectedFile.name : 'Dodaj plik'}</span>
                      <input
                        id="cv"
                        name="cv"
                        type="file"
                        className="sr-only"
                        accept=".pdf,.doc,.docx"
                        onChange={handleFileChange}
                      />
                    </label>
                    {!selectedFile && <p className="mt-1">lub przeciągnij i upuść</p>}
                  </div>
                  <p className="text-xs text-gray-500">
                    PDF, DOC lub DOCX do 10MB
                  </p>
                  {(fileError || errors.cv) && (
                    <p className="text-sm text-red-500">{fileError || errors.cv?.[0]}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Wiadomość do rekrutera
              </label>
              <textarea
                id="message"
                rows={4}
                value={formData.message}
                onChange={e => handleInputChange('message', e.target.value)}
                className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                  errors.message ? 'border-red-500' : 'border-gray-300'
                }`}
              />
              {errors.message && (
                <p className="mt-1 text-sm text-red-500">{errors.message[0]}</p>
              )}
            </div>

            {/* RODO Checkbox */}
            <div className="mt-4">
              <div className="flex items-start">
                <div className="flex items-center h-5">
                  <input
                    id="rodo"
                    type="checkbox"
                    required
                    className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="rodo" className="text-gray-700">
                    Klikając „Wyślij aplikację", wyrażasz zgodę na przetwarzanie danych osobowych na potrzeby procesu rekrutacji zgodnie z RODO.
                  </label>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-accent-600 hover:bg-accent-700 transition-colors duration-200"
            >
              <Send className="w-5 h-5 mr-2" />
              {isSubmitting ? 'Wysyłanie...' : 'Aplikuj teraz'}
            </button>

            {submitError && (
              <p className="mt-4 text-sm text-red-500 text-center">{submitError}</p>
            )}

            <p className="text-xs text-gray-500 text-center mt-4">
              Wysyłając zgłoszenie wyrażasz zgodę na przetwarzanie Twoich danych osobowych
              na potrzeby rekrutacji.
            </p>
          </form>
        </>
      )}

    </div>
  );
}