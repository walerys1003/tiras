import React, { useEffect } from 'react';
import { Truck, Clock, Users, Search, ArrowRight, Building2, Mail, Phone, Globe, MapPin, Briefcase, Sparkles } from 'lucide-react';
import { Routes, Route, useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import JobSearch from './components/JobSearch';
import JobList from './components/JobList';
import Footer from './components/Footer';
import JobListing from './components/JobListing';
import AddJobForm from './components/AddJobForm';
import Pricing from './components/Pricing';
import PromotionServices from './components/PromotionServices';
import SingleBlogPost from './pages/SingleBlogPost';
import SocialMedia from './components/SocialMedia';
import Contact from './components/Contact';
import NewsletterSignup from './components/Newsletter';
import Terms from './components/Terms';
import Privacy from './components/Privacy';
import Login from './pages/admin/Login';
import Dashboard from './pages/admin/Dashboard';
import Jobs from './pages/admin/Jobs';
import AdminUsers from './pages/admin/Users';
import Newsletter from './pages/admin/Newsletter';
import AdminBlog from './pages/admin/Blog';
import Seo from './pages/admin/Seo';
import Settings from './pages/admin/Settings';
import Blog from './components/Blog';
import EditJob from './pages/admin/EditJob';
import EditBlogPost from './pages/admin/EditBlogPost';
import PaymentPlaceholder from './pages/PaymentPlaceholder';
import PaymentSuccess from './pages/PaymentSuccess';
import PaymentCanceled from './pages/PaymentCanceled';
import Payments from './pages/admin/Payments';
import Analytics from './pages/admin/Analytics';
import type { SearchFilters } from './components/JobSearch';
import RequireRole from './components/admin/RequireRole';
import { useSettings } from './hooks/useSettings';
import SeoHead from './components/SeoHead';

console.log('App component loaded');

// Function to generate schema.org data for homepage
const generateHomePageSchema = (settings: Record<string, string>) => {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": settings.default_title || "TirJob.pl",
    "url": "https://tirjob.pl",
    "description": settings.default_description || "Portal pracy dla kierowców i specjalistów transportu",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://tirjob.pl/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "publisher": {
      "@type": "Organization",
      "name": "TirJob.pl",
      "logo": {
        "@type": "ImageObject",
        "url": settings.logo_url || "https://i.ibb.co/7NdqLD2G/2.png",
        "width": "600",
        "height": "60"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": settings.contact_phone || "+48 501 42 00 42",
        "contactType": "customer service",
        "email": settings.contact_email || "kontakt@tirjob.pl"
      }
    }
  };
};

function App() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [searchFilters, setSearchFilters] = React.useState<SearchFilters | undefined>();
  const location = useLocation();
  const [isReady, setIsReady] = React.useState(false);
  const { settings } = useSettings();

  console.log('App rendering, pathname:', location.pathname);

  // Redirect /admin to /admin/dashboard
  useEffect(() => {
    if (location.pathname === '/admin') {
      console.log('Redirecting from /admin to /admin/dashboard');
      navigate('/admin/dashboard');
    }
  }, [location.pathname, navigate]);

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  useEffect(() => {
    // Mark the app as ready after initial render
    console.log('Setting app as ready');
    setIsReady(true);
  }, []);

  // Function to navigate and scroll to top
  const navigateAndScrollToTop = (path: string, e: React.MouseEvent) => {
    e.preventDefault();
    navigate(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isReady) {
    console.log('App not ready yet, showing loading screen');
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
    
    // Reset to page 1 when search filters change
    const newSearchParams = new URLSearchParams(searchParams);
    newSearchParams.set('page', '1');
    window.history.pushState({}, '', `?${newSearchParams.toString()}`);
  };

  // Don't show navigation for admin routes
  if (location.pathname.startsWith('/admin')) {
    console.log('Rendering admin routes');
    return (
      <>
        <Routes>
          <Route path="/admin/login" element={<Login />} />
          <Route path="/admin/dashboard" element={
            <RequireRole allowedRoles={['admin', 'redaktor', 'moderator']}>
              <Dashboard />
            </RequireRole>
          } />
          <Route path="/admin/jobs" element={
            <RequireRole 
              allowedRoles={['admin', 'moderator']}
              redirectTo={'/admin/blog'}
            >
              <Jobs />
            </RequireRole>
          } />
          <Route path="/admin/jobs/new" element={
            <RequireRole 
              allowedRoles={['admin', 'moderator']}
              redirectTo={'/admin/blog'}
            >
              <AddJobForm admin={true} />
            </RequireRole>
          } />
          <Route path="/admin/jobs/:id/edit" element={
            <RequireRole 
              allowedRoles={['admin', 'moderator']}
              redirectTo={'/admin/blog'}
            >
              <EditJob />
            </RequireRole>
          } />
          <Route path="/admin/newsletter" element={
            <RequireRole allowedRoles={['admin']}>
              <Newsletter />
            </RequireRole>
          } />
          <Route path="/admin/blog" element={
            <RequireRole 
              allowedRoles={['admin', 'redaktor']}
              redirectTo={'/admin/jobs'}
            >
              <AdminBlog />
            </RequireRole>
          } />
          <Route path="/admin/blog/new" element={
            <RequireRole 
              allowedRoles={['admin', 'redaktor']}
              redirectTo={'/admin/jobs'}
            >
              <EditBlogPost />
            </RequireRole>
          } />
          <Route path="/admin/blog/:id/edit" element={
            <RequireRole 
              allowedRoles={['admin', 'redaktor']}
              redirectTo={'/admin/jobs'}
            >
              <EditBlogPost />
            </RequireRole>
          } />
         <Route path="/admin/seo" element={
           <RequireRole allowedRoles={['admin']}>
             <Seo />
           </RequireRole>
         } />
        <Route path="/admin/analytics" element={
          <RequireRole allowedRoles={['admin', 'moderator']}>
            <Analytics />
          </RequireRole>
        } />
        <Route path="/admin/payments" element={
          <RequireRole allowedRoles={['admin', 'moderator']}>
            <Payments />
          </RequireRole>
        } />
          <Route path="/admin/users" element={
            <RequireRole allowedRoles={['admin']}>
              <AdminUsers />
            </RequireRole>
          } />
          <Route path="/admin/settings" element={
            <RequireRole allowedRoles={['admin']}>
              <Settings />
            </RequireRole>
          } />
        </Routes>
      </>
    );
  }

  return (
    // Main app UI
    <div className="min-h-screen bg-gradient-to-b from-navy-50 to-white">
      <SeoHead 
        path={location.pathname} 
        defaultTitle={settings.default_title}
        defaultDescription={settings.default_description}
        dynamicData={location.pathname === '/' ? {
          title: settings.default_title,
          description: settings.default_description,
          keywords: settings.default_keywords,
          schemaData: generateHomePageSchema(settings)
        } : undefined}
      />
      
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-sm shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center space-x-8">
              <div 
                className="flex-shrink-0 flex items-center cursor-pointer group"
                onClick={() => {
                  navigate('/');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
              >
                <Truck className="h-8 w-8 text-accent-600 group-hover:text-accent-700 transition-colors" />
                <span className="ml-2 text-2xl font-bold text-navy-800 group-hover:text-navy-900 transition-colors">
                  TirJob.pl
                </span>
              </div>
              <div className="hidden sm:flex sm:space-x-6">
                <a 
                  href="/"
                  onClick={(e) => navigateAndScrollToTop('/', e)}
                  className="text-navy-900 inline-flex items-center px-1 pt-1 border-b-2 border-accent-500 text-sm font-medium"
                >
                  Oferty pracy
                </a>
                <a 
                  href="/cennik"
                  onClick={(e) => navigateAndScrollToTop('/cennik', e)}
                  className="text-navy-600 hover:text-navy-800 inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium transition-colors"
                >
                  Cennik
                </a>
                <a 
                  href="/uslugi-promocji"
                  onClick={(e) => navigateAndScrollToTop('/uslugi-promocji', e)}
                  className="text-navy-600 hover:text-navy-800 inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium transition-colors"
                >
                  Usługi promocji
                </a>
                <a 
                  href="/blog"
                  onClick={(e) => navigateAndScrollToTop('/blog', e)}
                  className="text-navy-600 hover:text-navy-800 inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium transition-colors"
                >
                  Blog
                </a>
                <a 
                  href="/social-media"
                  onClick={(e) => navigateAndScrollToTop('/social-media', e)}
                  className="text-navy-600 hover:text-navy-800 inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium transition-colors"
                >
                  Social Media
                </a>
                <a 
                  href="/kontakt"
                  onClick={(e) => navigateAndScrollToTop('/kontakt', e)}
                  className="text-navy-600 hover:text-navy-800 inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium transition-colors"
                >
                  Kontakt
                </a>
              </div>
            </div>
            <div className="flex items-center">
              <button 
                onClick={() => {
                  navigate('/dodaj-ogloszenie');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-accent-600 text-white px-6 py-2 rounded-full text-sm font-medium hover:bg-accent-700 shadow-sm hover:shadow transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-500"
              >
                + Dodaj ogłoszenie
              </button>
            </div>
          </div>
        </div>
      </nav>

      <Routes>
        <Route path="/dodaj-ogloszenie" element={<AddJobForm />} />
        <Route path="/oferty-pracy/:id" element={<JobListing id={window.location.pathname.split('/oferty-pracy/')[1] || ''} />} />
        <Route path="/platnosc/:id" element={<PaymentPlaceholder />} />
        <Route path="/platnosc/sukces" element={<PaymentSuccess />} />
        <Route path="/platnosc/anulowana" element={<PaymentCanceled />} />
        <Route path="/cennik" element={<Pricing />} />
        <Route path="/uslugi-promocji" element={<PromotionServices />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:id" element={<SingleBlogPost />} />
        <Route path="/social-media" element={<SocialMedia />} />
        <Route path="/kontakt" element={<Contact />} />
        <Route path="/newsletter" element={<NewsletterSignup />} />
        <Route path="/regulamin" element={<Terms />} />
        <Route path="/polityka-prywatnosci" element={<Privacy />} />
        <Route path="/" element={
          <>
            {/* Hero Section */}
            <div className="relative bg-gradient-to-br from-navy-800 to-navy-900 py-20 overflow-hidden">
              {/* Background image with overlay */}
              <div className="absolute inset-0">
                <img 
                  src="https://i.ibb.co/7NdqLD2G/2.png" 
                  alt="Transport drogowy" 
                  className="w-full h-full object-cover opacity-10"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-navy-900/80 to-navy-900/90"></div>
              </div>

              {/* Content */}
              <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                  {/* Left column - Text content */}
                  <div className="text-left space-y-8">
                    <div>
                      <span className="inline-block px-4 py-2 rounded-full bg-accent-500/20 text-accent-100 font-medium text-sm mb-4">
                        ZNAJDŹ PRACĘ W TRANSPORCIE
                      </span>
                      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                        Twoja kariera w branży TSL zaczyna się tutaj!
                      </h1>
                    </div>
                    
                    <p className="text-xl text-navy-100">
                      Codziennie nowe oferty pracy dla kierowców i specjalistów transportu. 
                      Znajdź idealną pracę dopasowaną do Twoich kwalifikacji!
                    </p>

                    {/* Quick stats */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 transform hover:scale-105 transition-transform duration-300">
                        <div className="text-3xl font-bold text-white mb-1">600+</div>
                        <div className="text-navy-200">aktualnych ofert</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 transform hover:scale-105 transition-transform duration-300">
                        <div className="text-3xl font-bold text-white mb-1">24/7</div>
                        <div className="text-navy-200">wsparcie online</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 transform hover:scale-105 transition-transform duration-300">
                        <div className="text-3xl font-bold text-white mb-1">15k+</div>
                        <div className="text-navy-200">aktywnych kierowców</div>
                      </div>
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 transform hover:scale-105 transition-transform duration-300">
                        <div className="text-3xl font-bold text-white mb-1">94%</div>
                        <div className="text-navy-200">skuteczność</div>
                      </div>
                    </div>

                    {/* Quick links */}
                    <div className="flex flex-wrap gap-4">
                      <button
                        onClick={() => {
                          const jobListElement = document.querySelector('#job-list');
                          if (jobListElement) {
                            jobListElement.scrollIntoView({ behavior: 'smooth' });
                          }
                        }}
                        className="inline-flex items-center px-6 py-3 bg-accent-600 text-white rounded-full hover:bg-accent-700 transition-colors shadow-lg"
                      >
                        <Briefcase className="w-5 h-5 mr-2" />
                        Przeglądaj oferty pracy
                      </button>
                      <button
                        onClick={() => {
                          navigate('/dodaj-ogloszenie');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="inline-flex items-center px-6 py-3 bg-white/10 backdrop-blur-sm text-white rounded-full hover:bg-white/20 transition-colors"
                      >
                        <MapPin className="w-5 h-5 mr-2" />
                        Dodaj ogłoszenie
                      </button>
                    </div>
                  </div>

                  {/* Right column - Image */}
                  <div className="hidden lg:block relative">
                    <img 
                      src="https://i.ibb.co/7NdqLD2G/2.png" 
                      alt="Ciężarówka na drodze" 
                      className="rounded-2xl shadow-2xl transform -rotate-2 hover:rotate-0 transition-transform duration-500"
                    />
                    {/* Decorative elements */}
                    <div className="absolute -top-6 -right-6 w-32 h-32 bg-accent-500/20 rounded-full blur-2xl"></div>
                    <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-navy-500/20 rounded-full blur-2xl"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24" id="job-list">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Left Column - Search Filters */}
                <div className="lg:col-span-4">
                  <JobSearch onSearch={handleSearch} />
                </div>
                
                {/* Right Column - Job Listings */}
                <div className="lg:col-span-8">
                  <JobList searchFilters={searchFilters} />
                </div>
              </div>
              
              {/* USP Section */}
              <section className="mt-16 bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-bold text-center text-navy-900 mb-8">
                  Dlaczego warto korzystać z TirJob.pl?
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-accent-100 text-accent-600 rounded-full flex items-center justify-center">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-navy-800 mb-2">Długa ekspozycja ofert</h3>
                    <p className="text-navy-600">{settings.job_post_duration || '60'} dni za jedyne {settings.job_post_price || '500'} zł</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-accent-100 text-accent-600 rounded-full flex items-center justify-center">
                      <Users className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-navy-800 mb-2">Dostęp do setek kierowców</h3>
                    <p className="text-navy-600">i specjalistów transportu</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-accent-100 text-accent-600 rounded-full flex items-center justify-center">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-navy-800 mb-2">Szybka rekrutacja</h3>
                    <p className="text-navy-600">5 minut na dodanie ogłoszenia</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-accent-100 text-accent-600 rounded-full flex items-center justify-center">
                      <Search className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-navy-800 mb-2">Precyzyjne targetowanie</h3>
                    <p className="text-navy-600">kandydatów</p>
                  </div>
                </div>
              </section>
            </main>
          </>
        } />
      </Routes>

      <Footer />
    </div>
  );
}

export default App;