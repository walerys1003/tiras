import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import BlogPost from '../components/BlogPost';
import { getBlogPost } from '../lib/blog';
import { Helmet } from 'react-helmet';

export default function SingleBlogPost() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Fetch the blog post from the database
    if (id) {
      const fetchPost = async () => {
        try {
          const result = await getBlogPost(id);
          if (result.success && result.post) {
            // Transform the data to match the BlogPostProps format
            const blogPost = {
              id: result.post.id,
              title: result.post.title,
              excerpt: result.post.excerpt || '',
              content: result.post.content || '',
              image: result.post.featured_image || `https://source.unsplash.com/random/800x600?truck&sig=${result.post.id}`,
              category: result.post.category.title,
              tags: [], // Add tags if needed
              author: {
                name: 'TirJob.pl',
                role: 'Redakcja'
              },
              publishedAt: new Date(result.post.published_at || result.post.created_at).toLocaleDateString('pl-PL', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              }),
              readTime: '5 min', // Calculate based on content length if needed
              liked: false,
              bookmarked: false,
              views: result.post.views || 0,
              comments: 0
            };
            setPost(blogPost);
          } else {
            setError('Nie znaleziono artykułu');
          }
        } catch (err) {
          console.error('Error fetching blog post:', err);
          setError('Wystąpił błąd podczas ładowania artykułu');
        } finally {
          setLoading(false);
        }
      };
      
      fetchPost();
    }
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50/70">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-navy-50/70">
        <h1 className="text-3xl font-bold text-navy-800 mb-4">Artykuł nie został znaleziony</h1>
        <p className="text-navy-600 mb-6">{error || 'Przepraszamy, ale szukany artykuł nie istnieje lub został usunięty.'}</p>
        <button 
          onClick={() => navigate('/blog')}
          className="px-6 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
        >
          Wróć do bloga
        </button>
      </div>
    );
  }

  // Generate dynamic SEO metadata directly
  const generateSeoMetadata = () => {
    if (!post) return null;
    
    // Generate title
    const title = `${post.title} | Blog TirJob.pl`;
    
    // Generate description
    const description = post.excerpt;
    
    // Generate keywords
    const keywords = post.tags.join(', ');
    
    // Generate Schema.org JSON-LD
    const schemaData = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "headline": post.title,
      "description": post.excerpt,
      "image": post.image,
      "datePublished": post.publishedAt,
      "author": {
        "@type": "Person",
        "name": post.author.name
      },
      "publisher": {
        "@type": "Organization",
        "name": "TirJob.pl",
        "logo": {
          "@type": "ImageObject",
          "url": "https://tirjob.pl/logo.png"
        }
      },
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": `https://tirjob.pl${location.pathname}`
      }
    };
    
    return { title, description, keywords, schemaData, image: post.image };
  };
  
  const seoMetadata = generateSeoMetadata();

  return (
    <>
      {seoMetadata && (
        <Helmet>
          <title>{seoMetadata.title}</title>
          <meta name="description" content={seoMetadata.description} />
          <meta name="keywords" content={seoMetadata.keywords} />
          
          {/* OpenGraph Tags */}
          <meta property="og:title" content={seoMetadata.title} />
          <meta property="og:description" content={seoMetadata.description} />
          <meta property="og:image" content={seoMetadata.image} />
          <meta property="og:type" content="article" />
          <meta property="og:url" content={`https://tirjob.pl${location.pathname}`} />
          <meta property="og:site_name" content="TirJob.pl" />
          
          {/* Twitter Tags */}
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content={seoMetadata.title} />
          <meta name="twitter:description" content={seoMetadata.description} />
          <meta name="twitter:image" content={seoMetadata.image} />
          
          {/* Canonical URL */}
          <link rel="canonical" href={`https://tirjob.pl${location.pathname}`} />
          
          {/* Schema.org JSON-LD */}
          <script type="application/ld+json">
            {JSON.stringify(seoMetadata.schemaData)}
          </script>
        </Helmet>
      )}
      <BlogPost post={post} />
    </>
  );
}