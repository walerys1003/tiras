import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { Save, ArrowLeft, Globe } from 'lucide-react';
import ContentEditor from '../../components/admin/BlogPostEditor/ContentEditor';
import SeoEditor from '../../components/admin/BlogPostEditor/SeoEditor';
import { supabase } from '../../lib/supabase';

interface BlogCategory {
  id: string;
  title: string;
  slug: string;
  description: string | null;
}

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  category_id: string;
  status: string;
  published_at: string | null;
  created_at: string;
  updated_at: string;
  is_featured: boolean;
  views: number;
  featured_image: string | null;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  seo_image: string | null;
  category?: BlogCategory;
}

export default function EditBlogPost() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [post, setPost] = useState<Partial<BlogPost>>({
    title: '',
    slug: '',
    content: '',
    excerpt: null,
    category_id: '',
    status: 'draft', 
    featured_image: null,
    is_featured: false,
    seo_title: null,
    seo_description: null,
    seo_keywords: null,
    seo_image: null
  });
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('content');
  const [saveSuccess, setSaveSuccess] = useState<boolean | null>(null);

  // Check auth on mount
  useEffect(() => {
    const init = async () => {
      if (user) {
        await fetchCategories();
        if (id) {
          await fetchPost();
        }
        setLoading(false);
      }
    };

    init();
  }, [user, id]);

  // Reset loading when user changes
  useEffect(() => {
    if (!user) {
      setLoading(true);
    }
  }, [user]);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_categories')
        .select('*')
        .order('title');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
      setError('Failed to load categories');
    }
  };

  const fetchPost = async () => {
    try {
      console.log('Fetching blog post with ID for editing:', id);
      
      const { data, error } = await supabase
        .from('blog_posts')
        .select(`
          *,
          category:blog_categories(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      if (!data) throw new Error('Post not found');

      console.log('Fetched blog post with content length:', data.content?.length);
      
      // Set post data
      setPost({
        id: data.id,
        title: data.title,
        slug: data.slug,
        content: data.content,
        excerpt: data.excerpt,
        category_id: data.category_id,
        status: data.status || 'draft',
        featured_image: data.featured_image,
        is_featured: data.is_featured || false,
        seo_title: data.seo_title,
        seo_description: data.seo_description,
        seo_keywords: data.seo_keywords,
        seo_image: data.seo_image
      });
    } catch (error) {
      console.error('Error fetching post:', error); 
      setError('Failed to load post');
    } finally {
      setLoading(false);
    }
  };

  const updatePost = (updates: Partial<BlogPost>) => {
    setPost(prev => ({ ...prev, ...updates }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Submit triggered with content length:', post.content?.length || 0);
    setSaveSuccess(null);
    
    if (!post.title || !post.content || !post.category_id) { 
      setError('Proszę wypełnić wszystkie wymagane pola');
      return;
    }

    setSaving(true);
    setError(null);

    try {
      // Generate slug from title if not provided
      let updatedPost = { ...post };
      
      if (!updatedPost.slug) {
        const slug = updatedPost.title
          .toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '') // Remove diacritics
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)/g, '');
        updatedPost.slug = slug;
      }
      
      console.log('Final post data being saved:', {
        id: updatedPost.id,
        title: updatedPost.title,
        slug: updatedPost.slug,
        contentLength: updatedPost.content?.length || 0,
        category_id: updatedPost.category_id,
        status: updatedPost.status
      });

      // Create update data object
      const updateData = {
        title: updatedPost.title,
        slug: updatedPost.slug,
        content: updatedPost.content,
        excerpt: updatedPost.excerpt,
        category_id: updatedPost.category_id,
        status: updatedPost.status,
        published_at: updatedPost.status === 'published' ? new Date().toISOString() : null,
        featured_image: updatedPost.featured_image || null,
        is_featured: updatedPost.is_featured || false,
        seo_title: updatedPost.seo_title || null,
        seo_description: updatedPost.seo_description || null,
        seo_keywords: updatedPost.seo_keywords || null,
        seo_image: updatedPost.seo_image || null
      };

      if (updatedPost.id) {
        // Update existing post
        const { error } = await supabase
          .from('blog_posts')
          .update(updateData)
          .eq('id', updatedPost.id);

        if (error) {
          console.error('Supabase update error:', error);
          throw error;
        }
        
        // Verify the update was successful by fetching the post again
        const { data: verifyData, error: verifyError } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('id', updatedPost.id)
          .single();
          
        if (verifyError) {
          console.error('Verification error:', verifyError);
          throw new Error('Verification failed: Could not confirm post update');
        }
        
        if (!verifyData) {
          throw new Error('Verification failed: Post not found after update');
        }
        
        // Check if the content was actually updated
        if (verifyData.content !== updatedPost.content) {
          console.error('Content mismatch after update:', {
            original: updatedPost.content?.substring(0, 100),
            saved: verifyData.content?.substring(0, 100)
          });
          throw new Error('Verification failed: Content was not saved correctly');
        }
        
        console.log('Post verified after update:', {
          id: verifyData.id,
          title: verifyData.title,
          contentLength: verifyData.content?.length
        });
      } else {
        // Create new post
        const { data, error } = await supabase
          .from('blog_posts')
          .insert(updateData)
          .select()
          .single();

        if (error) {
          console.error('Supabase insert error:', error);
          throw error;
        }
        
        if (!data || !data.id) throw new Error('No data returned from insert operation');
        
        // Verify the insert was successful
        const { data: verifyData, error: verifyError } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('id', data.id)
          .single();
          
        if (verifyError) {
          console.error('Verification error after insert:', verifyError);
          throw new Error('Verification failed: Could not confirm post creation');
        }
        
        if (!verifyData) {
          throw new Error('Verification failed: Post not found after creation');
        }
        
        console.log('Post verified after creation:', {
          id: verifyData.id,
          title: verifyData.title,
          contentLength: verifyData.content?.length
        });
        
        updatedPost.id = data.id;
      }

      console.log('Post saved successfully with ID:', updatedPost.id);
      setSaveSuccess(true);
      
      // Stay on the same page after saving
      if (!id && updatedPost.id) {
        navigate(`/admin/blog/${updatedPost.id}/edit`, { replace: true });
      }
    } catch (error) {
      console.error('Error saving post:', error);
      setError(error instanceof Error ? error.message : 'Nie udało się zapisać wpisu');
      setSaveSuccess(false);
    } finally {
      setSaving(false);
    }
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={() => navigate('/admin/blog')}
              className="mr-4 p-2 hover:bg-white rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-navy-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-navy-900">
                {id ? 'Edytuj artykuł' : 'Nowy artykuł'}
              </h1>
              {id && <p className="text-navy-600">ID: {id}</p>}
            </div>
          </div>
          {id && (
            <button
              onClick={() => window.open(`/blog/${post.slug}`, '_blank')}
              className="text-accent-600 hover:text-accent-700 font-medium"
            >
              Zobacz artykuł
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="mb-6 border-b border-gray-200">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('content')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'content' ? 'border-accent-500 text-accent-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
            >Treść</button>
            <button
              onClick={() => setActiveTab('seo')}
              className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${activeTab === 'seo' ? 'border-accent-500 text-accent-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
            ><Globe className="w-4 h-4 mr-2" />SEO</button>
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 text-red-600 p-4 rounded-lg">
            <p className="font-medium">Błąd:</p>
            <p>{error}</p> 
          </div>
        )}
        
        {saveSuccess === true && (
          <div className="mb-6 bg-green-50 text-green-600 p-4 rounded-lg">
            <p className="font-medium">Sukces!</p>
            <p>Zmiany zostały pomyślnie zapisane.</p>
          </div>
        )}
        
        {saveSuccess === false && (
          <div className="mb-6 bg-red-50 text-red-600 p-4 rounded-lg">
            <p className="font-medium">Błąd!</p>
            <p>Nie udało się zapisać zmian. Spróbuj ponownie.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Content Tab */}
          {activeTab === 'content' && (
            <ContentEditor 
              post={post} 
              updatePost={updatePost} 
              categories={categories} 
            />
          )}
          
          {/* SEO Tab */}
          {activeTab === 'seo' && (
            <SeoEditor 
              post={post} 
              updatePost={updatePost} 
            />
          )}

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => navigate('/admin/blog')}
              className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium flex items-center mr-3"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Wróć do listy
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Zapisywanie...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" />
                  {id ? 'Zapisz zmiany' : 'Opublikuj artykuł'}
                </> 
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}