import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { 
  CreditCard, Search, Filter, ArrowUpDown, ChevronDown, ChevronUp, 
  CheckCircle2, XCircle, Clock, Building2, Calendar, Eye, Download, 
  FileText, RefreshCw, Banknote
} from 'lucide-react';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';

interface Payment {
  id: string;
  job_post_id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
  job_post: {
    title: string;
    company: {
      name: string;
      email: string;
      phone: string;
    };
  };
}

type SortField = 'created_at' | 'amount' | 'status' | 'company';
type SortDirection = 'asc' | 'desc';

export default function Payments() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [expandedPayment, setExpandedPayment] = useState<string | null>(null);
  const [totalAmount, setTotalAmount] = useState({ PLN: 0, EUR: 0, USD: 0 });
  const [completedAmount, setCompletedAmount] = useState({ PLN: 0, EUR: 0, USD: 0 });

  useEffect(() => {
    if (user) {
      fetchPayments();
    }
  }, [user]);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('payments')
        .select(`
          *,
          job_post:job_posts(
            title,
            company:companies(
              name,
              email,
              phone
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const paymentsData = data as Payment[];
      setPayments(paymentsData);

      // Calculate totals
      const totals = { PLN: 0, EUR: 0, USD: 0 };
      const completed = { PLN: 0, EUR: 0, USD: 0 };

      paymentsData.forEach(payment => {
        const currency = payment.currency as keyof typeof totals;
        if (totals[currency] !== undefined) {
          totals[currency] += Number(payment.amount);
          if (payment.status === 'completed') {
            completed[currency] += Number(payment.amount);
          }
        }
      });

      setTotalAmount(totals);
      setCompletedAmount(completed);
    } catch (error) {
      console.error('Error fetching payments:', error);
      setError('Failed to load payments');
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: 'pending' | 'completed' | 'failed') => {
    try {
      const { error } = await supabase
        .from('payments')
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;

      // Also update job_post payment_status
      const payment = payments.find(p => p.id === id);
      if (payment) {
        await supabase
          .from('job_posts')
          .update({ 
            payment_status: newStatus,
            status: newStatus === 'completed' ? 'active' : 'inactive'
          })
          .eq('id', payment.job_post_id);
      }

      // Refresh payments
      fetchPayments();
    } catch (error) {
      console.error('Error updating payment status:', error);
      alert('Failed to update payment status');
    }
  };

  const exportToCSV = () => {
    // Create CSV content
    const headers = ['ID', 'Data', 'Firma', 'Ogłoszenie', 'Kwota', 'Waluta', 'Status'];
    const rows = filteredPayments.map(payment => [
      payment.id,
      new Date(payment.created_at).toLocaleDateString('pl-PL'),
      payment.job_post.company.name,
      payment.job_post.title,
      payment.amount,
      payment.currency,
      payment.status === 'completed' ? 'Opłacone' : 
        payment.status === 'pending' ? 'Oczekujące' : 'Anulowane'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `platnosci-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Apply filters and sorting
  const filteredPayments = payments
    .filter(payment => {
      // Status filter
      if (statusFilter !== 'all' && payment.status !== statusFilter) {
        return false;
      }

      // Date filter
      if (dateFilter !== 'all') {
        const paymentDate = new Date(payment.created_at);
        const now = new Date();
        
        if (dateFilter === 'today') {
          const today = new Date();
          return paymentDate.toDateString() === today.toDateString();
        } else if (dateFilter === 'week') {
          const weekAgo = new Date();
          weekAgo.setDate(now.getDate() - 7);
          return paymentDate >= weekAgo;
        } else if (dateFilter === 'month') {
          const monthAgo = new Date();
          monthAgo.setMonth(now.getMonth() - 1);
          return paymentDate >= monthAgo;
        }
      }

      // Search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          payment.job_post.title.toLowerCase().includes(query) ||
          payment.job_post.company.name.toLowerCase().includes(query) ||
          payment.job_post.company.email.toLowerCase().includes(query) ||
          payment.id.toLowerCase().includes(query)
        );
      }

      return true;
    })
    .sort((a, b) => {
      // Apply sorting
      if (sortField === 'created_at') {
        return sortDirection === 'asc'
          ? new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          : new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      } else if (sortField === 'amount') {
        return sortDirection === 'asc'
          ? Number(a.amount) - Number(b.amount)
          : Number(b.amount) - Number(a.amount);
      } else if (sortField === 'status') {
        const statusOrder = { completed: 0, pending: 1, failed: 2 };
        return sortDirection === 'asc'
          ? statusOrder[a.status] - statusOrder[b.status]
          : statusOrder[b.status] - statusOrder[a.status];
      } else if (sortField === 'company') {
        return sortDirection === 'asc'
          ? a.job_post.company.name.localeCompare(b.job_post.company.name)
          : b.job_post.company.name.localeCompare(a.job_post.company.name);
      }
      return 0;
    });

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 mr-1" />;
      case 'pending':
        return <Clock className="w-4 h-4 mr-1" />;
      case 'failed':
        return <XCircle className="w-4 h-4 mr-1" />;
      default:
        return null;
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pl-PL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  return (
    <RequireRole allowedRoles={['admin', 'moderator']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-navy-900">Płatności</h2>
                <p className="text-navy-600">Zarządzaj płatnościami za ogłoszenia</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={fetchPayments}
                  className="px-4 py-2 bg-navy-600 text-white rounded-lg hover:bg-navy-700 transition-colors flex items-center"
                >
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Odśwież
                </button>
                <button
                  onClick={exportToCSV}
                  className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Eksportuj do CSV
                </button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Wszystkie płatności</h3>
                  <CreditCard className="h-6 w-6 text-accent-500" />
                </div>
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-navy-900">{payments.length}</p>
                  <div className="flex flex-col text-sm text-navy-600">
                    <span>Suma: {totalAmount.PLN.toLocaleString('pl-PL')} PLN</span>
                    {totalAmount.EUR > 0 && <span>{totalAmount.EUR.toLocaleString('pl-PL')} EUR</span>}
                    {totalAmount.USD > 0 && <span>{totalAmount.USD.toLocaleString('pl-PL')} USD</span>}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Opłacone</h3>
                  <CheckCircle2 className="h-6 w-6 text-green-500" />
                </div>
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-navy-900">
                    {payments.filter(p => p.status === 'completed').length}
                  </p>
                  <div className="flex flex-col text-sm text-navy-600">
                    <span>Suma: {completedAmount.PLN.toLocaleString('pl-PL')} PLN</span>
                    {completedAmount.EUR > 0 && <span>{completedAmount.EUR.toLocaleString('pl-PL')} EUR</span>}
                    {completedAmount.USD > 0 && <span>{completedAmount.USD.toLocaleString('pl-PL')} USD</span>}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Oczekujące</h3>
                  <Clock className="h-6 w-6 text-yellow-500" />
                </div>
                <p className="text-2xl font-bold text-navy-900">
                  {payments.filter(p => p.status === 'pending').length}
                </p>
                <div className="flex flex-col text-sm text-navy-600">
                  <span>
                    Suma: {payments
                      .filter(p => p.status === 'pending' && p.currency === 'PLN')
                      .reduce((sum, p) => sum + Number(p.amount), 0)
                      .toLocaleString('pl-PL')} PLN
                  </span>
                </div>
              </div>
            </div>

            {/* Filters and Search */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Szukaj płatności..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                  />
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Filter className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent appearance-none"
                  >
                    <option value="all">Wszystkie statusy</option>
                    <option value="completed">Opłacone</option>
                    <option value="pending">Oczekujące</option>
                    <option value="failed">Anulowane</option>
                  </select>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent appearance-none"
                  >
                    <option value="all">Wszystkie daty</option>
                    <option value="today">Dzisiaj</option>
                    <option value="week">Ostatni tydzień</option>
                    <option value="month">Ostatni miesiąc</option>
                  </select>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <ArrowUpDown className="h-5 w-5 text-gray-400" />
                  </div>
                  <select
                    value={`${sortField}-${sortDirection}`}
                    onChange={(e) => {
                      const [field, direction] = e.target.value.split('-');
                      setSortField(field as SortField);
                      setSortDirection(direction as SortDirection);
                    }}
                    className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent appearance-none"
                  >
                    <option value="created_at-desc">Data (najnowsze)</option>
                    <option value="created_at-asc">Data (najstarsze)</option>
                    <option value="amount-desc">Kwota (malejąco)</option>
                    <option value="amount-asc">Kwota (rosnąco)</option>
                    <option value="status-asc">Status (A-Z)</option>
                    <option value="status-desc">Status (Z-A)</option>
                    <option value="company-asc">Firma (A-Z)</option>
                    <option value="company-desc">Firma (Z-A)</option>
                  </select>
                </div>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
                {error}
              </div>
            )}

            {/* Payments List */}
            {filteredPayments.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <p className="text-gray-600">
                  {searchQuery || statusFilter !== 'all' || dateFilter !== 'all'
                    ? 'Brak płatności spełniających kryteria wyszukiwania.'
                    : 'Brak płatności do wyświetlenia.'}
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          ID / Data
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <button
                            onClick={() => handleSort('company')}
                            className="flex items-center focus:outline-none"
                          >
                            Firma / Ogłoszenie
                            {sortField === 'company' && (
                              sortDirection === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
                            )}
                          </button>
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <button
                            onClick={() => handleSort('amount')}
                            className="flex items-center focus:outline-none"
                          >
                            Kwota
                            {sortField === 'amount' && (
                              sortDirection === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
                            )}
                          </button>
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <button
                            onClick={() => handleSort('status')}
                            className="flex items-center focus:outline-none"
                          >
                            Status
                            {sortField === 'status' && (
                              sortDirection === 'asc' ? <ChevronUp className="w-4 h-4 ml-1" /> : <ChevronDown className="w-4 h-4 ml-1" />
                            )}
                          </button>
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Akcje
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredPayments.map((payment) => (
                        <React.Fragment key={payment.id}>
                          <tr className={`hover:bg-gray-50 ${expandedPayment === payment.id ? 'bg-gray-50' : ''}`}>
                            <td className="px-6 py-4">
                              <div className="flex flex-col">
                                <div className="text-sm font-medium text-navy-900 mb-1">
                                  {payment.id.substring(0, 8)}...
                                </div>
                                <div className="text-xs text-gray-500 flex items-center">
                                  <Calendar className="w-3.5 h-3.5 mr-1" />
                                  {formatDate(payment.created_at)}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex flex-col">
                                <div className="text-sm font-medium text-navy-900 mb-1 flex items-center">
                                  <Building2 className="w-4 h-4 mr-1 text-gray-500" />
                                  {payment.job_post.company.name}
                                </div>
                                <div className="text-xs text-gray-500">
                                  {payment.job_post.title}
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="text-sm font-medium text-navy-900 flex items-center">
                                <Banknote className="w-4 h-4 mr-1 text-gray-500" />
                                {payment.amount} {payment.currency}
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeColor(payment.status)}`}>
                                {getStatusIcon(payment.status)}
                                {payment.status === 'completed' ? 'Opłacone' : 
                                 payment.status === 'pending' ? 'Oczekujące' : 'Anulowane'}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-right text-sm font-medium">
                              <div className="flex justify-end space-x-3">
                                <button
                                  onClick={() => setExpandedPayment(expandedPayment === payment.id ? null : payment.id)}
                                  className="text-navy-600 hover:text-navy-900"
                                >
                                  {expandedPayment === payment.id ? 
                                    <ChevronUp className="w-5 h-5" /> : 
                                    <ChevronDown className="w-5 h-5" />}
                                </button>
                                <button
                                  onClick={() => window.open(`/oferty-pracy/${payment.job_post_id}`, '_blank')}
                                  className="text-navy-600 hover:text-navy-900"
                                >
                                  <Eye className="w-5 h-5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                          {expandedPayment === payment.id && (
                            <tr className="bg-gray-50">
                              <td colSpan={5} className="px-6 py-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                  <div>
                                    <h4 className="text-sm font-semibold text-navy-800 mb-3">Dane płatności</h4>
                                    <div className="space-y-2 text-sm">
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">ID płatności:</span>
                                        <span className="font-medium">{payment.id}</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Data utworzenia:</span>
                                        <span>{formatDate(payment.created_at)}</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Data aktualizacji:</span>
                                        <span>{formatDate(payment.updated_at)}</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Kwota:</span>
                                        <span className="font-medium">{payment.amount} {payment.currency}</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Status:</span>
                                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeColor(payment.status)}`}>
                                          {getStatusIcon(payment.status)}
                                          {payment.status === 'completed' ? 'Opłacone' : 
                                           payment.status === 'pending' ? 'Oczekujące' : 'Anulowane'}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                  <div>
                                    <h4 className="text-sm font-semibold text-navy-800 mb-3">Dane firmy</h4>
                                    <div className="space-y-2 text-sm">
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Nazwa firmy:</span>
                                        <span className="font-medium">{payment.job_post.company.name}</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Email:</span>
                                        <a href={`mailto:${payment.job_post.company.email}`} className="text-accent-600 hover:text-accent-700">
                                          {payment.job_post.company.email}
                                        </a>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Telefon:</span>
                                        <a href={`tel:${payment.job_post.company.phone}`} className="text-accent-600 hover:text-accent-700">
                                          {payment.job_post.company.phone}
                                        </a>
                                      </div>
                                      <div className="flex justify-between">
                                        <span className="text-gray-600">Ogłoszenie:</span>
                                        <a 
                                          href={`/oferty-pracy/${payment.job_post_id}`} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          className="text-accent-600 hover:text-accent-700"
                                        >
                                          {payment.job_post.title}
                                        </a>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                {/* Actions */}
                                <div className="mt-6 flex justify-end space-x-3">
                                  {payment.status === 'pending' && (
                                    <>
                                      <button
                                        onClick={() => handleUpdateStatus(payment.id, 'completed')}
                                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center"
                                      >
                                        <CheckCircle2 className="w-4 h-4 mr-2" />
                                        Oznacz jako opłacone
                                      </button>
                                      <button
                                        onClick={() => handleUpdateStatus(payment.id, 'failed')}
                                        className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center"
                                      >
                                        <XCircle className="w-4 h-4 mr-2" />
                                        Oznacz jako anulowane
                                      </button>
                                    </>
                                  )}
                                  {payment.status === 'failed' && (
                                    <button
                                      onClick={() => handleUpdateStatus(payment.id, 'completed')}
                                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center"
                                    >
                                      <CheckCircle2 className="w-4 h-4 mr-2" />
                                      Oznacz jako opłacone
                                    </button>
                                  )}
                                  {payment.status === 'completed' && (
                                    <button
                                      onClick={() => handleUpdateStatus(payment.id, 'pending')}
                                      className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors flex items-center"
                                    >
                                      <Clock className="w-4 h-4 mr-2" />
                                      Oznacz jako oczekujące
                                    </button>
                                  )}
                                  <button
                                    onClick={() => window.open(`/oferty-pracy/${payment.job_post_id}`, '_blank')}
                                    className="px-4 py-2 bg-navy-600 text-white rounded-lg hover:bg-navy-700 transition-colors flex items-center"
                                  >
                                    <FileText className="w-4 h-4 mr-2" />
                                    Zobacz ogłoszenie
                                  </button>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </RequireRole>
  );
}