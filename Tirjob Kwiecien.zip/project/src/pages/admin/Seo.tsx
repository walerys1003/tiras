import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { 
  Search, Plus, Edit, Trash2, Save, X, Globe, FileText, 
  Code, Image, Tag, ArrowRight, Check, AlertCircle
} from 'lucide-react';
import { Loader, CheckCircle } from 'lucide-react';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';
import { 
  getAllSeoSettings, 
  getSeoSettingsByPath, 
  saveSeoSettings, 
  deleteSeoSettings,
  getPageTypes,
  parseSchemaOrg,
  type SeoSettings,
  type SeoSettingsInput
} from '../../lib/seo';
import { type Setting } from '../../lib/settings';
import { useSettings } from '../../hooks/useSettings';

export default function Seo() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { settings, updateSettings, refetch } = useSettings();
  const [seoSettings, setSeoSettings] = useState<SeoSettings[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedSetting, setSelectedSetting] = useState<SeoSettings | null>(null);
  const [formData, setFormData] = useState<SeoSettingsInput>({
    page_path: '',
    page_type: 'custom',
    title: '',
    description: '',
    keywords: '',
    og_title: '',
    og_description: '',
    og_image: '',
    og_type: 'website',
    schema_org: null
  });
  const [schemaOrgString, setSchemaOrgString] = useState('');
  const [schemaOrgError, setSchemaOrgError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState('meta');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [defaultSeoSettings, setDefaultSeoSettings] = useState({
    default_title: settings.default_title || '',
    default_description: settings.default_description || '',
    default_keywords: settings.default_keywords || ''
  });

  // Fetch SEO settings on mount
  useEffect(() => {
    const fetchSettings = async () => {
      if (user) {
        try {
          const data = await getAllSeoSettings();
          setSeoSettings(data);
          
          // Initialize default SEO settings
          setDefaultSeoSettings({
            default_title: settings.default_title || '',
            default_description: settings.default_description || '',
            default_keywords: settings.default_keywords || ''
          });
        } catch (error) {
          console.error('Error fetching SEO settings:', error);
          setError('Failed to load SEO settings');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchSettings();
  }, [user]);

  // Reset loading when user changes
  useEffect(() => {
    if (!user) {
      setLoading(true);
    }
  }, [user]);

  // Filter settings based on search query
  const filteredSettings = searchQuery
    ? seoSettings.filter(setting => 
        setting.page_path.toLowerCase().includes(searchQuery.toLowerCase()) ||
        setting.page_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        setting.title?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : seoSettings;

  const handleAddSetting = () => {
    setFormData({
      page_path: '',
      page_type: 'custom',
      title: '',
      description: '',
      keywords: '',
      og_title: '',
      og_description: '',
      og_image: '',
      og_type: 'website',
      schema_org: null
    });
    setSchemaOrgString('{\n  "@context": "https://schema.org",\n  "@type": "WebPage",\n  "name": "",\n  "description": ""\n}');
    setSchemaOrgError(null);
    setFormErrors({});
    setActiveTab('meta');
    setShowAddModal(true);
  };

  const handleEditSetting = async (id: string) => {
    try {
      const setting = seoSettings.find(s => s.id === id);
      if (!setting) return;

      setSelectedSetting(setting);
      setFormData({
        page_path: setting.page_path,
        page_type: setting.page_type,
        title: setting.title,
        description: setting.description,
        keywords: setting.keywords,
        og_title: setting.og_title,
        og_description: setting.og_description,
        og_image: setting.og_image,
        og_type: setting.og_type,
        schema_org: setting.schema_org
      });
      setSchemaOrgString(setting.schema_org ? JSON.stringify(setting.schema_org, null, 2) : '');
      setSchemaOrgError(null);
      setFormErrors({});
      setActiveTab('meta');
      setShowEditModal(true);
    } catch (error) {
      console.error('Error preparing edit form:', error);
      alert('Failed to load SEO setting details');
    }
  };

  const handleDeleteSetting = async (id: string) => {
    if (!confirm('Are you sure you want to delete this SEO setting?')) return;

    try {
      const result = await deleteSeoSettings(id);
      if (!result.success) throw new Error(result.error);
      
      setSeoSettings(seoSettings.filter(s => s.id !== id));
    } catch (error) {
      console.error('Error deleting SEO setting:', error);
      alert('Failed to delete SEO setting');
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.page_path) {
      errors.page_path = 'Page path is required';
    } else if (!formData.page_path.startsWith('/')) {
      errors.page_path = 'Page path must start with /';
    }

    if (!formData.page_type) {
      errors.page_type = 'Page type is required';
    }

    if (!formData.title) {
      errors.title = 'Title is required';
    } else if (formData.title.length > 60) {
      errors.title = 'Title should be 60 characters or less';
    }

    if (formData.description && formData.description.length > 160) {
      errors.description = 'Description should be 160 characters or less';
    }

    if (schemaOrgString) {
      const result = parseSchemaOrg(schemaOrgString);
      if (!result.valid) {
        errors.schema_org = result.error || 'Invalid Schema.org JSON';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      // Parse Schema.org JSON if provided
      let schemaOrgData = null;
      if (schemaOrgString) {
        const result = parseSchemaOrg(schemaOrgString);
        if (result.valid) {
          schemaOrgData = result.data;
        } else {
          setSchemaOrgError(result.error);
          setIsSubmitting(false);
          return;
        }
      }

      const settingsToSave: SeoSettingsInput = {
        ...formData,
        schema_org: schemaOrgData
      };

      const result = await saveSeoSettings(settingsToSave);
      
      if (!result.success) {
        throw new Error(result.error);
      }

      // Refresh the settings list
      const updatedSettings = await getAllSeoSettings();
      setSeoSettings(updatedSettings);

      // Close the modal
      setShowAddModal(false);
      setShowEditModal(false);
    } catch (error) {
      console.error('Error saving SEO settings:', error);
      setError(error instanceof Error ? error.message : 'Failed to save SEO settings');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSettingChange = async (key: string, value: string) => {
    try {
      // Update local state first for immediate feedback
      setDefaultSeoSettings(prev => ({
        ...prev,
        [key]: value
      }));
      
      // Then update the settings in the database
      await updateSettings([
        { 
          key: key,
          value: value,
          setting_group: 'seo'
        }
      ]);
    } catch (error) {
      console.error('Error updating settings:', error);
      setError('Failed to update settings');
    }
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  return (
    <RequireRole allowedRoles={['admin']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-navy-900">Zarządzanie SEO</h2>
                <p className="text-navy-600">Zarządzaj metadanymi SEO dla różnych stron serwisu</p>
              </div>
            </div>            

            {/* Search and Filters */}
            <div className="mb-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Szukaj strony..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
                {error}
              </div>
            )}

            {/* SEO Settings List */}
            {filteredSettings.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <p className="text-gray-600">
                  {searchQuery ? 'Brak wyników dla podanego zapytania.' : 'Brak ustawień SEO. Dodaj pierwsze ustawienia.'}
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Ścieżka strony
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Typ strony
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Tytuł
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Akcje
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {filteredSettings.map((setting) => (
                        <tr key={setting.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4">
                            <div className="flex items-center">
                              <Globe className="w-4 h-4 mr-2 text-gray-500" />
                              <span className="text-sm font-medium text-navy-900">
                                {setting.page_path}
                              </span>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              {setting.page_type}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm text-gray-900 truncate max-w-xs">
                              {setting.title || '-'}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right text-sm font-medium">
                            <div className="flex justify-end space-x-3">
                              <button
                                onClick={() => handleEditSetting(setting.id)}
                                className="text-navy-600 hover:text-navy-900"
                              >
                                <Edit className="w-5 h-5" />
                              </button>
                              <button
                                onClick={() => handleDeleteSetting(setting.id)}
                                className="text-red-600 hover:text-red-900"
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Add SEO Settings Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-navy-900">Dodaj ustawienia SEO</h3>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <form onSubmit={handleSubmit}>
                {/* Tabs */}
                <div className="flex border-b border-gray-200 mb-6">
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'meta'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('meta')}
                  >
                    Meta Tags
                  </button>
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'og'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('og')}
                  >
                    OpenGraph Tags
                  </button>
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'schema'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('schema')}
                  >
                    Schema.org
                  </button>
                </div>

                {/* Meta Tags Tab */}
                {activeTab === 'meta' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Title *
                      </label>
                      <input
                        type="text"
                        id="title"
                        value={formData.title || ''}
                        onChange={e => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Tytuł strony"
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.title ? 'border-red-500' : 'border-gray-300'
                        }`}
                        required
                      />
                      {formErrors.title ? (
                        <p className="mt-1 text-sm text-red-500">{formErrors.title}</p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          {formData.title ? `${formData.title.length}/60 znaków` : '0/60 znaków'}
                        </p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Description
                      </label>
                      <textarea
                        id="description"
                        value={formData.description || ''}
                        onChange={e => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Opis strony"
                        rows={3}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.description ? 'border-red-500' : 'border-gray-300'
                        }`}
                      />
                      {formErrors.description ? (
                        <p className="mt-1 text-sm text-red-500">{formErrors.description}</p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          {formData.description ? `${formData.description.length}/160 znaków` : '0/160 znaków'}
                        </p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="keywords" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Keywords
                      </label>
                      <input
                        type="text"
                        id="keywords"
                        value={formData.keywords || ''}
                        onChange={e => setFormData({ ...formData, keywords: e.target.value })}
                        placeholder="słowo kluczowe 1, słowo kluczowe 2, słowo kluczowe 3"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Oddziel słowa kluczowe przecinkami
                      </p>
                    </div>
                  </div>
                )}

                {/* OpenGraph Tags Tab */}
                {activeTab === 'og' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="og_title" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Title
                      </label>
                      <input
                        type="text"
                        id="og_title"
                        value={formData.og_title || ''}
                        onChange={e => setFormData({ ...formData, og_title: e.target.value })}
                        placeholder="Tytuł dla social media"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Jeśli puste, zostanie użyty Meta Title
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_description" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Description
                      </label>
                      <textarea
                        id="og_description"
                        value={formData.og_description || ''}
                        onChange={e => setFormData({ ...formData, og_description: e.target.value })}
                        placeholder="Opis dla social media"
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Jeśli puste, zostanie użyty Meta Description
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_image" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Image URL
                      </label>
                      <input
                        type="url"
                        id="og_image"
                        value={formData.og_image || ''}
                        onChange={e => setFormData({ ...formData, og_image: e.target.value })}
                        placeholder="https://example.com/image.jpg"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        URL do obrazka wyświetlanego w social media
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_type" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Type
                      </label>
                      <select
                        id="og_type"
                        value={formData.og_type || 'website'}
                        onChange={e => setFormData({ ...formData, og_type: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      >
                        <option value="website">website</option>
                        <option value="article">article</option>
                        <option value="blog">blog</option>
                        <option value="product">product</option>
                        <option value="profile">profile</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Schema.org Tab */}
                {activeTab === 'schema' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="schema_org" className="block text-sm font-medium text-gray-700 mb-1">
                        Schema.org JSON-LD <span className="text-xs text-gray-500">(Zaawansowane)</span>
                      </label>
                      <div className="relative">
                        <textarea
                          id="schema_org"
                          value={schemaOrgString}
                          onChange={e => {
                            setSchemaOrgString(e.target.value);
                            setSchemaOrgError(null);
                          }}
                          placeholder='{\n  "@context": "https://schema.org",\n  "@type": "WebPage",\n  "name": "Nazwa strony",\n  "description": "Opis strony"\n}'
                          rows={12}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent font-mono text-sm ${
                            schemaOrgError ? 'border-red-500' : 'border-gray-300'
                          }`}
                        />
                      </div>
                      {schemaOrgError ? (
                        <p className="mt-1 text-sm text-red-500 flex items-start">
                          <AlertCircle className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                          {schemaOrgError}
                        </p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          Dane strukturalne w formacie JSON-LD dla wyszukiwarek. Pomaga w wyświetlaniu rozszerzonych wyników wyszukiwania.
                        </p>
                      )}
                      <div className="mt-4">
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              const formatted = JSON.stringify(JSON.parse(schemaOrgString), null, 2);
                              setSchemaOrgString(formatted);
                              setSchemaOrgError(null);
                            } catch (error) {
                              setSchemaOrgError(error instanceof Error ? error.message : 'Invalid JSON format');
                            }
                          }}
                          className="px-4 py-2 bg-gray-100 text-gray-700  rounded-lg hover:bg-gray-200 transition-colors text-sm mr-2"
                        >
                          Formatuj JSON
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            // Generate a basic schema.org template based on page type
                            let template = {};
                            
                            switch (formData.page_type) {
                              case 'home':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "WebSite",
                                  "name": formData.title || "TirJob.pl",
                                  "url": "https://tirjob.pl",
                                  "description": formData.description || "Portal pracy dla kierowców i specjalistów transportu",
                                  
                                  "potentialAction": {
                                    "@type": "SearchAction",
                                    "target": "https://tirjob.pl/search?q={search_term_string}",
                                    "query-input": "required name=search_term_string"
                                  },
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    },
                                    "contactPoint": {
                                      "@type": "ContactPoint",
                                      "telephone": settings.contact_phone || "+48 501 42 00 42",
                                      "contactType": "customer service",
                                      "email": settings.contact_email || "kontakt@tirjob.pl"
                                    }
                                  }
                                };
                                break;
                              case 'blog':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "Blog",
                                  "name": formData.title || "Blog TirJob.pl",
                                  "url": "https://tirjob.pl/blog",
                                  "description": formData.description || "Blog o branży transportowej",
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    },
                                    "contactPoint": {
                                      "@type": "ContactPoint",
                                      "telephone": settings.contact_phone || "+48 501 42 00 42",
                                      "contactType": "customer service",
                                      "email": settings.contact_email || "kontakt@tirjob.pl"
                                    }
                                  }
                                };
                                break;
                              case 'article':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "Article",
                                  "headline": formData.title || "",
                                  "description": formData.description || "",
                                  "image": formData.og_image || "",
                                  "datePublished": new Date().toISOString(),
                                  "dateModified": new Date().toISOString(),
                                  "author": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl"
                                  },
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    }
                                  }
                                };
                                break;
                              default:
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "WebPage",
                                  "name": formData.title || "",
                                  "description": formData.description || "",
                                  "url": `https://tirjob.pl${formData.page_path || ''}`,
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    }
                                  }
                                };
                            }
                            
                            setSchemaOrgString(JSON.stringify(template, null, 2));
                            setSchemaOrgError(null);
                          }}
                          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                        >
                          Generuj szablon
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Form Actions */}
                <div className="mt-8 flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 text-gray-700 hover:text-gray-900"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`px-6 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors ${
                      isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                        Zapisywanie...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Save className="w-4 h-4 mr-2" />
                        Zapisz
                      </span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit SEO Settings Modal */}
        {showEditModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-navy-900">Edytuj ustawienia SEO</h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <form onSubmit={handleSubmit}>
                {/* Tabs */}
                <div className="flex border-b border-gray-200 mb-6">
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'meta'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('meta')}
                  >
                    Meta Tags
                  </button>
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'og'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('og')}
                  >
                    OpenGraph Tags
                  </button>
                  <button
                    type="button"
                    className={`px-4 py-2 font-medium text-sm ${
                      activeTab === 'schema'
                        ? 'text-accent-600 border-b-2 border-accent-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('schema')}
                  >
                    Schema.org
                  </button>
                </div>

                {/* Meta Tags Tab */}
                {activeTab === 'meta' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="page_path" className="block text-sm font-medium text-gray-700 mb-1">
                        Ścieżka strony *
                      </label>
                      <input
                        type="text"
                        id="page_path"
                        value={formData.page_path || ''}
                        onChange={e => setFormData({ ...formData, page_path: e.target.value })}
                        placeholder="/sciezka-strony"
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.page_path ? 'border-red-500' : 'border-gray-300'
                        }`}
                        required
                      />
                      {formErrors.page_path && (
                        <p className="mt-1 text-sm text-red-500">{formErrors.page_path}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="page_type" className="block text-sm font-medium text-gray-700 mb-1">
                        Typ strony *
                      </label>
                      <select
                        id="page_type"
                        value={formData.page_type || 'custom'}
                        onChange={e => setFormData({ ...formData, page_type: e.target.value })}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.page_type ? 'border-red-500' : 'border-gray-300'
                        }`}
                        required
                      >
                        <option value="custom">Custom</option>
                        <option value="home">Home</option>
                        <option value="blog">Blog</option>
                        <option value="article">Article</option>
                        <option value="category">Category</option>
                        <option value="tag">Tag</option>
                      </select>
                      {formErrors.page_type && (
                        <p className="mt-1 text-sm text-red-500">{formErrors.page_type}</p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Title *
                      </label>
                      <input
                        type="text"
                        id="title"
                        value={formData.title || ''}
                        onChange={e => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Tytuł strony"
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.title ? 'border-red-500' : 'border-gray-300'
                        }`}
                        required
                      />
                      {formErrors.title ? (
                        <p className="mt-1 text-sm text-red-500">{formErrors.title}</p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          {formData.title ? `${formData.title.length}/60 znaków` : '0/60 znaków'}
                        </p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Description
                      </label>
                      <textarea
                        id="description"
                        value={formData.description || ''}
                        onChange={e => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Opis strony"
                        rows={3}
                        className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                          formErrors.description ? 'border-red-500' : 'border-gray-300'
                        }`}
                      />
                      {formErrors.description ? (
                        <p className="mt-1 text-sm text-red-500">{formErrors.description}</p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          {formData.description ? `${formData.description.length}/160 znaków` : '0/160 znaków'}
                        </p>
                      )}
                    </div>

                    <div>
                      <label htmlFor="keywords" className="block text-sm font-medium text-gray-700 mb-1">
                        Meta Keywords
                      </label>
                      <input
                        type="text"
                        id="keywords"
                        value={formData.keywords || ''}
                        onChange={e => setFormData({ ...formData, keywords: e.target.value })}
                        placeholder="słowo kluczowe 1, słowo kluczowe 2, słowo kluczowe 3"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Oddziel słowa kluczowe przecinkami
                      </p>
                    </div>
                  </div>
                )}

                {/* OpenGraph Tags Tab */}
                {activeTab === 'og' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="og_title" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Title
                      </label>
                      <input
                        type="text"
                        id="og_title"
                        value={formData.og_title || ''}
                        onChange={e => setFormData({ ...formData, og_title: e.target.value })}
                        placeholder="Tytuł dla social media"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Jeśli puste, zostanie użyty Meta Title
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_description" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Description
                      </label>
                      <textarea
                        id="og_description"
                        value={formData.og_description || ''}
                        onChange={e => setFormData({ ...formData, og_description: e.target.value })}
                        placeholder="Opis dla social media"
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        Jeśli puste, zostanie użyty Meta Description
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_image" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Image URL
                      </label>
                      <input
                        type="url"
                        id="og_image"
                        value={formData.og_image || ''}
                        onChange={e => setFormData({ ...formData, og_image: e.target.value })}
                        placeholder="https://example.com/image.jpg"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <p className="mt-1 text-xs text-gray-500">
                        URL do obrazka wyświetlanego w social media
                      </p>
                    </div>

                    <div>
                      <label htmlFor="og_type" className="block text-sm font-medium text-gray-700 mb-1">
                        OG Type
                      </label>
                      <select
                        id="og_type"
                        value={formData.og_type || 'website'}
                        onChange={e => setFormData({ ...formData, og_type: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      >
                        <option value="website">website</option>
                        <option value="article">article</option>
                        <option value="blog">blog</option>
                        <option value="product">product</option>
                        <option value="profile">profile</option>
                      </select>
                    </div>
                  </div>
                )}

                {/* Schema.org Tab */}
                {activeTab === 'schema' && (
                  <div className="space-y-6">
                    <div>
                      <label htmlFor="schema_org" className="block text-sm font-medium text-gray-700 mb-1">
                        Schema.org JSON-LD <span className="text-xs text-gray-500">(Zaawansowane)</span>
                      </label>
                      <div className="relative">
                        <textarea
                          id="schema_org"
                          value={schemaOrgString}
                          onChange={e => {
                            setSchemaOrgString(e.target.value);
                            setSchemaOrgError(null);
                          }}
                          placeholder='{\n  "@context": "https://schema.org",\n  "@type": "WebPage",\n  "name": "Nazwa strony",\n  "description": "Opis strony"\n}'
                          rows={12}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent font-mono text-sm ${
                            schemaOrgError ? 'border-red-500' : 'border-gray-300'
                          }`}
                        />
                      </div>
                      {schemaOrgError ? (
                        <p className="mt-1 text-sm text-red-500 flex items-start">
                          <AlertCircle className="w-4 h-4 mr-1 mt-0.5 flex-shrink-0" />
                          {schemaOrgError}
                        </p>
                      ) : (
                        <p className="mt-1 text-xs text-gray-500">
                          Dane strukturalne w formacie JSON-LD dla wyszukiwarek. Pomaga w wyświetlaniu rozszerzonych wyników wyszukiwania.
                        </p>
                      )}
                      <div className="mt-4">
                        <button
                          type="button"
                          onClick={() => {
                            try {
                              const formatted = JSON.stringify(JSON.parse(schemaOrgString), null, 2);
                              setSchemaOrgString(formatted);
                              setSchemaOrgError(null);
                            } catch (error) {
                              setSchemaOrgError(error instanceof Error ? error.message : 'Invalid JSON format');
                            }
                          }}
                          className="px-4 py-2 bg-gray-100 text-gray-700  rounded-lg hover:bg-gray-200 transition-colors text-sm mr-2"
                        >
                          Formatuj JSON
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            // Generate a basic schema.org template based on page type
                            let template = {};
                            
                            switch (formData.page_type) {
                              case 'home':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "WebSite",
                                  "name": formData.title || "TirJob.pl",
                                  "url": "https://tirjob.pl",
                                  "description": formData.description || "Portal pracy dla kierowców i specjalistów transportu",
                                  
                                  "potentialAction": {
                                    "@type": "SearchAction",
                                    "target": "https://tirjob.pl/search?q={search_term_string}",
                                    "query-input": "required name=search_term_string"
                                  },
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    },
                                    "contactPoint": {
                                      "@type": "ContactPoint",
                                      "telephone": settings.contact_phone || "+48 501 42 00 42",
                                      "contactType": "customer service",
                                      "email": settings.contact_email || "kontakt@tirjob.pl"
                                    }
                                  }
                                };
                                break;
                              case 'blog':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "Blog",
                                  "name": formData.title || "Blog TirJob.pl",
                                  "url": "https://tirjob.pl/blog",
                                  "description": formData.description || "Blog o branży transportowej",
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    },
                                    "contactPoint": {
                                      "@type": "ContactPoint",
                                      "telephone": settings.contact_phone || "+48 501 42 00 42",
                                      "contactType": "customer service",
                                      "email": settings.contact_email || "kontakt@tirjob.pl"
                                    }
                                  }
                                };
                                break;
                              case 'article':
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "Article",
                                  "headline": formData.title || "",
                                  "description": formData.description || "",
                                  "image": formData.og_image || "",
                                  "datePublished": new Date().toISOString(),
                                  "dateModified": new Date().toISOString(),
                                  "author": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl"
                                  },
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    }
                                  }
                                };
                                break;
                              default:
                                template = {
                                  "@context": "https://schema.org",
                                  "@type": "WebPage",
                                  "name": formData.title || "",
                                  "description": formData.description || "",
                                  "url": `https://tirjob.pl${formData.page_path || ''}`,
                                  "publisher": {
                                    "@type": "Organization",
                                    "name": "TirJob.pl",
                                    "logo": {
                                      "@type": "ImageObject",
                                      "url": "https://i.ibb.co/7NdqLD2G/2.png",
                                      "width": "600",
                                      "height": "60"
                                    }
                                  }
                                };
                            }
                            
                            setSchemaOrgString(JSON.stringify(template, null, 2));
                            setSchemaOrgError(null);
                          }}
                          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                        >
                          Generuj szablon
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Form Actions */}
                <div className="mt-8 flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 text-gray-700 hover:text-gray-900"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`px-6 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors ${
                      isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center">
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                        Zapisywanie...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Save className="w-4 h-4 mr-2" />
                        Zapisz
                      </span>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </RequireRole>
  );
}