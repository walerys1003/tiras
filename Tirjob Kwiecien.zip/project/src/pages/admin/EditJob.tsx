import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Save, ArrowLeft } from 'lucide-react';

interface JobDetails {
  id: string;
  title: string;
  company_id: string;
  position_category: string;
  position_type: string;
  work_type: string;
  country: string;
  voivodeship: string | null;
  city: string;
  trailer_type: string;
  schedule: string;
  salary_amount: number;
  salary_currency: string;
  salary_type: string;
  is_premium: boolean;
  expires_at: string;
  status: string;
  company: {
    name: string;
    email: string;
    phone: string;
  };
  requirements: Array<{ experience: string }>;
  duties: Array<{ duty: string }>;
  benefits: Array<{ benefit: string }>;
  languages: Array<{ language: string }>;
  qualifications: Array<{ qualification: string }>;
}

export default function EditJob() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [job, setJob] = useState<JobDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check auth on mount
  useEffect(() => {
    const init = async () => {
      if (user) {
        await fetchJobDetails();
        setLoading(false);
      }
    };

    init();
  }, [user, id]);

  // Reset loading when user changes
  useEffect(() => {
    if (!user) {
      setLoading(true);
    }
  }, [user]);

  const fetchJobDetails = async () => {
    try {
      const { data, error } = await supabase
        .from('job_posts')
        .select(`
          *,
          company:companies(*),
          requirements:job_requirements(*),
          duties:job_duties(*),
          benefits:job_benefits(*),
          languages:job_languages(*),
          qualifications:job_qualifications(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setJob(data);
    } catch (error) {
      console.error('Error fetching job:', error);
      setError('Failed to load job details');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!job) return;

    setSaving(true);
    setError(null);

    try {
      // Update main job post
      const { error: jobError } = await supabase
        .from('job_posts')
        .update({
          title: job.title,
          position_category: job.position_category,
          position_type: job.position_type,
          work_type: job.work_type,
          country: job.country,
          voivodeship: job.voivodeship,
          city: job.city,
          trailer_type: job.trailer_type,
          schedule: job.schedule,
          salary_amount: job.salary_amount,
          salary_currency: job.salary_currency,
          salary_type: job.salary_type,
          is_premium: job.is_premium,
          expires_at: job.expires_at,
          status: job.status
        })
        .eq('id', job.id);

      if (jobError) throw jobError;

      // Update company details
      const { error: companyError } = await supabase
        .from('companies')
        .update({
          name: job.company.name,
          email: job.company.email,
          phone: job.company.phone
        })
        .eq('id', job.company_id);

      if (companyError) throw companyError;

      // Update requirements
      await supabase
        .from('job_requirements')
        .delete()
        .eq('job_post_id', job.id);
      
      await supabase
        .from('job_requirements')
        .insert(job.requirements.map(req => ({
          job_post_id: job.id,
          experience: req.experience
        })));

      // Update duties
      await supabase
        .from('job_duties')
        .delete()
        .eq('job_post_id', job.id);
      
      await supabase
        .from('job_duties')
        .insert(job.duties.map(duty => ({
          job_post_id: job.id,
          duty: duty.duty
        })));

      // Update benefits
      await supabase
        .from('job_benefits')
        .delete()
        .eq('job_post_id', job.id);
      
      await supabase
        .from('job_benefits')
        .insert(job.benefits.map(benefit => ({
          job_post_id: job.id,
          benefit: benefit.benefit
        })));

      // Update languages
      await supabase
        .from('job_languages')
        .delete()
        .eq('job_post_id', job.id);
      
      await supabase
        .from('job_languages')
        .insert(job.languages.map(lang => ({
          job_post_id: job.id,
          language: lang.language
        })));

      // Update qualifications
      await supabase
        .from('job_qualifications')
        .delete()
        .eq('job_post_id', job.id);
      
      await supabase
        .from('job_qualifications')
        .insert(job.qualifications.map(qual => ({
          job_post_id: job.id,
          qualification: qual.qualification
        })));

      navigate('/admin/jobs');
    } catch (error) {
      console.error('Error updating job:', error);
      setError('Failed to update job details');
    } finally {
      setSaving(false);
    }
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-navy-900 mb-2">Nie znaleziono ogłoszenia</h2>
          <button
            onClick={() => navigate('/admin/jobs')}
            className="text-accent-600 hover:text-accent-700 font-medium"
          >
            Wróć do listy ogłoszeń
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={() => navigate('/admin/jobs')}
              className="mr-4 p-2 hover:bg-white rounded-lg transition-colors"
            >
              <ArrowLeft className="w-6 h-6 text-navy-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-navy-900">Edytuj ogłoszenie</h1>
              <p className="text-navy-600">ID: {job.id}</p>
            </div>
          </div>
          <button
            onClick={() => window.open(`/oferty-pracy/${job.id}`, '_blank')}
            className="text-accent-600 hover:text-accent-700 font-medium"
          >
            Zobacz ogłoszenie
          </button>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 text-red-600 p-4 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Podstawowe informacje</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tytuł ogłoszenia
                </label>
                <input
                  type="text"
                  value={job.title}
                  onChange={e => setJob({ ...job, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  value={job.status}
                  onChange={e => setJob({ ...job, status: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                >
                  <option value="active">Aktywne</option>
                  <option value="inactive">Nieaktywne</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kategoria stanowiska
                </label>
                <select
                  value={job.position_category}
                  onChange={e => setJob({ ...job, position_category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                >
                  <option value="drivers">Kierowcy</option>
                  <option value="logistics">Spedycja i logistyka</option>
                  <option value="construction">Budownictwo i magazyny</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Typ stanowiska
                </label>
                <input
                  type="text"
                  value={job.position_type}
                  onChange={e => setJob({ ...job, position_type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rodzaj pracy
                </label>
                <select
                  value={job.work_type}
                  onChange={e => setJob({ ...job, work_type: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                >
                  <option value="domestic">Krajowy</option>
                  <option value="international">Międzynarodowy</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Data wygaśnięcia
                </label>
                <input
                  type="date"
                  value={new Date(job.expires_at).toISOString().split('T')[0]}
                  onChange={e => setJob({ ...job, expires_at: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Lokalizacja</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kraj
                </label>
                <input
                  type="text"
                  value={job.country}
                  onChange={e => setJob({ ...job, country: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Województwo
                </label>
                <input
                  type="text"
                  value={job.voivodeship || ''}
                  onChange={e => setJob({ ...job, voivodeship: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Miasto
                </label>
                <input
                  type="text"
                  value={job.city}
                  onChange={e => setJob({ ...job, city: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Company Info */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Dane firmy</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nazwa firmy
                </label>
                <input
                  type="text"
                  value={job.company.name}
                  onChange={e => setJob({
                    ...job,
                    company: { ...job.company, name: e.target.value }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={job.company.email}
                  onChange={e => setJob({
                    ...job,
                    company: { ...job.company, email: e.target.value }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Telefon
                </label>
                <input
                  type="tel"
                  value={job.company.phone}
                  onChange={e => setJob({
                    ...job,
                    company: { ...job.company, phone: e.target.value }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Requirements */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Wymagania</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Doświadczenie
                </label>
                <select
                  value={job.requirements[0]?.experience || ''}
                  onChange={e => setJob({
                    ...job,
                    requirements: [{ experience: e.target.value }]
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                >
                  <option value="none">Brak doświadczenia</option>
                  <option value="6m">Do 6 miesięcy</option>
                  <option value="2y">Do 2 lat</option>
                  <option value="5y">2-5 lat</option>
                  <option value="5y+">Powyżej 5 lat</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Języki
                </label>
                <div className="space-y-2">
                  {job.languages.map((lang, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={lang.language}
                        onChange={e => {
                          const newLanguages = [...job.languages];
                          newLanguages[index] = { language: e.target.value };
                          setJob({ ...job, languages: newLanguages });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const newLanguages = job.languages.filter((_, i) => i !== index);
                          setJob({ ...job, languages: newLanguages });
                        }}
                        className="px-3 py-2 text-red-600 hover:text-red-700"
                      >
                        Usuń
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setJob({
                      ...job,
                      languages: [...job.languages, { language: '' }]
                    })}
                    className="text-accent-600 hover:text-accent-700 font-medium"
                  >
                    + Dodaj język
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kwalifikacje
                </label>
                <div className="space-y-2">
                  {job.qualifications.map((qual, index) => (
                    <div key={index} className="flex gap-2">
                      <input
                        type="text"
                        value={qual.qualification}
                        onChange={e => {
                          const newQualifications = [...job.qualifications];
                          newQualifications[index] = { qualification: e.target.value };
                          setJob({ ...job, qualifications: newQualifications });
                        }}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const newQualifications = job.qualifications.filter((_, i) => i !== index);
                          setJob({ ...job, qualifications: newQualifications });
                        }}
                        className="px-3 py-2 text-red-600 hover:text-red-700"
                      >
                        Usuń
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => setJob({
                      ...job,
                      qualifications: [...job.qualifications, { qualification: '' }]
                    })}
                    className="text-accent-600 hover:text-accent-700 font-medium"
                  >
                    + Dodaj kwalifikację
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Duties */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Obowiązki</h2>
            <div className="space-y-2">
              {job.duties.map((duty, index) => (
                <div key={index} className="flex gap-2">
                  <input
                    type="text"
                    value={duty.duty}
                    onChange={e => {
                      const newDuties = [...job.duties];
                      newDuties[index] = { duty: e.target.value };
                      setJob({ ...job, duties: newDuties });
                    }}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const newDuties = job.duties.filter((_, i) => i !== index);
                      setJob({ ...job, duties: newDuties });
                    }}
                    className="px-3 py-2 text-red-600 hover:text-red-700"
                  >
                    Usuń
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setJob({
                  ...job,
                  duties: [...job.duties, { duty: '' }]
                })}
                className="text-accent-600 hover:text-accent-700 font-medium"
              >
                + Dodaj obowiązek
              </button>
            </div>
          </div>

          {/* Benefits */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-navy-900 mb-4">Benefity</h2>
            <div className="space-y-2">
              {job.benefits.map((benefit, index) => (
                <div key={index} className="flex gap-2">
                  <input
                    type="text"
                    value={benefit.benefit}
                    onChange={e => {
                      const newBenefits = [...job.benefits];
                      newBenefits[index] = { benefit: e.target.value };
                      setJob({ ...job, benefits: newBenefits });
                    }}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const newBenefits = job.benefits.filter((_, i) => i !== index);
                      setJob({ ...job, benefits: newBenefits });
                    }}
                    className="px-3 py-2 text-red-600 hover:text-red-700"
                  >
                    Usuń
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setJob({
                  ...job,
                  benefits: [...job.benefits, { benefit: '' }]
                })}
                className="text-accent-600 hover:text-accent-700 font-medium"
              >
                + Dodaj benefit
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 font-medium flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Zapisywanie...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" />
                  Zapisz zmiany
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}