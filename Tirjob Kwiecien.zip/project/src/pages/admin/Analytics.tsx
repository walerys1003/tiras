import React, { useEffect, useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { 
  Filter, RefreshCw, Download, FileText, CreditCard, Search
} from 'lucide-react';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';
import JobAnalyticsComponent from '../../components/admin/analytics/JobAnalytics';
import PaymentAnalyticsComponent from '../../components/admin/analytics/PaymentAnalytics';

// For debugging
console.log('Analytics page component loaded');

export default function Analytics() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'jobs' | 'payments'>('jobs');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Filter states
  const [dateRange, setDateRange] = useState<'all' | '7days' | '30days' | '90days' | 'custom'>('30days');
  const [startDate, setStartDate] = useState<string>(
    new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [endDate, setEndDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  
  // Update date range when filter changes
  useEffect(() => {
    console.log('Date range changed:', dateRange);
    const now = new Date();
    let start = new Date();
    
    switch (dateRange) {
      case '7days':
        start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30days':
        start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      case '90days':
        start = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
        break;
      case 'all':
        start = new Date(2020, 0, 1); // Far in the past
        break;
      // For 'custom', we use the existing startDate and endDate
    }
    
    if (dateRange !== 'custom') {
      setStartDate(start.toISOString().split('T')[0]);
      setEndDate(now.toISOString().split('T')[0]);
    }
  }, [dateRange]);

  // Show loading state while checking authentication
  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-navy-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mb-4"></div>
          <p className="text-navy-600">Oczekiwanie na dane użytkownika...</p>
        </div>
      </div>
    );
  }

  return (
    <RequireRole allowedRoles={['admin', 'moderator']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-navy-900">Analityka</h2>
                <p className="text-navy-600">Szczegółowe statystyki i analiza danych</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    if (activeTab === 'jobs') {
                      console.log('Triggering refresh for job analytics');
                      const jobAnalyticsComponent = document.getElementById('job-analytics-component');
                      if (jobAnalyticsComponent) {
                        jobAnalyticsComponent.dispatchEvent(new Event('refresh'));
                      }
                    } else {
                      console.log('Triggering refresh for payment analytics');
                      const paymentAnalyticsComponent = document.getElementById('payment-analytics-component');
                      if (paymentAnalyticsComponent) {
                        paymentAnalyticsComponent.dispatchEvent(new Event('refresh'));
                      }
                    }
                  }}
                  className="px-4 py-2 bg-navy-600 text-white rounded-lg hover:bg-navy-700 transition-colors flex items-center"
                >
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Odśwież
                </button>
                <button
                  onClick={() => {
                    if (activeTab === 'jobs') {
                      console.log('Triggering export for job analytics');
                      const jobAnalyticsComponent = document.getElementById('job-analytics-component');
                      if (jobAnalyticsComponent) {
                        jobAnalyticsComponent.dispatchEvent(new Event('export'));
                      }
                    } else {
                      console.log('Triggering export for payment analytics');
                      const paymentAnalyticsComponent = document.getElementById('payment-analytics-component');
                      if (paymentAnalyticsComponent) {
                        paymentAnalyticsComponent.dispatchEvent(new Event('export'));
                      }
                    }
                  }}
                  className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Eksportuj do CSV
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="mb-6 border-b border-gray-200">
              <div className="flex space-x-8">
                <button
                  onClick={() => setActiveTab('jobs')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'jobs' 
                      ? 'border-accent-500 text-accent-600' 
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Analityka ogłoszeń
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('payments')}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === 'payments' 
                      ? 'border-accent-500 text-accent-600' 
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center">
                    <CreditCard className="w-5 h-5 mr-2" />
                    Analityka płatności
                  </div>
                </button>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-navy-900 flex items-center">
                  <Filter className="w-5 h-5 mr-2 text-gray-500" />
                  Filtry
                </h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Zakres dat
                  </label>
                  <select
                    value={dateRange}
                    onChange={(e) => setDateRange(e.target.value as any)}
                    className="w-full pl-3 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                  >
                    <option value="7days">Ostatnie 7 dni</option>
                    <option value="30days">Ostatnie 30 dni</option>
                    <option value="90days">Ostatnie 90 dni</option>
                    <option value="all">Cały okres</option>
                    <option value="custom">Niestandardowy zakres</option>
                  </select>
                </div>
                
                {dateRange === 'custom' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Data początkowa
                      </label>
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full pl-3 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Data końcowa
                      </label>
                      <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="w-full pl-3 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                    </div>
                  </>
                )}
                
                {activeTab === 'jobs' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Wyszukaj ogłoszenie
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Szukaj po tytule lub firmie..."
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                      />
                      <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Analytics Content */}
            {activeTab === 'jobs' ? (
              <div id="job-analytics-component">
                <JobAnalyticsComponent 
                  dateRange={dateRange}
                  startDate={startDate}
                  endDate={endDate}
                  onRefresh={() => console.log('Job analytics refreshed')}
                />
              </div>
            ) : (
              <div id="payment-analytics-component">
                <PaymentAnalyticsComponent 
                  dateRange={dateRange}
                  startDate={startDate}
                  endDate={endDate}
                  onRefresh={() => console.log('Payment analytics refreshed')}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </RequireRole>
  );
}