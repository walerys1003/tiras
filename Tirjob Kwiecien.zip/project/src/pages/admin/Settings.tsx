import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { 
  Settings as SettingsIcon, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Linkedin, 
  Instagram, 
  Clock, 
  DollarSign, 
  Upload, 
  Save, 
  Loader, 
  CheckCircle, 
  AlertCircle,
  Trash2,
  RefreshCw
} from 'lucide-react';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';
import { getAllSettings, saveSettings } from '../../lib/settings';
import { uploadFile, deleteFile } from '../../lib/storage';
import type { Setting } from '../../lib/settings';

interface SettingGroup {
  id: string;
  name: string;
  icon: React.ReactNode;
  settings: Setting[];
}

export default function Settings() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('contact');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'success' | 'error' | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const [settingGroups, setSettingGroups] = useState<SettingGroup[]>([
    {
      id: 'contact',
      name: 'Dane kontaktowe',
      icon: <Mail className="w-5 h-5" />,
      settings: [
        { key: 'contact_email', value: 'kontakt@tirjob.pl', setting_group: 'contact' },
        { key: 'contact_phone', value: '+48 501 42 00 42', setting_group: 'contact' },
        { key: 'company_address', value: 'ul. Świeradowska 47\n02-662 Warszawa', setting_group: 'contact' }
      ]
    },
    {
      id: 'social',
      name: 'Social media',
      icon: <Facebook className="w-5 h-5" />,
      settings: [
        { key: 'facebook_url', value: 'https://facebook.com/tirjob', setting_group: 'social' },
        { key: 'linkedin_url', value: 'https://linkedin.com/company/tirjob', setting_group: 'social' },
        { key: 'instagram_url', value: 'https://instagram.com/tirjob.pl', setting_group: 'social' }
      ]
    },
    {
      id: 'recruitment',
      name: 'Rekrutacja',
      icon: <Clock className="w-5 h-5" />,
      settings: [
        { key: 'job_post_duration', value: '60', setting_group: 'recruitment' },
        { key: 'job_post_price', value: '500', setting_group: 'recruitment' },
        { key: 'job_post_premium_price', value: '750', setting_group: 'recruitment' }
      ]
    },
  ]);

  useEffect(() => {
    if (user) {
      fetchSettings();
    }
  }, [user]);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const data = await getAllSettings();

      if (data && data.length > 0) {
        // Update settings with values from database
        const updatedGroups = [...settingGroups];
        
        data.forEach(setting => {
          const groupIndex = updatedGroups.findIndex(group => group.id === setting.setting_group);
          if (groupIndex !== -1) {
            const settingIndex = updatedGroups[groupIndex].settings.findIndex(s => s.key === setting.key);
            if (settingIndex !== -1) {
              updatedGroups[groupIndex].settings[settingIndex].value = setting.value;
            } else {
              // Add new setting if it doesn't exist in our predefined list
              updatedGroups[groupIndex].settings.push(setting);
            }
          }
        });
        
        setSettingGroups(updatedGroups);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
      setError('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSettingChange = (groupId: string, key: string, value: string) => {
    const updatedGroups = [...settingGroups];
    const groupIndex = updatedGroups.findIndex(group => group.id === groupId);
    
    if (groupIndex !== -1) {
      const settingIndex = updatedGroups[groupIndex].settings.findIndex(s => s.key === key);
      if (settingIndex !== -1) {
        updatedGroups[groupIndex].settings[settingIndex].value = value;
        setSettingGroups(updatedGroups);
      }
    }
  };

  const handleSaveSettings = async () => {
    try {
      setSaving(true);
      setSaveStatus(null);
      
      // Prepare settings for saving
      const settingsToSave = settingGroups.flatMap(group => 
        group.settings.map(setting => ({
          key: setting.key,
          value: setting.value,
          setting_group: setting.setting_group
        }))
      );
      
      // Save settings
      const result = await saveSettings(settingsToSave);
      
      if (!result.success) {
        throw new Error(result.error);
      }
      
      setSaveStatus('success');
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveStatus('error');
      setError(error instanceof Error ? error.message : 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  // Get display name for a setting
  const getSettingName = (key: string): string => {
    const settingNames: Record<string, string> = {
      'contact_email': 'Adres e-mail kontaktowy',
      'contact_phone': 'Numer telefonu',
      'company_address': 'Adres firmy',
      'facebook_url': 'Facebook URL',
      'linkedin_url': 'LinkedIn URL',
      'instagram_url': 'Instagram URL',
      'job_post_duration': 'Czas trwania ogłoszenia (dni)',
      'job_post_price': 'Cena ogłoszenia (PLN)',
      'job_post_premium_price': 'Cena ogłoszenia premium (PLN)',
      'default_title': 'Domyślny tytuł strony',
      'default_description': 'Domyślny Meta description',
      'default_keywords': 'Słowa kluczowe'
    };
    
    return settingNames[key] || key;
  };

  // Get placeholder for a setting
  const getSettingPlaceholder = (key: string): string => {
    const placeholders: Record<string, string> = {
      'contact_email': 'np. kontakt@tirjob.pl',
      'contact_phone': 'np. +48 123 456 789',
      'company_address': 'Adres siedziby firmy',
      'facebook_url': 'https://facebook.com/twojafirma',
      'linkedin_url': 'https://linkedin.com/company/twojafirma',
      'instagram_url': 'https://instagram.com/twojafirma',
      'job_post_duration': '60',
      'job_post_price': '500',
      'job_post_premium_price': '750',
      'default_title': 'Tytuł strony głównej',
      'default_description': 'Opis strony głównej',
      'default_keywords': 'Słowa kluczowe oddzielone przecinkami'
    };
    
    return placeholders[key] || '';
  };

  // Get input type for a setting
  const getSettingType = (key: string): 'text' | 'number' | 'email' | 'url' | 'textarea' => {
    if (key === 'contact_email') return 'email';
    if (key === 'facebook_url' || key === 'linkedin_url' || key === 'instagram_url') return 'url';
    if (key === 'job_post_duration' || key === 'job_post_price' || key === 'job_post_premium_price') return 'number';
    if (key === 'company_address' || key === 'default_description' || key === 'default_keywords') return 'textarea';
    return 'text';
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600"></div>
      </div>
    );
  }

  return (
    <RequireRole allowedRoles={['admin']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-navy-900">Ustawienia</h2>
                <p className="text-navy-600">Zarządzaj ustawieniami systemu</p>
              </div>
              <button
                onClick={handleSaveSettings}
                disabled={saving}
                className={`px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center ${
                  saving ? 'opacity-70 cursor-not-allowed' : ''
                }`}
              >
                {saving ? (
                  <Loader className="w-5 h-5 mr-2 animate-spin" />
                ) : saveStatus === 'success' ? (
                  <CheckCircle className="w-5 h-5 mr-2" />
                ) : saveStatus === 'error' ? (
                  <AlertCircle className="w-5 h-5 mr-2" />
                ) : (
                  <Save className="w-5 h-5 mr-2" />
                )}
                {saving ? 'Zapisywanie...' : saveStatus === 'success' ? 'Zapisano!' : saveStatus === 'error' ? 'Błąd zapisu' : 'Zapisz zmiany'}
              </button>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-lg mb-6">
                {error}
              </div>
            )}

            <div className="flex flex-col md:flex-row">
              {/* Sidebar */}
              <div className="w-full md:w-64 md:pr-8 mb-6 md:mb-0">
                <div className="bg-white rounded-xl shadow-sm overflow-hidden">
                  <ul className="divide-y divide-gray-200">
                    {settingGroups.map(group => (
                      <li key={group.id}>
                        <button
                          onClick={() => setActiveTab(group.id)}
                          className={`w-full flex items-center px-4 py-3 text-left ${
                            activeTab === group.id
                              ? 'bg-accent-50 text-accent-700 border-l-4 border-accent-500'
                              : 'text-navy-600 hover:bg-gray-50'
                          }`}
                        >
                          <span className="mr-3">{group.icon}</span>
                          <span className="font-medium">{group.name}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Main Settings Area */}
              <div className="flex-1">
                <div className="bg-white rounded-xl shadow-sm p-6">
                  {settingGroups.map(group => (
                    <div
                      key={group.id}
                      className={activeTab === group.id ? 'block' : 'hidden'}
                    >
                      <h3 className="text-xl font-bold text-navy-900 mb-6 flex items-center">
                        {group.icon}
                        <span className="ml-2">{group.name}</span>
                      </h3>

                      <div className="space-y-6">
                        {group.settings.map(setting => (
                          <div key={setting.key} className="grid grid-cols-1 gap-2">
                            <label className="block text-sm font-medium text-gray-700">
                              {getSettingName(setting.key)}
                            </label>
                            
                            {getSettingType(setting.key) === 'textarea' ? (
                              <textarea
                                value={setting.value}
                                onChange={(e) => handleSettingChange(group.id, setting.key, e.target.value)}
                                placeholder={getSettingPlaceholder(setting.key)}
                                rows={3}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                              />
                            ) : (
                              <input
                                type={getSettingType(setting.key)}
                                value={setting.value}
                                onChange={(e) => handleSettingChange(group.id, setting.key, e.target.value)}
                                placeholder={getSettingPlaceholder(setting.key)}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </RequireRole>
  );
}