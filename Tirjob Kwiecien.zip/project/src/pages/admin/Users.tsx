import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import { Edit, Trash2, Plus, Calendar, User, Mail, Shield, LogOut, AlertCircle } from 'lucide-react';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';
import type { UserRole } from '../../lib/types';

export default function Users() {
  const navigate = useNavigate();
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    role: 'user' as UserRole,
    password: ''
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoggingOutAll, setIsLoggingOutAll] = useState(false);

  const fetchUsers = async () => {
    try {
      const { data: usersData, error: usersError } = await supabase
        .from('users')
        .select('id, email, name, role, created_at, user_id');

      if (usersError) throw usersError;

      setUsers(usersData || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      setError(error instanceof Error ? error.message : 'Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser?.role === 'admin') {
      fetchUsers();
    }
  }, [currentUser]);

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    if (currentUser?.role !== 'admin') {
      setError('Only admin users can update user roles');
      return;
    }

    if (userId === currentUser.id) {
      setError('You cannot change your own role');
      return;
    }

    try {
      const { error: updateError } = await supabase
        .from('users')
        .update({ role: newRole })
        .eq('user_id', userId);

      if (updateError) throw updateError;

      // Update local state
      setUsers(users.map(u => 
        u.user_id === userId ? { ...u, role: newRole } : u
      ));

      setError(null); // Clear any existing errors
    } catch (error) {
      console.error('Error updating role:', error);
      setError(error instanceof Error ? error.message : 'Failed to update user role');
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormErrors({});
    setIsSubmitting(true);

    try {
      // Validate form
      const errors: Record<string, string> = {};
      if (!formData.email) errors.email = 'Email jest wymagany';
      if (!formData.name) errors.name = 'Imię i nazwisko jest wymagane';
      if (!formData.password) errors.password = 'Hasło jest wymagane';
      
      if (Object.keys(errors).length > 0) {
        setFormErrors(errors);
        setIsSubmitting(false);
        return;
      }

      // Sign up the user using Supabase Auth
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            name: formData.name,
            role: formData.role
          }
        }
      });

      if (signUpError) throw signUpError;
      if (!authData.user) throw new Error('Failed to create user');

      // The user record in the users table will be created automatically via triggers

      // Refresh user list
      await fetchUsers();

      // Reset form and close modal
      setFormData({
        email: '',
        name: '',
        role: 'user',
        password: ''
      });
      setShowAddModal(false);
      setError(null); // Clear any existing errors
    } catch (error) {
      console.error('Error adding user:', error);
      setFormErrors({
        submit: error instanceof Error ? error.message : 'Failed to add user'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteUser = async (userId: string, userEmail: string) => {
    if (userId === currentUser?.id) {
      setError('Nie możesz usunąć własnego konta administratora');
      return;
    }

    if (!confirm(`Czy na pewno chcesz usunąć użytkownika ${userEmail}? Ta operacja jest nieodwracalna.`)) {
      return;
    }

    setProcessingId(userId);
    try {
      // Delete from public.users first
      const { error: appError } = await supabase
        .from('users')
        .delete()
        .eq('user_id', userId);

      if (appError) throw appError;

      // Then delete from auth.users
      const { error: authError } = await supabase.auth.admin.deleteUser(userId);
      if (authError) throw authError;

      // Update local state
      setUsers(prev => prev.filter(u => u.user_id !== userId));
      setError(null); // Clear any existing errors
    } catch (error) {
      console.error('Error deleting user:', error);
      setError(error instanceof Error ? error.message : 'Failed to delete user');
    } finally {
      setProcessingId(null);
    }
  };

  const handleLogoutAllUsers = async () => {
    if (!confirm('Czy na pewno chcesz wylogować wszystkich użytkowników? Ta operacja wyloguje również Ciebie.')) return;
    
    setIsLoggingOutAll(true);
    try {
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      
      if (error) throw error;
      
      setError(null); // Clear any existing errors
      alert('Wszyscy użytkownicy zostali wylogowani. Za chwilę zostaniesz przekierowany na stronę logowania.');
      
      // Wait a moment and then navigate to login
      setTimeout(() => {
        navigate('/admin/login');
      }, 2000);
    } catch (error) {
      console.error('Error logging out all users:', error);
      setError(error instanceof Error ? error.message : 'Failed to log out all users');
      setIsLoggingOutAll(false);
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pl-PL', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'redaktor':
        return 'bg-purple-100 text-purple-800';
      case 'moderator':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <RequireRole allowedRoles={['admin']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-navy-900">Użytkownicy</h2>
                <p className="text-navy-600">Zarządzaj użytkownikami systemu</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleLogoutAllUsers}
                  disabled={isLoggingOutAll}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <LogOut className="w-5 h-5 mr-2" />
                  {isLoggingOutAll ? 'Wylogowywanie...' : 'Wyloguj wszystkich'}
                </button>
                <button
                  onClick={() => {
                    setFormData({
                      email: '',
                      name: '',
                      role: 'user',
                      password: ''
                    });
                    setFormErrors({});
                    setShowAddModal(true);
                  }}
                  className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors flex items-center"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj użytkownika
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 p-4 rounded-lg mb-6 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2" />
                {error}
              </div>
            )}

            {users.length === 0 && !loading ? (
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <p className="text-gray-600">
                  Brak użytkowników do wyświetlenia.
                </p>
              </div>
            ) : (
            <div className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Użytkownik
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rola
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Data utworzenia
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Akcje
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {users.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-navy-100 rounded-full flex items-center justify-center">
                              <User className="h-5 w-5 text-navy-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-navy-900">
                                {user.name}
                              </div>
                              <div className="text-sm text-gray-500 flex items-center">
                                <Mail className="w-4 h-4 mr-1" />
                                {user.email}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {currentUser?.id === user.user_id ? (
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role)}`}>
                              <Shield className="w-3.5 h-3.5 mr-1" />
                              {user.role}
                            </span>
                          ) : (
                            <select
                              value={user.role}
                              onChange={(e) => handleRoleChange(user.user_id, e.target.value as UserRole)}
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role)} border-0 bg-transparent cursor-pointer focus:ring-0`}
                              disabled={currentUser?.role !== 'admin'}
                            >
                              <option value="user">Użytkownik</option>
                              <option value="moderator">Moderator</option>
                              <option value="redaktor">Redaktor</option>
                              <option value="admin">Administrator</option>
                            </select>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {user.created_at ? formatDate(user.created_at) : 'N/A'}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right text-sm font-medium">
                          <div className="flex justify-end space-x-3">
                            <button
                              onClick={() => {
                                setSelectedUser(user);
                                setFormData({
                                  email: user.email,
                                  name: user.name,
                                  role: user.role,
                                  password: ''
                                });
                                setFormErrors({});
                                setShowEditModal(true);
                              }}
                              className="text-navy-600 hover:text-navy-900"
                              disabled={currentUser?.id === user.user_id}
                            >
                              <Edit className={`w-5 h-5 ${currentUser?.id === user.user_id ? 'opacity-30 cursor-not-allowed' : ''}`} />
                            </button>
                            <button
                              onClick={() => handleDeleteUser(user.user_id, user.email)}
                              className="text-red-600 hover:text-red-900"
                              disabled={currentUser?.id === user.user_id || processingId === user.user_id}
                            >
                              <Trash2 className={`w-5 h-5 ${currentUser?.id === user.user_id || processingId === user.user_id ? 'opacity-30 cursor-not-allowed' : ''}`} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            )}
          </div>
        </div>

        {/* Add User Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
              <h3 className="text-lg font-bold text-navy-900 mb-4">Dodaj użytkownika</h3>
              
              <form onSubmit={handleAddUser}>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                        formErrors.email ? 'border-red-500' : 'border-gray-300'
                      }`}
                      required
                    />
                    {formErrors.email && (
                      <p className="mt-1 text-sm text-red-500">{formErrors.email}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Imię i nazwisko
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                        formErrors.name ? 'border-red-500' : 'border-gray-300'
                      }`}
                      required
                    />
                    {formErrors.name && (
                      <p className="mt-1 text-sm text-red-500">{formErrors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                      Hasło
                    </label>
                    <input
                      type="password"
                      id="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                        formErrors.password ? 'border-red-500' : 'border-gray-300'
                      }`}
                      required
                    />
                    {formErrors.password && (
                      <p className="mt-1 text-sm text-red-500">{formErrors.password}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
                      Rola
                    </label>
                    <select
                      id="role"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                    >
                      <option value="user">Użytkownik</option>
                      <option value="moderator">Moderator</option>
                      <option value="redaktor">Redaktor</option>
                      <option value="admin">Administrator</option>
                    </select>
                  </div>
                  
                  {formErrors.submit && (
                    <div className="bg-red-50 text-red-600 p-3 rounded-lg">
                      {formErrors.submit}
                    </div>
                  )}
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 disabled:opacity-50"
                  >
                    {isSubmitting ? 'Dodawanie...' : 'Dodaj użytkownika'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit User Modal */}
        {showEditModal && selectedUser && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
              <h3 className="text-lg font-bold text-navy-900 mb-4">Edytuj użytkownika</h3>
              
              <form onSubmit={async (e) => {
                e.preventDefault();
                if (!selectedUser) return;
                
                setFormErrors({});
                setIsSubmitting(true);

                try {
                  const { error } = await supabase
                    .from('users')
                    .update({
                      name: formData.name,
                      role: formData.role
                    })
                    .eq('user_id', selectedUser.user_id);

                  if (error) throw error;

                  // Update local state
                  setUsers(users.map(u => 
                    u.user_id === selectedUser.user_id ? { ...u, name: formData.name, role: formData.role } : u
                  ));

                  setError(null); // Clear any existing errors
                  setShowEditModal(false);
                } catch (error) {
                  console.error('Error updating user:', error);
                  setFormErrors({
                    submit: error instanceof Error ? error.message : 'Failed to update user'
                  });
                } finally {
                  setIsSubmitting(false);
                }
              }}>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Imię i nazwisko
                    </label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent ${
                        formErrors.name ? 'border-red-500' : 'border-gray-300'
                      }`}
                      required
                    />
                    {formErrors.name && (
                      <p className="mt-1 text-sm text-red-500">{formErrors.name}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="role" className="block text-sm font-medium text-gray-700 mb-1">
                      Rola
                    </label>
                    <select
                      id="role"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-accent-500 focus:border-transparent"
                    >
                      <option value="user">Użytkownik</option>
                      <option value="moderator">Moderator</option>
                      <option value="redaktor">Redaktor</option>
                      <option value="admin">Administrator</option>
                    </select>
                  </div>
                  
                  {formErrors.submit && (
                    <div className="bg-red-50 text-red-600 p-3 rounded-lg">
                      {formErrors.submit}
                    </div>
                  )}
                </div>
                
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setShowEditModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-4 py-2 bg-accent-600 text-white rounded-lg hover:bg-accent-700 disabled:opacity-50"
                  >
                    {isSubmitting ? 'Zapisywanie...' : 'Zapisz zmiany'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </RequireRole>
  );
}