import React, { useEffect, useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { FileText, Mail, CreditCard } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import AdminSidebar from '../../components/admin/AdminSidebar';
import RequireRole from '../../components/admin/RequireRole';

console.log('Dashboard component loaded');

export default function Dashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    activeJobs: 0,
    totalSubscribers: 0,
    totalBlogPosts: 0,
    monthlyRevenue: 0
  });

  console.log('Dashboard rendering with user:', user ? { role: user.role, email: user.email } : null);

  // Check auth on mount
  useEffect(() => {
    const init = async () => {
      if (user) {
        console.log('Dashboard: User exists, fetching stats');
        await fetchStats();
        setLoading(false);
      }
    };

    init();
  }, [user]);

  // Reset loading when user changes
  useEffect(() => {
    if (!user) {
      console.log('Dashboard: No user, setting loading to true');
      setLoading(true);
    }
  }, [user]);

  const fetchStats = async () => {
    try {
      console.log('Fetching dashboard stats');
      const [
        { count: jobsCount },
        { count: subscribersCount },
        { data: paymentsData, error: paymentsError }
      ] = await Promise.all([
        supabase
          .from('job_posts')
          .select('id', { count: 'exact' })
          .eq('status', 'active'),
        supabase
          .from('newsletter_subscribers')
          .select('id', { count: 'exact' })
          .eq('status', 'active'),
        supabase
          .from('payments')
          .select('amount, currency, status, created_at')
          .eq('status', 'completed')
          .gte('created_at', new Date(new Date().setMonth(new Date().getMonth() - 1)).toISOString())
      ]);

      if (paymentsError) {
        console.error('Error fetching payments:', paymentsError);
        throw paymentsError;
      }

      // Calculate monthly revenue
      let monthlyRevenue = 0;
      if (paymentsData) {
        monthlyRevenue = paymentsData.reduce((sum, payment) => {
          // Convert all currencies to PLN for simplicity
          // In a real app, you might want to use exchange rates
          const amount = payment.currency === 'PLN' 
            ? payment.amount 
            : payment.currency === 'EUR' 
              ? payment.amount * 4.3 // Example EUR to PLN conversion
              : payment.amount * 3.9; // Example USD to PLN conversion
          
          return sum + amount;
        }, 0);
      }

      console.log('Stats fetched:', { jobsCount, subscribersCount, monthlyRevenue });
      setStats({
        activeJobs: jobsCount || 0,
        totalSubscribers: subscribersCount || 0,
        totalBlogPosts: 0,
        monthlyRevenue: monthlyRevenue
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  // Show loading state while checking authentication
  if (!user || loading) {
    console.log('Dashboard: Showing loading state', { user: !!user, loading });
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mb-4"></div>
          <p className="text-navy-600">Ładowanie panelu...</p>
        </div>
      </div>
    );
  }

  return (
    // Render dashboard content
    <RequireRole allowedRoles={['admin', 'redaktor', 'moderator']}>
      <div className="min-h-screen bg-navy-50">
        <AdminSidebar />

        {/* Main Content */}
        <div className="ml-64 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-navy-900">Dashboard</h2>
              <p className="text-navy-600">Przegląd statystyk i aktywności</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Aktywne ogłoszenia</h3>
                  <FileText className="h-6 w-6 text-green-500" />
                </div>
                <p className="text-3xl font-bold text-navy-900">{stats.activeJobs}</p>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Subskrybenci</h3>
                  <Mail className="h-6 w-6 text-blue-500" />
                </div>
                <p className="text-3xl font-bold text-navy-900">{stats.totalSubscribers}</p>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-navy-600">Przychód (miesiąc)</h3>
                  <CreditCard className="h-6 w-6 text-emerald-500" />
                </div>
                <p className="text-3xl font-bold text-navy-900">
                  {stats.monthlyRevenue.toLocaleString('pl-PL', {
                    style: 'currency',
                    currency: 'PLN'
                  })}
                </p>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-xl font-bold text-navy-900 mb-6">Ostatnia aktywność</h3>
              <div className="space-y-4">
                <p className="text-navy-600">Brak ostatniej aktywności</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </RequireRole>
  );
}