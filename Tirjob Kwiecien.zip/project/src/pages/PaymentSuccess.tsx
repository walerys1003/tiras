import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { CheckCircle2, ArrowRight, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

export default function PaymentSuccess() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const jobId = searchParams.get('job_id');
  const [loading, setLoading] = useState(true);
  const [jobTitle, setJobTitle] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const updateJobStatus = async () => {
      if (!jobId) {
        setError('Brak identyfikatora ogłoszenia');
        setLoading(false);
        return;
      }

      try {
        // Update payment status
        const { error: paymentError } = await supabase
          .from('payments')
          .update({ 
            status: 'completed',
            updated_at: new Date().toISOString()
          })
          .eq('job_post_id', jobId);

        if (paymentError) throw paymentError;

        // Update job post status
        const { data: jobData, error: jobError } = await supabase
          .from('job_posts')
          .update({ 
            status: 'active',
            payment_status: 'completed'
          })
          .eq('id', jobId)
          .select('title')
          .single();

        if (jobError) throw jobError;
        
        setJobTitle(jobData?.title || 'Twoje ogłoszenie');
        
        // Wait a moment before redirecting
        setTimeout(() => {
          setLoading(false);
        }, 1500);
      } catch (error) {
        console.error('Error updating job status:', error);
        setError('Wystąpił błąd podczas aktualizacji statusu ogłoszenia');
        setLoading(false);
      }
    };

    updateJobStatus();
  }, [jobId, navigate]);

  const handleViewJob = () => {
    if (jobId) {
      navigate(`/oferty-pracy/${jobId}`);
    } else {
      navigate('/');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mb-4"></div>
          <p className="text-navy-600">Finalizowanie płatności...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-navy-50 py-12">
        <div className="max-w-lg mx-auto px-4">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <h1 className="text-2xl font-bold text-navy-900 mb-2">Wystąpił błąd</h1>
              <p className="text-navy-600">{error}</p>
            </div>
            
            <button
              onClick={() => navigate('/')}
              className="w-full flex items-center justify-center px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
            >
              <ArrowRight className="w-5 h-5 mr-2" />
              Wróć na stronę główną
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-50 py-12">
      <div className="max-w-lg mx-auto px-4">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-navy-900 mb-2">Płatność zakończona pomyślnie!</h1>
            <p className="text-navy-600">Twoje ogłoszenie zostało opublikowane i jest już widoczne dla potencjalnych kandydatów.</p>
          </div>

          <div className="bg-green-50 rounded-lg p-6 mb-8 border border-green-100">
            <h2 className="font-semibold text-green-800 mb-2">Podsumowanie</h2>
            <div className="space-y-2 text-navy-700">
              <div className="flex justify-between">
                <span>Ogłoszenie:</span>
                <span className="font-medium">{jobTitle}</span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <span className="font-medium text-green-700">Aktywne</span>
              </div>
              <div className="flex justify-between">
                <span>Płatność:</span>
                <span className="font-medium text-green-700">Zrealizowana</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <button
              onClick={handleViewJob}
              className="w-full flex items-center justify-center px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
            >
              <ArrowRight className="w-5 h-5 mr-2" />
              Zobacz swoje ogłoszenie
            </button>
            
            <button
              onClick={() => navigate('/')}
              className="w-full flex items-center justify-center px-6 py-3 bg-white border border-gray-300 text-navy-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Wróć na stronę główną
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}