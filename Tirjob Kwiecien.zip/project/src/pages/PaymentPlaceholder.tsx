import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { CreditCard, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { createCheckoutSession } from '../lib/stripe';

export default function PaymentPlaceholder() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [jobTitle, setJobTitle] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [amount, setAmount] = useState(0);
  const [currency, setCurrency] = useState('PLN');
  const [isPremium, setIsPremium] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchJobDetails = async () => {
      if (!id) return;

      try {
        const { data, error } = await supabase
          .from('job_posts')
          .select(`
            title,
            is_premium,
            payment_status,
            salary_currency,
            company:companies(name)
          `)
          .eq('id', id)
          .single();

        if (error) throw error;
        if (!data) throw new Error('Job not found');

        if (data.payment_status === 'completed') {
          navigate(`/oferty-pracy/${id}`);
          return;
        }

        setJobTitle(data.title);
        setCompanyName(data.company?.name || '');
        setAmount(data.is_premium ? 750 : 500);
        setCurrency('PLN'); // Always use PLN for payments
        setIsPremium(data.is_premium);
      } catch (error) {
        console.error('Error fetching job details:', error);
        setError('Nie udało się załadować szczegółów ogłoszenia.');
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
    
    // Check if we're returning from Stripe with a success or canceled status
    const status = searchParams.get('status');
    if (status === 'success') {
      handlePaymentResult(true);
    } else if (status === 'canceled') {
      setError('Płatność została anulowana. Możesz spróbować ponownie.');
    }
  }, [id, searchParams]);

  const handlePaymentResult = async (success: boolean) => {
    if (!id) return;

    setProcessingPayment(true);
    try {
      // Update payment status
      const { error: paymentError } = await supabase
        .from('payments')
        .update({ 
          status: success ? 'completed' : 'failed',
          updated_at: new Date().toISOString()
        })
        .eq('job_post_id', id);

      if (paymentError) throw paymentError;

      // Update job post status
      const { error: jobError } = await supabase
        .from('job_posts')
        .update({ 
          status: success ? 'active' : 'inactive',
          payment_status: success ? 'completed' : 'failed'
        })
        .eq('id', id);

      if (jobError) throw jobError;

      // Redirect based on payment result
      if (success) {
        navigate(`/oferty-pracy/${id}`, { replace: true });
      } else {
        navigate('/dodaj-ogloszenie', { replace: true });
      }
    } catch (error) {
      console.error('Error updating payment status:', error);
      setError('Wystąpił błąd podczas aktualizacji statusu płatności. Prosimy o kontakt z obsługą.');
    } finally {
      setProcessingPayment(false);
    }
  };

  const handleStripeCheckout = async () => {
    if (!id) return;
    
    setProcessingPayment(true);
    setError(null);
    
    try {
      const result = await createCheckoutSession({
        jobId: id,
        amount,
        currency,
        jobTitle,
        companyName,
        isPremium
      });
      
      if (!result.success) {
        throw new Error(result.error || 'Nie udało się utworzyć sesji płatności');
      }
      
      // The redirect to Stripe happens in the createCheckoutSession function
    } catch (error) {
      console.error('Error creating checkout session:', error);
      setError(error instanceof Error ? error.message : 'Wystąpił nieznany błąd podczas tworzenia sesji płatności');
      setProcessingPayment(false);
    }
  };

  if (loading || processingPayment) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-navy-50">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mb-4"></div>
          <p className="text-navy-600">{processingPayment ? 'Przetwarzanie płatności...' : 'Ładowanie...'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-50 py-12">
      <div className="max-w-lg mx-auto px-4">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <CreditCard className="w-8 h-8 text-accent-600" />
            </div>
            <h1 className="text-2xl font-bold text-navy-900 mb-2">Płatność za ogłoszenie</h1>
            <p className="text-navy-600">{jobTitle}</p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
              {error}
            </div>
          )}

          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <div className="flex justify-between items-center mb-4">
              <span className="text-navy-700">Kwota do zapłaty:</span>
              <span className="text-2xl font-bold text-navy-900">{amount} PLN</span>
            </div>
            <p className="text-sm text-navy-600">
              Po dokonaniu płatności, Twoje ogłoszenie zostanie automatycznie opublikowane.
            </p>
          </div>

          <div className="space-y-4">
            <button
              onClick={handleStripeCheckout}
              disabled={processingPayment}
              className="w-full flex items-center justify-center px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors shadow-md hover:shadow-lg"
            >
              <CreditCard className="w-5 h-5 mr-2" />
              Zapłać z kartą
            </button>
          </div>

          <p className="text-sm text-gray-500 text-center mt-6">
            Płatność jest przetwarzana przez Stripe. Twoje dane płatnicze są bezpieczne i szyfrowane.
          </p>
        </div>
      </div>
    </div>
  );
}