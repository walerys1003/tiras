import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { XCircle, ArrowRight, RefreshCw } from 'lucide-react';

export default function PaymentCanceled() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const jobId = searchParams.get('job_id');

  const handleRetryPayment = () => {
    if (jobId) {
      navigate(`/platnosc/${jobId}`);
    } else {
      navigate('/dodaj-ogloszenie');
    }
  };

  return (
    <div className="min-h-screen bg-navy-50 py-12">
      <div className="max-w-lg mx-auto px-4">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-navy-900 mb-2">Płatność anulowana</h1>
            <p className="text-navy-600">Twoja płatność została anulowana. Ogłoszenie nie zostało opublikowane.</p>
          </div>

          <div className="bg-amber-50 rounded-lg p-6 mb-8 border border-amber-100">
            <h2 className="font-semibold text-amber-800 mb-2">Co teraz?</h2>
            <p className="text-navy-700 mb-4">
              Możesz spróbować ponownie dokonać płatności lub wrócić do formularza dodawania ogłoszenia.
            </p>
            <p className="text-sm text-navy-600">
              Jeśli masz problemy z płatnością, skontaktuj się z naszym zespołem wsparcia: <a href="mailto:kontakt@tirjob.pl" className="text-accent-600 hover:text-accent-700">kontakt@tirjob.pl</a>
            </p>
          </div>

          <div className="space-y-4">
            <button
              onClick={handleRetryPayment}
              className="w-full flex items-center justify-center px-6 py-3 bg-accent-600 text-white rounded-lg hover:bg-accent-700 transition-colors"
            >
              <RefreshCw className="w-5 h-5 mr-2" />
              Spróbuj ponownie
            </button>
            
            <button
              onClick={() => navigate('/dodaj-ogloszenie')}
              className="w-full flex items-center justify-center px-6 py-3 bg-white border border-gray-300 text-navy-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <ArrowRight className="w-5 h-5 mr-2" />
              Wróć do formularza
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}