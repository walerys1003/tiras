import { supabase, withRetry } from './supabase';
import type { JobFormData } from '../components/AddJobForm';
import type { SearchFilters } from '../components/JobSearch';
import { getSeoSettingsByPath } from './seo';

export interface JobListing {
  id: string;
  title: string;
  company: {
    name: string;
  };
  city: string;
  country: string;
  voivodeship: string | null;
  salary_amount: number;
  salary_currency: string;
  salary_type: string;
  schedule: string;
  trailer_type: string;
  work_type: string;
  is_premium: boolean;
  created_at: string;
  position_type: string;
  requirements: {
    experience: string;
  }[];
  languages: {
    language: string;
  }[];
  qualifications: {
    qualification: string;
  }[];
}

export interface PaginatedResult<T> {
  data: T[];
  totalCount: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}

const jobListingsCache = new Map<string, { data: PaginatedResult<JobListing>; timestamp: number }>();
const CACHE_EXPIRY_TIME = 5 * 60 * 1000;

export async function getJobListings(
  filters?: SearchFilters,
  page: number = 1,
  pageSize: number = 20
): Promise<{ success: boolean; data?: PaginatedResult<JobListing>; error?: any }> {
  try {
    const cacheKey = JSON.stringify({ filters, page, pageSize });
    
    const cachedResult = jobListingsCache.get(cacheKey);
    if (cachedResult && Date.now() - cachedResult.timestamp < CACHE_EXPIRY_TIME) {
      return { success: true, data: cachedResult.data };
    }

    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    
    let countQuery = supabase
      .from('job_posts')
      .select('*', { count: 'exact' })
      .eq('status', 'active')
      .gt('expires_at', new Date().toISOString());

    if (filters) {
      if (filters.country_id) {
        countQuery = countQuery.eq('country_id', filters.country_id);
      }

      if (filters.position.category) {
        countQuery = countQuery.eq('position_category', filters.position.category);
      }
      
      if (filters.position.type) {
        countQuery = countQuery.eq('position_type', filters.position.type);
      }
      
      if (filters.workType) {
        countQuery = countQuery.eq('work_type', filters.workType);
      }
      
      if (filters.trailerType && filters.trailerType !== 'Nie dotyczy') {
        countQuery = countQuery.eq('trailer_type', filters.trailerType);
      }
      
      if (filters.schedule) {
        countQuery = countQuery.eq('schedule', filters.schedule);
      }
      
      if (filters.salary.amount) {
        const amount = parseFloat(filters.salary.amount);
        if (!isNaN(amount)) {
          countQuery = countQuery.gte('salary_amount', amount);
        }
      }
      
      if (filters.salary.currency) {
        countQuery = countQuery.eq('salary_currency', filters.salary.currency);
      }
      
      if (filters.driverLicenses && filters.driverLicenses.length > 0) {
        const licenseConditions = filters.driverLicenses.map(license => 
          `position_type.ilike.%${license}%`
        );
        countQuery = countQuery.or(licenseConditions.join(','));
      }
    }

    const { count, error: countError } = await countQuery;
    
    if (countError) throw countError;
    
    const totalCount = count || 0;
    const totalPages = Math.ceil(totalCount / pageSize);

    let query = supabase
      .from('job_posts')
      .select(`
        *,
        company:companies(name),
        country:job_countries(country_name),
        city:job_cities(city_name, voivodeship:job_voivodeships(name)),
        requirements:job_requirements(*),
        languages:job_languages(*),
        qualifications:job_qualifications(*)
      `)
      .eq('status', 'active')
      .gt('expires_at', new Date().toISOString())
      .order('is_premium', { ascending: false });

    if (filters) {
      if (filters.country_id) {
        query = query.eq('country_id', filters.country_id);
      }

      if (filters.position.category) {
        query = query.eq('position_category', filters.position.category);
      }
      
      if (filters.position.type) {
        query = query.eq('position_type', filters.position.type);
      }
      
      if (filters.workType) {
        query = query.eq('work_type', filters.workType);
      }
      
      if (filters.trailerType && filters.trailerType !== 'Nie dotyczy') {
        query = query.eq('trailer_type', filters.trailerType);
      }
      
      if (filters.schedule) {
        query = query.eq('schedule', filters.schedule);
      }
      
      if (filters.salary.amount) {
        const amount = parseFloat(filters.salary.amount);
        if (!isNaN(amount)) {
          query = query.gte('salary_amount', amount);
        }
      }
      
      if (filters.salary.currency) {
        query = query.eq('salary_currency', filters.salary.currency);
      }
      
      if (filters.driverLicenses && filters.driverLicenses.length > 0) {
        const licenseConditions = filters.driverLicenses.map(license => 
          `position_type.ilike.%${license}%`
        );
        query = query.or(licenseConditions.join(','));
      }
    }

    query = query.range(from, to);

    const { data: jobPosts, error: jobError } = await query;

    if (jobError) throw jobError;
    if (!jobPosts) return { success: false, error: 'No data returned from query' };

    const transformedJobPosts = jobPosts.map(post => ({
      id: post.id,
      title: post.title,
      company: {
        name: post.company.name
      },
      city: post.city.city_name,
      country: post.country.country_name,
      voivodeship: post.city.voivodeship?.name || null,
      salary_amount: post.salary_amount,
      salary_currency: post.salary_currency,
      salary_type: post.salary_type,
      schedule: post.schedule,
      trailer_type: post.trailer_type,
      work_type: post.work_type,
      is_premium: post.is_premium,
      created_at: post.created_at,
      position_type: post.position_type,
      requirements: post.requirements || [],
      languages: post.languages || [],
      qualifications: post.qualifications || []
    }));

    const paginatedResult: PaginatedResult<JobListing> = {
      data: transformedJobPosts,
      totalCount,
      totalPages,
      currentPage: page,
      pageSize
    };

    jobListingsCache.set(cacheKey, {
      data: paginatedResult,
      timestamp: Date.now()
    });

    return { success: true, data: paginatedResult };
  } catch (error) {
    console.error('Error fetching job listings:', error);
    return { success: false, error };
  }
}

export async function createJobListing(formData: JobFormData, active: boolean = false) {
  try {
    const { data: company, error: companyError } = await supabase
      .from('companies')
      .insert({
        name: formData.companyName,
        email: formData.email,
        phone: formData.phone,
        nip: formData.nip,
        invoice_data: formData.invoiceData
      })
      .select()
      .single();

    if (companyError) throw companyError;

    const { data: countryData, error: countryError } = await supabase
      .from('job_countries')
      .select('id')
      .eq('country_name', formData.country)
      .single();

    if (countryError) throw countryError;

    let cityQuery = supabase
      .from('job_cities')
      .select('id')
      .eq('city_name', formData.city)
      .eq('country_id', countryData.id);

    if (formData.country === 'Polska' && formData.voivodeship) {
      const { data: voivodeshipData, error: voivodeshipError } = await supabase
        .from('job_voivodeships')
        .select('id')
        .eq('name', formData.voivodeship)
        .eq('country_id', countryData.id)
        .single();

      if (voivodeshipError) throw voivodeshipError;
      
      cityQuery = cityQuery.eq('voivodeship_id', voivodeshipData.id);
    }

    // Changed from .single() to .maybeSingle() to handle case where city doesn't exist
    let { data: cityData, error: cityError } = await cityQuery.maybeSingle();

    // If city doesn't exist or there was an error, create it
    if (!cityData || cityError) {
      const newCityData: any = {
        city_name: formData.city,
        country_id: countryData.id
      };

      if (formData.country === 'Polska' && formData.voivodeship) {
        const { data: voivodeshipData } = await supabase
          .from('job_voivodeships')
          .select('id')
          .eq('name', formData.voivodeship)
          .eq('country_id', countryData.id)
          .single();

        if (voivodeshipData) {
          newCityData.voivodeship_id = voivodeshipData.id;
        }
      }

      const { data: newCity, error: newCityError } = await supabase
        .from('job_cities')
        .insert(newCityData)
        .select()
        .single();

      if (newCityError) throw newCityError;
      
      cityData = newCity;
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 60);

    const { data: jobPost, error: jobError } = await supabase
      .from('job_posts')
      .insert({
        company_id: company.id,
        title: `${formData.position.type} – ${formData.workType === 'domestic' ? 'Transport krajowy' : 'Transport międzynarodowy'}`,
        position_category: formData.position.category,
        position_type: formData.position.type,
        work_type: formData.workType,
        country_id: countryData.id,
        city_id: cityData.id,
        trailer_type: formData.trailerType,
        schedule: formData.schedule,
        salary_amount: parseFloat(formData.salary.amount),
        salary_currency: formData.salary.currency,
        salary_type: formData.salary.type,
        is_premium: formData.promotionOptions.isPremium,
        status: active ? 'active' : 'inactive',
        payment_status: 'pending',
        expires_at: expiresAt.toISOString()
      })
      .select()
      .single();

    if (jobError) throw jobError;

    const amount = formData.promotionOptions.isPremium ? 750 : 500;
    const { error: paymentError } = await supabase
      .from('payments')
      .insert({
        job_post_id: jobPost.id,
        amount: amount,
        currency: 'PLN',
        status: 'pending'
      });

    if (paymentError) throw paymentError;

    await Promise.all([
      supabase.from('job_requirements').insert({
        job_post_id: jobPost.id,
        experience: formData.experience
      }),

      ...formData.duties.map(duty =>
        supabase.from('job_duties').insert({
          job_post_id: jobPost.id,
          duty
        })
      ),

      ...formData.benefits.map(benefit =>
        supabase.from('job_benefits').insert({
          job_post_id: jobPost.id,
          benefit
        })
      ),

      ...formData.languages.map(language =>
        supabase.from('job_languages').insert({
          job_post_id: jobPost.id,
          language
        })
      ),

      ...formData.qualifications.map(qualification =>
        supabase.from('job_qualifications').insert({
          job_post_id: jobPost.id,
          qualification
        })
      )
    ]);

    jobListingsCache.clear();

    return { success: true, jobId: jobPost.id };
  } catch (error) {
    console.error('Error creating job listing:', error);
    return { success: false, error };
  }
}