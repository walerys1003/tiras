import { loadStripe } from '@stripe/stripe-js';

// Load the Stripe.js library with your publishable key
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

export interface CreateCheckoutSessionParams {
  jobId: string;
  amount: number;
  currency: string;
  jobTitle: string;
  companyName: string;
  isPremium: boolean;
}

export async function createCheckoutSession({
  jobId,
  amount,
  currency,
  jobTitle,
  companyName,
  isPremium
}: CreateCheckoutSessionParams) {
  try {
    // Get the Stripe instance
    const stripe = await stripePromise;
    if (!stripe) {
      throw new Error('Failed to load Stripe');
    }

    // Create a checkout session
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/rpc/create_stripe_checkout`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({
        job_id: jobId,
        amount: amount * 100, // Convert to cents
        currency: 'pln', // Always use PLN for payments
        job_title: jobTitle,
        company_name: companyName,
        is_premium: isPremium,
        success_url: `${window.location.origin}/platnosc/sukces?job_id=${jobId}`,
        cancel_url: `${window.location.origin}/platnosc/anulowana?job_id=${jobId}`
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to create checkout session');
    }

    const { id: sessionId } = await response.json();

    // Redirect to Stripe Checkout
    const { error } = await stripe.redirectToCheckout({
      sessionId
    });

    if (error) {
      throw error;
    }

    return { success: true };
  } catch (error) {
    console.error('Error creating checkout session:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

export async function checkPaymentStatus(jobId: string) {
  try {
    const { data, error } = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/rpc/check_payment_status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY,
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({
        job_id: jobId
      })
    }).then(res => res.json());

    if (error) {
      throw error;
    }

    return { 
      success: true, 
      status: data.status,
      paymentStatus: data.payment_status
    };
  } catch (error) {
    console.error('Error checking payment status:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}