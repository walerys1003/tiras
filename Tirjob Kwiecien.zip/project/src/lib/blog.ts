import { supabase } from './supabase';
import { cache } from './cache';
import { Users, Building, TrendingUp, Calendar, GraduationCap, Lightbulb } from 'lucide-react';
import type { BlogPostProps } from '../components/BlogPost';

export interface BlogCategory {
  id: string;
  title: string;
  slug: string;
  description: string | null;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string | null;
  category_id: string;
  status: string;
  published_at: string | null;
  created_at: string;
  updated_at: string;
  is_featured: boolean;
  views: number;
  featured_image: string | null;
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  seo_image: string | null;
  category: BlogCategory;
  // These fields are for UI only and not in the database schema
  seo?: {
    title?: string | null;
    description?: string | null;
    keywords?: string | null;
    og_image?: string | null;
  };
}

export async function getBlogCategories(): Promise<BlogCategory[]> {
  // Check cache first
  const cachedCategories = cache.get<BlogCategory[]>('blog-categories');
  if (cachedCategories) {
    return cachedCategories;
  }

  try {
    const { data, error } = await supabase
      .from('blog_categories')
      .select('*')
      .order('title');

    if (error) throw error;

    // Cache the results
    cache.set('blog-categories', data);
    return data;
  } catch (error) {
    console.error('Error fetching blog categories:', error);
    return [];
  }
}

export async function getFeaturedPosts(): Promise<BlogPostProps[]> {
  try {
    const { data, error } = await supabase
      .from('blog_posts')
      .select(`
        *,
        category:blog_categories(*)
      `)
      .eq('status', 'published')
      .eq('is_featured', true)
      .order('published_at', { ascending: false })
      .limit(7);

    if (error) throw error;

    // Transform the data to match BlogPostProps
    return (data || []).map(post => ({
      id: post.id,
      title: post.title,
      excerpt: post.excerpt || '',
      content: post.content,
      image: post.featured_image || `https://source.unsplash.com/random/800x600?truck&sig=${post.id}`,
      category: post.category.title,
      tags: [], // Add tags if needed
      author: {
        name: 'TirJob.pl',
        role: 'Redakcja'
      },
      publishedAt: new Date(post.published_at || post.created_at).toLocaleDateString('pl-PL', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }),
      readTime: '5 min', // Calculate based on content length if needed
      liked: false,
      bookmarked: false,
      views: post.views || 0,
      comments: 0
    }));
  } catch (error) {
    console.error('Error fetching featured posts:', error);
    return [];
  }
}

export async function getBlogPosts(
  categoryId?: string,
  page: number = 1,
  perPage: number = 7
): Promise<{ posts: BlogPostProps[]; total: number }> {
  try {
    let query = supabase
      .from('blog_posts')
      .select(`
        *,
        category:blog_categories(*)
      `, { count: 'exact' })
      .eq('status', 'published')
      .order('published_at', { ascending: false });

    if (categoryId) {
      query = query.eq('category_id', categoryId);
    }

    // Add pagination
    const from = (page - 1) * perPage;
    const to = from + perPage - 1;
    query = query.range(from, to);

    const { data, error, count } = await query;

    if (error) throw error;

    // Transform the data to match BlogPostProps
    const posts: BlogPostProps[] = (data || []).map(post => ({
      id: post.id,
      title: post.title,
      excerpt: post.excerpt || '',
      content: post.content,
      image: post.featured_image || `https://source.unsplash.com/random/800x600?truck&sig=${post.id}`,
      category: post.category.title,
      tags: [], // Add tags if needed
      author: {
        name: 'TirJob.pl',
        role: 'Redakcja'
      },
      publishedAt: new Date(post.published_at || post.created_at).toLocaleDateString('pl-PL', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }),
      readTime: '5 min', // Calculate based on content length if needed
      liked: false,
      bookmarked: false,
      views: post.views || 0,
      comments: 0
    }));

    return {
      posts,
      total: count || 0
    };
  } catch (error) {
    console.error('Error fetching blog posts:', error);
    return { posts: [], total: 0 };
  }
}

export function getCategoryStyles(slug: string) {
  switch (slug) {
    case 'porady-dla-kandydatow':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
    case 'porady-dla-pracodawcow':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
    case 'trendy-w-branzy':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
    case 'wydarzenia-i-szkolenia':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
    case 'edukacja-i-rozwoj':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/10'
      };
    case 'innowacje':
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
    default:
      return {
        color: 'from-navy-400/40 to-navy-500/40',
        bgLight: 'bg-navy-50',
        iconBg: 'bg-navy-100/40',
        iconColor: 'text-navy-600/80',
        accentColor: 'bg-accent-700/20'
      };
  }
}

export function getCategoryIcon(slug: string) {
  const icons = {
    'porady-dla-kandydatow': Users,
    'porady-dla-pracodawcow': Building,
    'trendy-w-branzy': TrendingUp,
    'wydarzenia-i-szkolenia': Calendar,
    'edukacja-i-rozwoj': GraduationCap,
    'innowacje': Lightbulb
  };

  return icons[slug as keyof typeof icons] || Users;
}

export async function saveBlogPost(post: Partial<BlogPost>): Promise<{ success: boolean; error?: string; id?: string }> {
  try {
    console.log('Saving blog post with content length:', post.content?.length || 0);
    
    if (post.id) {
      // Update existing post
      if (!post.content) {
        console.error('Content is empty or undefined when updating post');
        return { success: false, error: 'Treść wpisu nie może być pusta' };
      }
      
      console.log('Updating existing post with ID:', post.id);
      
      // Create an update object with only the fields that exist in the database schema
      const updateData = {
        title: post.title,
        slug: post.slug,
        content: post.content,
        excerpt: post.excerpt,
        category_id: post.category_id,
        status: post.status,
        published_at: post.status === 'published' ? new Date().toISOString() : null,
        featured_image: post.featured_image || null,
        is_featured: post.is_featured || false,
        // SEO fields
        seo_title: post.seo_title || null,
        seo_description: post.seo_description || null,
        seo_keywords: post.seo_keywords || null,
        seo_image: post.seo_image || null,
        updated_at: new Date().toISOString()
      };
      
      const { error } = await supabase
        .from('blog_posts')
        .update(updateData)
        .eq('id', post.id);

      if (error) {
        console.error('Supabase update error:', error);
        throw error;
      }
      
      // Verify the update was successful
      const { data: verifyData, error: verifyError } = await supabase
        .from('blog_posts')
        .select('id, content')
        .eq('id', post.id)
        .single();
      
      console.log('Verification result:', {
        error: verifyError ? verifyError.message : null,
        dataExists: !!verifyData,
        contentLength: verifyData?.content?.length || 0,
        contentMatches: verifyData?.content === post.content
      });
      
      if (verifyError || !verifyData) {
        throw new Error('Verification failed: Post data could not be retrieved');
      }
      
      console.log('Verification successful. Blog post updated successfully:', verifyData);
      return { success: true, id: post.id };
    } else {
      // Create new post
      if (!post.content) {
        console.error('Content is empty or undefined when creating post');
        return { success: false, error: 'Treść wpisu nie może być pusta' };
      }
      
      console.log('Creating new blog post');
      
      // Create an insert object with only the fields that exist in the database schema
      const insertData = {
        title: post.title,
        slug: post.slug,
        content: post.content,
        excerpt: post.excerpt,
        category_id: post.category_id,
        status: post.status,
        published_at: post.status === 'published' ? new Date().toISOString() : null,
        featured_image: post.featured_image || null,
        is_featured: post.is_featured || false,
        // SEO fields
        seo_title: post.seo_title || null,
        seo_description: post.seo_description || null,
        seo_keywords: post.seo_keywords || null,
        seo_image: post.seo_image || null
      };
      
      const { data, error } = await supabase
        .from('blog_posts')
        .insert(insertData)
        .select()
        .single();

      if (error) {
        console.error('Supabase insert error:', error);
        throw error;
      }
      
      if (!data || !data.id) throw new Error('No data returned from insert operation');
      
      console.log('New blog post created successfully with ID:', data.id);
      return { success: true, id: data.id };
    }
  } catch (error) {
    console.error('Error details:', error);
    console.error('Error saving blog post:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas zapisywania wpisu'
    };
  }
}

export async function deleteBlogPost(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('blog_posts')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error deleting blog post:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas usuwania wpisu'
    };
  }
}

export async function getBlogPost(id: string): Promise<{ success: boolean; post?: BlogPost; error?: string }> {
  try {
    console.log('Fetching blog post with ID for editing:', id);
    
    const { data, error } = await supabase
      .from('blog_posts')
      .select(`
        *,
        category:blog_categories(*)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    if (!data) throw new Error('Post not found');

    console.log('Fetched blog post with content length:', data.content?.length);
    
    // Increment view count
    // Only increment view count when viewing the post, not when editing
    if (window.location.pathname.startsWith('/blog/')) {
      await supabase
        .from('blog_posts')
        .update({ views: (data.views || 0) + 1 })
        .eq('id', id);
    }

    return { success: true, post: data as BlogPost };
  } catch (error) {
    console.error('Error fetching blog post:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas pobierania wpisu'
    };
  }
}