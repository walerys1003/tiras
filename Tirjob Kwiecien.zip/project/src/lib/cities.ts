import { supabase } from './supabase';
import { cache } from './cache';

export interface City {
  id: string;
  name: string;
  countryId: string;
  voivodeshipId?: string;
}

interface CityData {
  cities: City[];
  citiesByCountry: Record<string, City[]>;
  citiesByVoivodeship: Record<string, City[]>;
}

export async function fetchCities(): Promise<CityData> {
  const cachedData = cache.get<CityData>('cities');
  if (cachedData) {
    return cachedData;
  }

  try {
    const { data, error } = await supabase
      .from('job_cities')
      .select(`
        id,
        city_name,
        country_id,
        voivodeship_id
      `)
      .order('city_name');

    if (error) throw error;

    const cities = (data || []).map(city => ({
      id: city.id,
      name: city.city_name,
      countryId: city.country_id,
      voivodeshipId: city.voivodeship_id
    }));

    // Group cities by country
    const citiesByCountry = cities.reduce<Record<string, City[]>>((acc, city) => {
      if (!acc[city.countryId]) {
        acc[city.countryId] = [];
      }
      acc[city.countryId].push(city);
      return acc;
    }, {});

    // Group cities by voivodeship
    const citiesByVoivodeship = cities.reduce<Record<string, City[]>>((acc, city) => {
      if (city.voivodeshipId) {
        if (!acc[city.voivodeshipId]) {
          acc[city.voivodeshipId] = [];
        }
        acc[city.voivodeshipId].push(city);
      }
      return acc;
    }, {});

    const cityData: CityData = {
      cities,
      citiesByCountry,
      citiesByVoivodeship
    };

    cache.set('cities', cityData);
    return cityData;
  } catch (error) {
    console.error('Error fetching cities:', error);
    return {
      cities: [],
      citiesByCountry: {},
      citiesByVoivodeship: {}
    };
  }
}

export function getCitiesByCountry(countryId: string, cityData: CityData): City[] {
  return cityData.citiesByCountry[countryId] || [];
}

export function getCitiesByVoivodeship(voivodeshipId: string, cityData: CityData): City[] {
  return cityData.citiesByVoivodeship[voivodeshipId] || [];
}

export function filterCities(cities: City[], searchText: string): City[] {
  if (!searchText) return cities;
  const search = searchText.toLowerCase();
  return cities.filter(city => city.name.toLowerCase().includes(search));
}