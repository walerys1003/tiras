import { supabase } from './supabase';
import type { User, UserRole } from './types';

console.log('auth.ts module loaded');

export async function signIn(email: string, password: string): Promise<{ success: boolean; error?: string; user?: User }> {
  try {
    console.log('Attempting to sign in with:', email);
    const { data: { session }, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (authError) {
      console.error('Auth error:', authError);
      return { success: false, error: 'Nieprawidłowy email lub hasło', user: undefined };
    }

    if (!session?.user) {
      console.error('No session or user after sign in');
      return { success: false, error: 'Błąd logowania' };
    }

    // Check if user has role in app_metadata
    const role = session.user.app_metadata?.role as UserRole;
    console.log('User role from auth metadata:', role);

    if (role && ['admin', 'redaktor', 'moderator'].includes(role)) {
      // Create user object directly from session data
      const user: User = {
        id: session.user.id,
        email: session.user.email || '',
        name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
        role: role
      }

      return { success: true, user };
    } else {
      await supabase.auth.signOut();
      return { success: false, error: 'Brak dostępu do panelu administracyjnego' };
    }
  } catch (error) {
    console.error('Sign in error:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas logowania'
    };
  }
}

export async function signOut(): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('Sign out error:', error);
      throw error;
    }
    return { success: true };
  } catch (error) {
    console.error('Sign out error:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas wylogowywania' 
    };
  }
}

export async function checkAuth(): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    console.log('checkAuth called');
    const { data: { session }, error } = await supabase.auth.getSession();

    if (error) {
      console.error('Error getting session:', error);
      throw error;
    }
    
    if (!session?.user) {
      console.log('checkAuth: No session found');
      return { success: false, error: 'Brak sesji' };
    }

    console.log('checkAuth: Session found for user:', session.user.email);
    console.log('checkAuth: User metadata:', { 
      app_metadata: session.user.app_metadata,
      user_metadata: session.user.user_metadata
    });

    // Get role from session metadata
    const role = session.user.app_metadata?.role as UserRole;

    console.log('checkAuth: User role:', role);

    if (!role || !['admin', 'redaktor', 'moderator'].includes(role)) {
      console.log('checkAuth: User does not have required role');
      return { success: false, error: 'Brak dostępu do panelu administracyjnego' };
    }

    const user: User = {
      id: session.user.id,
      email: session.user.email!,
      name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
      role: session.user.app_metadata?.role as UserRole
    };

    console.log('checkAuth: Authentication successful, returning user');
    return {
      success: true,
      user
    };
  } catch (error) {
    console.error('Auth check error:', error);
    console.log('checkAuth: Error during authentication check');
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Wystąpił błąd podczas weryfikacji sesji'
    };
  }
}