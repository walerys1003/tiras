export function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout>;

  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };

    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

export function formatExperience(experience: string): string {
  switch (experience) {
    case 'none':
      return 'Brak doświadczenia';
    case '6m':
      return 'Do 6 miesięcy';
    case '2y':
      return 'Do 2 lat';
    case '5y':
      return '2-5 lat';
    case '5y+':
      return 'Powyżej 5 lat';
    default:
      return experience;
  }
}

export function formatSalaryType(type: string): string {
  switch (type) {
    case 'netto':
      return 'Kwota netto';
    case 'brutto':
      return 'Kwota brutto';
    case 'km':
      return 'Stawka za kilometr';
    case 'hour':
      return 'Stawka godzinowa';
    case 'month':
      return 'Pensja miesięczna';
    case 'day':
      return 'Dzienna dieta';
    default:
      return type;
  }
}