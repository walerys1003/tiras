// Function to convert array of objects to CSV string with UTF-8 BOM
export function objectsToCSV<T extends Record<string, any>>(
  data: T[],
  headers: { [K in keyof T]?: string },
  delimiter: string = ';'
): string {
  // Add UTF-8 BOM
  const BOM = '\uFEFF';
  
  // Get all keys from the first object
  const keys = Object.keys(headers);
  
  // Create header row
  const headerRow = keys.map(key => headers[key as keyof T]).join(delimiter);
  
  // Create data rows
  const rows = data.map(obj =>
    keys.map(key => {
      const value = obj[key];
      // Handle values that might contain the delimiter
      const stringValue = String(value ?? '');
      if (stringValue.includes(delimiter) || stringValue.includes('"')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return stringValue;
    }).join(delimiter)
  );
  
  // Combine all rows
  return BOM + [headerRow, ...rows].join('\n');
}