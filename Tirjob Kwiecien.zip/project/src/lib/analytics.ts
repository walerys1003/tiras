import { supabase } from './supabase';

// Record a job view
export async function recordJobView(jobId: string) {
  try {
    // Get session ID from localStorage or create a new one
    let sessionId = localStorage.getItem('tirjob_session_id');
    if (!sessionId) {
      sessionId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      localStorage.setItem('tirjob_session_id', sessionId);
    }

    // Call the RPC function to record the view
    const { data, error } = await supabase.rpc('record_job_view', {
      job_id: jobId,
      ip: null, // We don't collect IP addresses on the client side for privacy
      session: sessionId,
      agent: navigator.userAgent
    });

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error recording job view:', error);
    return { success: false, error };
  }
}

// Get job analytics
export async function getJobAnalytics(
  startDate?: string,
  endDate?: string | null,
  jobId?: string
) {
  try {
    // Prepare date parameters
    console.log('getJobAnalytics called with:', { startDate, endDate, jobId });
    
    // Ensure we have valid dates
    let start: string | null = null;
    if (startDate) {
      try {
        start = new Date(startDate).toISOString();
      } catch (e) {
        console.error('Invalid start date:', startDate, e);
      }
    }
    
    let end: string | null = null;
    if (endDate) {
      try {
        end = new Date(endDate).toISOString();
      } catch (e) {
        console.error('Invalid end date:', endDate, e);
      }
    }
    
    console.log('Parsed dates:', { start, end });

    // Fetch job posts with filters
    let jobsQuery = supabase
      .from('job_posts')
      .select(`
        id,
        title,
        status,
        position_category,
        created_at,
        company:companies(name)
      `);
    
    console.log('Building job posts query');
    
    // Apply date filter
    if (start) {
      jobsQuery = jobsQuery.gte('created_at', start);
    }
    
    if (end) {
      jobsQuery = jobsQuery.lte('created_at', end);
    }
    
    // Apply job ID filter if provided
    if (jobId) {
      jobsQuery = jobsQuery.eq('id', jobId);
    }
    
    console.log('Executing job posts query');
    const { data: jobs, error: jobsError } = await jobsQuery;
    
    console.log('Job posts query result:', { count: jobs?.length, error: jobsError });
    if (jobsError) throw jobsError;
    
    // Fetch applications data with filters
    let applicationsQuery = supabase
      .from('job_applications')
      .select(`
        id,
        job_post_id,
        created_at
      `);
    
    console.log('Building applications query');
    
    // Apply date filter
    if (start) {
      applicationsQuery = applicationsQuery.gte('created_at', start);
    }
    
    if (end) {
      applicationsQuery = applicationsQuery.lte('created_at', end);
    }
    
    // Apply job ID filter if provided
    if (jobId) {
      applicationsQuery = applicationsQuery.eq('job_post_id', jobId);
    }
    
    console.log('Executing applications query');
    const { data: applications, error: applicationsError } = await applicationsQuery;
    
    console.log('Applications query result:', { count: applications?.length, error: applicationsError });
    if (applicationsError) throw applicationsError;
    
    // Fetch job views data with filters
    let viewsQuery = supabase
      .from('job_views')
      .select(`
        id,
        job_post_id,
        viewed_at
      `);
    
    console.log('Building views query');
    
    // Apply date filter
    if (start) {
      viewsQuery = viewsQuery.gte('viewed_at', start);
    }
    
    if (end) {
      viewsQuery = viewsQuery.lte('viewed_at', end);
    }
    
    // Apply job ID filter if provided
    if (jobId) {
      viewsQuery = viewsQuery.eq('job_post_id', jobId);
    }
    
    console.log('Executing views query');
    const { data: views, error: viewsError } = await viewsQuery;
    
    console.log('Views query result:', { count: views?.length, error: viewsError });
    if (viewsError) throw viewsError;
    
    // Calculate analytics
    const totalJobs = jobs?.length || 0;
    const activeJobs = jobs?.filter(job => job.status === 'active').length || 0;
    const totalApplications = applications?.length || 0;
    const totalViews = views?.length || 0;
    
    console.log('Basic analytics calculated:', { totalJobs, activeJobs, totalApplications, totalViews });
    
    // Calculate conversion rate (applications / views)
    const conversionRate = totalViews > 0 ? (totalApplications / totalViews) * 100 : 0;
    
    // Group jobs by status
    const jobsByStatus = [
      { status: 'active', count: jobs?.filter(job => job.status === 'active').length || 0 },
      { status: 'inactive', count: jobs?.filter(job => job.status === 'inactive').length || 0 },
      { status: 'expired', count: jobs?.filter(job => job.status === 'expired').length || 0 }
    ];
    
    // Group jobs by month
    const jobsByMonth: { month: string; count: number }[] = [];
    const monthCounts: Record<string, number> = {};
    
    console.log('Calculating jobs by month');
    
    jobs?.forEach(job => {
      const date = new Date(job.created_at);
      const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthCounts[month] = (monthCounts[month] || 0) + 1;
    });
    
    // Sort months chronologically
    Object.keys(monthCounts)
      .sort()
      .forEach(month => {
        const [year, monthNum] = month.split('-');
        const monthName = new Date(parseInt(year), parseInt(monthNum) - 1, 1)
          .toLocaleString('pl-PL', { month: 'long', year: 'numeric' });
        
        jobsByMonth.push({
          month: monthName,
          count: monthCounts[month]
        });
      });
    
    // Group jobs by category
    const categoryMap: Record<string, number> = {};
    jobs?.forEach(job => {
      console.log('Processing job category:', job.position_category);
      
      const category = job.position_category || 'unknown';
      categoryMap[category] = (categoryMap[category] || 0) + 1;
    });
    
    const jobsByCategory = Object.entries(categoryMap).map(([category, count]) => ({
      category: category === 'drivers' ? 'Kierowcy' : 
               category === 'logistics' ? 'Spedycja i logistyka' : 
               category === 'construction' ? 'Budownictwo i magazyny' : 
               category,
      count
    }));
    
    console.log('Jobs by category:', jobsByCategory);
    
    // Calculate top performing jobs
    const jobViewCounts: Record<string, number> = {};
    views?.forEach(view => {
      jobViewCounts[view.job_post_id] = (jobViewCounts[view.job_post_id] || 0) + 1;
    });
    
    const jobApplicationCounts: Record<string, number> = {};
    applications?.forEach(app => {
      jobApplicationCounts[app.job_post_id] = (jobApplicationCounts[app.job_post_id] || 0) + 1;
    });
    
    const topJobs = jobs?.map(job => {
      const jobViews = jobViewCounts[job.id] || 0;
      const jobApplications = jobApplicationCounts[job.id] || 0;
      const jobConversionRate = jobViews > 0 ? (jobApplications / jobViews) * 100 : 0;
      
      return {
        id: job.id,
        title: job.title,
        company: job.company?.name || 'Unknown Company',
        views: jobViews,
        applications: jobApplications,
        conversionRate: jobConversionRate
      };
    }).sort((a, b) => b.applications - a.applications).slice(0, 10) || [];
    
    console.log('Analytics data prepared successfully');
    
    return {
      success: true,
      data: {
        totalJobs,
        activeJobs,
        totalApplications,
        totalViews,
        conversionRate,
        jobsByStatus,
        jobsByMonth,
        jobsByCategory,
        topJobs
      }
    };
  } catch (error) {
    console.error('Error fetching job analytics:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Get payment analytics
export async function getPaymentAnalytics(
  startDate?: string,
  endDate?: string | null
) {
  try {
    // Prepare date parameters
    const start = startDate ? new Date(startDate).toISOString() : null;
    const end = endDate ? new Date(endDate).toISOString() : null;
    
    // Fetch payment data with filters
    let paymentsQuery = supabase
      .from('payments')
      .select(`
        id,
        amount,
        currency,
        status,
        created_at,
        job_post_id
      `);
    
    // Apply date filter
    if (start) {
      paymentsQuery = paymentsQuery.gte('created_at', start);
    }
    
    if (end) {
      paymentsQuery = paymentsQuery.lte('created_at', end);
    }
    
    const { data: payments, error: paymentsError } = await paymentsQuery;
    
    if (paymentsError) throw paymentsError;
    
    // Calculate analytics
    const totalPayments = payments?.length || 0;
    const completedPayments = payments?.filter(p => p.status === 'completed').length || 0;
    const pendingPayments = payments?.filter(p => p.status === 'pending').length || 0;
    const failedPayments = payments?.filter(p => p.status === 'failed').length || 0;
    
    // Calculate total revenue
    let totalRevenue = 0;
    payments?.forEach(payment => {
      if (payment.status === 'completed') {
        // Convert all to PLN for simplicity
        const amount = payment.currency === 'PLN' 
          ? payment.amount 
          : payment.currency === 'EUR' 
            ? payment.amount * 4.3 // Example conversion rate
            : payment.amount * 3.9; // Example conversion rate
        
        totalRevenue += amount;
      }
    });
    
    // Group payments by month
    const revenueByMonth: { month: string; amount: number }[] = [];
    const monthRevenue: Record<string, number> = {};
    
    payments?.forEach(payment => {
      if (payment.status === 'completed') {
        const date = new Date(payment.created_at);
        const month = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        // Convert to PLN
        const amount = payment.currency === 'PLN' 
          ? payment.amount 
          : payment.currency === 'EUR' 
            ? payment.amount * 4.3 
            : payment.amount * 3.9;
        
        monthRevenue[month] = (monthRevenue[month] || 0) + amount;
      }
    });
    
    // Sort months chronologically
    Object.keys(monthRevenue)
      .sort()
      .forEach(month => {
        const [year, monthNum] = month.split('-');
        const monthName = new Date(parseInt(year), parseInt(monthNum) - 1, 1)
          .toLocaleString('pl-PL', { month: 'long', year: 'numeric' });
        
        revenueByMonth.push({
          month: monthName,
          amount: monthRevenue[month]
        });
      });
    
    // Group payments by status
    const paymentsByStatus = [
      { status: 'completed', count: completedPayments },
      { status: 'pending', count: pendingPayments },
      { status: 'failed', count: failedPayments }
    ];
    
    return {
      success: true,
      data: {
        totalPayments,
        totalRevenue,
        completedPayments,
        pendingPayments,
        failedPayments,
        revenueByMonth,
        paymentsByStatus
      }
    };
  } catch (error) {
    console.error('Error fetching payment analytics:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}