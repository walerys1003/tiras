import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  },
  global: {
    fetch: (...args) => {
      console.log('Supabase fetch request:', args[0]);
      return fetch(...args).then(response => {
        // Clone the response so we can log it without consuming it
        const clonedResponse = response.clone();
        clonedResponse.text().then(text => {
          try {
            const data = JSON.parse(text);
            console.log('Supabase response:', {
              url: args[0],
              status: response.status,
              data
            });
          } catch (e) {
            console.log('Supabase response (not JSON):', {
              url: args[0],
              status: response.status,
              text: text.substring(0, 500) // Log only first 500 chars if large
            });
          }
        });
        return response;
      });
    }
  }
});

// Helper function to handle Supabase errors
export function handleSupabaseError(error: any): string {
  if (!error) return 'An unknown error occurred';

  // Handle specific Supabase error codes
  if (error.code) {
    switch (error.code) {
      case 'PGRST116':
        return 'Resource not found';
      case 'PGRST301':
        return 'Database connection error';
      case '23505':
        return 'This record already exists';
      case '23503':
        return 'Cannot perform operation - data integrity violation';
      default:
        return `Database error: ${error.message || error.code}`;
    }
  }

  // Handle network errors
  if (error.message?.includes('fetch') || error.message?.includes('network')) {
    return 'Server connection error. Please check your internet connection.';
  }

  // Return original error message or generic error
  return error.message || 'An unexpected error occurred';
}

// Retry function with exponential backoff
export async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      // Don't retry if it's not a network error
      if (!lastError.message.includes('fetch') && !lastError.message.includes('network')) {
        throw lastError;
      }
      
      // Calculate delay with exponential backoff
      const delay = Math.min(baseDelay * Math.pow(2, attempt), 5000);
      
      // Wait before next retry
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  // If we've exhausted all retries, throw the last error
  throw lastError || new Error('Maximum retry attempts reached');
}