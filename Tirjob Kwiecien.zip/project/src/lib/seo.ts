import { supabase } from './supabase';

export interface SeoSettings {
  id: string;
  page_path: string;
  page_type: string;
  title: string | null;
  description: string | null;
  keywords: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  og_type: string | null;
  schema_org: any | null;
  created_at: string;
  updated_at: string;
}

export interface SeoSettingsInput {
  page_path: string;
  page_type: string;
  title: string | null;
  description: string | null;
  keywords: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  og_type: string | null;
  schema_org: any | null;
}

// Get all SEO settings
export async function getAllSeoSettings(): Promise<SeoSettings[]> {
  try {
    const { data, error } = await supabase
      .from('seo_settings')
      .select('*')
      .order('page_path');

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching SEO settings:', error);
    return [];
  }
}

// Get SEO settings by page path
export async function getSeoSettingsByPath(pagePath: string): Promise<SeoSettings | null> {
  try {
    const { data, error } = await supabase
      .from('seo_settings')
      .select('*')
      .eq('page_path', pagePath)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        // No data found
        return null;
      }
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error(`Error fetching SEO settings for path ${pagePath}:`, error);
    return null;
  }
}

// Create or update SEO settings
export async function saveSeoSettings(settings: SeoSettingsInput): Promise<{ success: boolean; error?: string; id?: string }> {
  try {
    // Use upsert to handle both insert and update cases
    const { data, error } = await supabase
      .from('seo_settings')
      .upsert(
        {
          ...settings,
          updated_at: new Date().toISOString()
        },
        {
          onConflict: 'page_path',
          ignoreDuplicates: false
        }
      )
      .select()
      .single();

    if (error) throw error;
    
    if (!data) {
      throw new Error('No data returned after save operation');
    }

    return { success: true, id: data.id };
  } catch (error) {
    console.error('Error saving SEO settings:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Delete SEO settings
export async function deleteSeoSettings(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase
      .from('seo_settings')
      .delete()
      .eq('id', id);

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error deleting SEO settings:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Get all page types
export function getPageTypes(): string[] {
  return [
    'home',
    'blog',
    'blog-post',
    'blog-category',
    'job-list',
    'job-detail',
    'pricing',
    'contact',
    'newsletter',
    'terms',
    'privacy',
    'social-media',
    'promotion-services',
    'custom'
  ];
}

// Parse and validate Schema.org JSON
export function parseSchemaOrg(jsonString: string): { valid: boolean; data?: any; error?: string } {
  try {
    const data = JSON.parse(jsonString);
    
    // Basic validation - check for required fields
    if (!data['@context'] || !data['@type']) {
      return { 
        valid: false, 
        error: 'Invalid Schema.org format: missing @context or @type' 
      };
    }
    
    return { valid: true, data };
  } catch (error) {
    return { 
      valid: false, 
      error: error instanceof Error ? error.message : 'Invalid JSON format'
    };
  }
}