import { supabase } from './supabase';

export interface Setting {
  key: string;
  value: string;
  setting_group: string;
}

export interface SettingGroup {
  id: string;
  name: string;
  settings: Setting[];
}

// Get all settings
export async function getAllSettings(): Promise<Setting[]> {
  try {
    const { data, error } = await supabase
      .from('admin_settings')
      .select('*')
      .order('key');

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching settings:', error);
    return [];
  }
}

// Get settings by group
export async function getSettingsByGroup(group: string): Promise<Setting[]> {
  try {
    const { data, error } = await supabase
      .from('admin_settings')
      .select('*')
      .eq('setting_group', group)
      .order('key');

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error(`Error fetching settings for group ${group}:`, error);
    return [];
  }
}

// Get setting by key
export async function getSettingByKey(key: string): Promise<Setting | null> {
  try {
    const { data, error } = await supabase
      .from('admin_settings')
      .select('*')
      .eq('key', key)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        // No data found
        return null;
      }
      throw error;
    }
    
    return data;
  } catch (error) {
    console.error(`Error fetching setting with key ${key}:`, error);
    return null;
  }
}

// Save settings
export async function saveSettings(settings: Partial<Setting>[]): Promise<{ success: boolean; error?: string }> {
  try {
    // Add updated_at to each setting
    const settingsToSave = settings.map(setting => ({
      ...setting,
      updated_at: new Date().toISOString()
    }));

    const { error } = await supabase
      .from('admin_settings')
      .upsert(settingsToSave, {
        onConflict: 'key',
        ignoreDuplicates: false
      });

    if (error) throw error;
    return { success: true };
  } catch (error) {
    console.error('Error saving settings:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Get a setting value by key with default fallback
export async function getSettingValue(key: string, defaultValue: string = ''): Promise<string> {
  const setting = await getSettingByKey(key);
  return setting?.value || defaultValue;
}

// Group settings by their group property
export function groupSettings(settings: Setting[]): SettingGroup[] {
  const groups: Record<string, Setting[]> = {};
  
  settings.forEach(setting => {
    if (!groups[setting.setting_group]) {
      groups[setting.setting_group] = [];
    }
    groups[setting.setting_group].push(setting);
  });
  
  return Object.entries(groups).map(([id, settings]) => ({
    id,
    name: getGroupName(id),
    settings
  }));
}

// Helper function to get a human-readable group name
function getGroupName(groupId: string): string {
  const groupNames: Record<string, string> = {
    'contact': 'Dane kontaktowe',
    'social': 'Social media',
    'recruitment': 'Rekrutacja',
    'seo': 'SEO',
    'branding': 'Branding'
  };
  
  return groupNames[groupId] || groupId;
}