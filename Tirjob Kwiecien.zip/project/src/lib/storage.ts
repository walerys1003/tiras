import { supabase } from './supabase';
import { v4 as uuidv4 } from 'uuid';

// Upload a file to Supabase Storage
export async function uploadFile(
  file: File,
  bucket: string = 'public',
  folder: string = 'uploads'
): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    // Generate a unique file name to avoid collisions
    const fileExt = file.name.split('.').pop();
    const fileName = `${uuidv4()}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    // Upload the file
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (error) throw error;

    // Get the public URL
    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return { success: true, url: publicUrl };
  } catch (error) {
    console.error('Error uploading file:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Delete a file from Supabase Storage
export async function deleteFile(
  filePath: string,
  bucket: string = 'public'
): Promise<{ success: boolean; error?: string }> {
  try {
    // Extract the path from the URL
    const path = filePath.split(`${bucket}/`)[1];
    
    if (!path) {
      throw new Error('Invalid file path');
    }

    const { error } = await supabase.storage
      .from(bucket)
      .remove([path]);

    if (error) throw error;

    return { success: true };
  } catch (error) {
    console.error('Error deleting file:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

// Get a list of files from a folder
export async function listFiles(
  bucket: string = 'public',
  folder: string = 'uploads'
): Promise<{ success: boolean; files?: any[]; error?: string }> {
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .list(folder);

    if (error) throw error;

    return { success: true, files: data };
  } catch (error) {
    console.error('Error listing files:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}