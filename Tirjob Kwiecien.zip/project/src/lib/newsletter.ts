import { supabase } from './supabase';
import { sendEmail } from './email';

export async function subscribeToNewsletter(email: string): Promise<{ success: boolean; error?: string }> {
  try {
    // Check if email already exists
    const { data: existingSubscriber, error: queryError } = await supabase
      .from('newsletter_subscribers')
      .select('id, status')
      .eq('email', email)
      .maybeSingle();

    if (queryError) throw queryError;

    if (existingSubscriber?.status === 'active') {
        return { success: false, error: 'Ten adres email jest już zapisany do newslettera.' };
    }

    if (existingSubscriber?.status === 'unsubscribed') {
        // Reactivate unsubscribed user
        const { error: updateError } = await supabase
          .from('newsletter_subscribers')
          .update({ 
            status: 'active',
            updated_at: new Date().toISOString()
          })
          .eq('id', existingSubscriber.id);

        if (updateError) throw updateError;
        return { success: true };
    } else {
      // Insert new subscriber
      const { error: insertError } = await supabase
        .from('newsletter_subscribers')
        .insert({
          email,
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });

      if (insertError) {
        if (insertError.code === '23505') {
          return { success: false, error: 'Ten adres email jest już zapisany do newslettera.' };
        }
        throw insertError;
      }
    }

    // Send confirmation email
    // Temporarily commented out email sending
    /*
    await sendEmail({
      to: email,
      subject: 'Witamy w newsletterze TirJob.pl! 🚛',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #1e3a8a; margin-bottom: 20px;">Dziękujemy za zapis do newslettera TirJob.pl! 🎉</h1>
          
          <p style="color: #334155; font-size: 16px; line-height: 1.6;">
            Witaj w społeczności TirJob.pl! Od teraz będziesz otrzymywać:
          </p>
          
          <ul style="color: #334155; font-size: 16px; line-height: 1.6;">
            <li>Najlepsze oferty pracy w branży transportowej</li>
            <li>Ekskluzywne porady dla kierowców i specjalistów TSL</li>
            <li>Informacje o trendach i zmianach w branży</li>
            <li>Dostęp do promocji i specjalnych ofert</li>
          </ul>
          
          <p style="color: #334155; font-size: 16px; line-height: 1.6; margin-top: 20px;">
            Śledź nas również w mediach społecznościowych:
          </p>
          
          <div style="margin-top: 20px;">
            <a href="https://facebook.com/tirjob" style="color: #1e3a8a; text-decoration: none; margin-right: 20px;">Facebook</a>
            <a href="https://linkedin.com/company/tirjob" style="color: #1e3a8a; text-decoration: none; margin-right: 20px;">LinkedIn</a>
            <a href="https://instagram.com/tirjob.pl" style="color: #1e3a8a; text-decoration: none;">Instagram</a>
          </div>
          
          <p style="color: #64748b; font-size: 14px; margin-top: 40px;">
            Możesz zrezygnować z subskrypcji w każdej chwili, klikając link "Wypisz się" w stopce każdego newslettera.
          </p>
        </div>
      `
    });
    */

    return { success: true };
  } catch (error) {
    console.error('Error subscribing to newsletter:', error);
    return { 
      success: false, 
      error: 'Wystąpił błąd podczas zapisywania do newslettera. Spróbuj ponownie później.' 
    };
  }
}