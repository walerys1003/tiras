export type UserRole = 'admin' | 'redaktor' | 'moderator' | 'user';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  created_at?: string;
  updated_at?: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
}