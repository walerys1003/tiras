import { z } from 'zod';

export const applicationFormSchema = z.object({
  name: z.string()
    .min(2, 'Imię i nazwisko musi mieć co najmniej 2 znaki')
    .max(100, 'Imię i nazwisko nie może przekraczać 100 znaków'),
  
  email: z.string()
    .email('Podaj prawidłowy adres email')
    .min(5, 'Email musi mieć co najmniej 5 znaków')
    .max(100, 'Email nie może przekraczać 100 znaków'),
  
  phone: z.string()
    .regex(
      /^(\+\d{1,4})?[\s-]?\d{3}[\s-]?\d{3}[\s-]?\d{3}$/, 
      'Podaj prawidłowy numer telefonu (np. +48 501 234 567)'
    ),
  
  message: z.string()
    .min(10, 'Wiadomość musi mieć co najmniej 10 znaków')
    .max(2000, 'Wiadomość nie może przekraczać 2000 znaków'),
  
  cv: z.instanceof(File)
    .refine(
      file => file.size <= 5 * 1024 * 1024,
      'Maksymalny rozmiar pliku to 5MB'
    )
    .refine(
      file => [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      ].includes(file.type),
      'Dozwolone formaty plików: PDF, DOC, DOCX'
    )
    .optional()
});