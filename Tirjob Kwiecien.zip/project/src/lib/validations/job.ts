import { z } from 'zod';

export const jobFormSchema = z.object({
  // Basic Info
  country: z.string({
    required_error: 'Wybierz kraj',
    invalid_type_error: 'Wybierz kraj'
  }).min(1, 'Wybierz kraj'),
  voivodeship: z.string().optional(),
  city: z.string({
    required_error: 'Podaj miasto',
    invalid_type_error: 'Podaj miasto'
  }).min(1, 'Podaj miasto'),
  position: z.object({
    category: z.string({
      required_error: 'Wybierz kategorię',
      invalid_type_error: 'Wybierz kategorię'
    }).min(1, 'Wybierz kategorię'),
    type: z.string({
      required_error: 'Wybierz stanowisko',
      invalid_type_error: 'Wybierz stanowisko'
    }).min(1, 'Wybierz stanowisko')
  }),
  workType: z.string({
    required_error: 'Wybierz rodzaj pracy',
    invalid_type_error: 'Wybierz rodzaj pracy'
  }).min(1, 'Wybierz rodzaj pracy'),
  trailerType: z.string({
    required_error: 'Wybierz rodzaj naczepy',
    invalid_type_error: 'Wybierz rodzaj naczepy'
  }).min(1, 'Wybierz rodzaj naczepy'),
  schedule: z.string({
    required_error: 'Wybierz system pracy',
    invalid_type_error: 'Wybierz system pracy'
  }).min(1, 'Wybierz system pracy'),

  // Job Details
  duties: z.array(z.string(), {
    required_error: 'Dodaj przynajmniej jeden obowiązek',
    invalid_type_error: 'Dodaj przynajmniej jeden obowiązek'
  }).min(1, 'Dodaj przynajmniej jeden obowiązek'),
  experience: z.string({
    required_error: 'Wybierz wymagane doświadczenie',
    invalid_type_error: 'Wybierz wymagane doświadczenie'
  }).min(1, 'Wybierz wymagane doświadczenie'),
  languages: z.array(z.string(), {
    required_error: 'Wybierz przynajmniej jeden język',
    invalid_type_error: 'Wybierz przynajmniej jeden język'
  }).min(1, 'Wybierz przynajmniej jeden język'),
  qualifications: z.array(z.string()),
  benefits: z.array(z.string(), {
    required_error: 'Dodaj przynajmniej jeden benefit',
    invalid_type_error: 'Dodaj przynajmniej jeden benefit'
  }).min(1, 'Dodaj przynajmniej jeden benefit'),

  // Contact Info
  companyName: z.string({
    required_error: 'Podaj nazwę firmy',
    invalid_type_error: 'Podaj nazwę firmy'
  }).min(1, 'Podaj nazwę firmy'),
  email: z.string({
    required_error: 'Podaj adres email',
    invalid_type_error: 'Podaj adres email'
  }).email('Podaj prawidłowy adres email'),
  phone: z.string({
    required_error: 'Podaj numer telefonu',
    invalid_type_error: 'Podaj numer telefonu'
  }).regex(/^\+?[\d\s-]{9,}$/, 'Podaj prawidłowy numer telefonu'),
  nip: z.string().optional(),
  invoiceData: z.string().optional(),

  // Payment Info
  salary: z.object({
    type: z.string({
      required_error: 'Wybierz rodzaj wynagrodzenia',
      invalid_type_error: 'Wybierz rodzaj wynagrodzenia'
    }).min(1, 'Wybierz rodzaj wynagrodzenia'),
    amount: z.string({
      required_error: 'Podaj kwotę wynagrodzenia',
      invalid_type_error: 'Podaj kwotę wynagrodzenia'
    })
    .min(1, 'Podaj kwotę wynagrodzenia')
    .refine(
      (val) => {
        const amount = parseFloat(val.replace(/[^\d.,]/g, '').replace(',', '.'));
        return !isNaN(amount) && amount > 0 && amount < 1000000;
      },
      {
        message: 'Podaj prawidłową kwotę wynagrodzenia (większą od 0 i mniejszą od 1 000 000)',
        path: ['amount']
      }
    ),
    currency: z.string({
      required_error: 'Wybierz walutę',
      invalid_type_error: 'Wybierz walutę'
    }).min(1, 'Wybierz walutę')
  }),
  promotionOptions: z.object({
    highlight: z.boolean(),
    isPremium: z.boolean()
  })
});