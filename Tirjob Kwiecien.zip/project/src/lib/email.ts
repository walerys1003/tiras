import { supabase } from './supabase';

interface EmailTemplate {
  subject: string;
  message: string;
}

export const sendEmail = async (
  to: string,
  template: EmailTemplate,
  attachment?: File
): Promise<boolean> => {
  try {
    const formData = new FormData();
    const apiKey = "72548f80-6b3a-4a9d-93ed-afc7f0b98975";
    formData.append('mail_to', to);
    formData.append('subject', template.subject);
    formData.append('message', template.message);
    formData.append('api_key', apiKey);
    
    if (attachment) {
      // Explicitly set the file name and type for the attachment
      formData.append('attachment', attachment, attachment.name);
      // Add content type hint for the server
      formData.append('attachment_type', attachment.type);
    }

    const response = await fetch('https://mail-api.tirjob.pl/email.php', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      const text = await response.text();
      console.error('Email API error response:', text);
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    // Try to parse as JSON, but handle non-JSON responses gracefully
    try {
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const result = await response.json();
        return result.status === 'success';
      } else {
        const text = await response.text();
        // If response contains "success" somewhere, consider it successful
        return text.toLowerCase().includes('success');
      }
    } catch (error) {
      console.error('Error parsing email API response:', error);
      return false;
    }
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};

// Base template function
export function createEmailTemplate(
  title: string,
  content: string,
  buttonText?: string,
  buttonUrl?: string
): { subject: string; message: string } {
  const html = `
    <!DOCTYPE html>
    <html lang="pl">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${title}</title>
      <style>
        body {
          font-family: 'Inter', Arial, sans-serif;
          line-height: 1.6;
          color: #1e3a8a;
          margin: 0;
          padding: 0;
          background-color: #f2f5f9;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
        }
        .header {
          background-color: #1e3a8a;
          color: white;
          padding: 30px;
          text-align: center;
          border-radius: 16px 16px 0 0;
          position: relative;
          overflow: hidden;
        }
        .header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: url('https://images.unsplash.com/photo-1519003722824-194d4455a60c?ixlib=rb-4.0.3') center/cover;
          opacity: 0.1;
        }
        .header h1 {
          position: relative;
          margin: 0;
          font-size: 24px;
          font-weight: bold;
        }
        .content {
          background: #ffffff;
          padding: 30px;
          border: 1px solid #e2e8f0;
          border-top: none;
          border-radius: 0 0 16px 16px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .button {
          display: inline-block;
          padding: 12px 24px;
          background-color: #e11d48;
          color: white;
          text-decoration: none;
          border-radius: 50px;
          margin: 20px 0;
          font-weight: 500;
          transition: all 0.2s;
        }
        .button:hover {
          background-color: #be123c;
        }
        .footer {
          text-align: center;
          padding: 20px;
          color: #64748b;
          font-size: 14px;
        }
        .logo {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 20px;
        }
        .logo svg {
          width: 32px;
          height: 32px;
          margin-right: 8px;
          color: #e11d48;
        }
        .logo-text {
          font-size: 24px;
          font-weight: bold;
          color: #1e3a8a;
        }
        .social-links {
          margin-top: 20px;
          padding-top: 20px;
          border-top: 1px solid #e2e8f0;
        }
        .social-links a {
          display: inline-block;
          padding: 8px 16px;
          color: #e11d48;
          text-decoration: none;
          margin: 0 10px;
          border-radius: 20px;
          transition: all 0.2s;
        }
        .social-links a:hover {
          color: #e11d48;
        }
        .highlight-box {
          background-color: #f8fafc;
          border-left: 4px solid #e11d48;
          padding: 16px;
          margin: 20px 0;
          border-radius: 0 8px 8px 0;
        }
        h2 {
          color: #1e3a8a;
          margin-top: 24px;
          font-size: 20px;
        }
        h3 {
          color: #1e3a8a;
          margin-top: 20px;
          font-size: 16px;
        }
        ul {
          list-style: none;
          padding: 0;
          margin: 16px 0;
        }
        ul li {
          padding: 8px 0;
          border-bottom: 1px solid #e2e8f0;
        }
        ul li:last-child {
          border-bottom: none;
        }
        strong {
          color: #1e3a8a;
        }
        .accent {
          color: #e11d48;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>${title}</h1>
        </div>
        <div class="content">
          <div class="logo">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M3 3h18v13H3z"></path>
              <path d="M3 16h18"></path>
              <path d="M8 20h8"></path>
              <path d="M19 16v3"></path>
              <path d="M5 16v3"></path>
            </svg>
            <span class="logo-text">TirJob.pl</span>
          </div>
          ${content}
          ${buttonText && buttonUrl ? `
            <div style="text-align: center;">
              <a href="${buttonUrl}" class="button">${buttonText}</a>
            </div>
          ` : ''}
          <div class="social-links">
            <a href="https://facebook.com/tirjob">Facebook</a>
            <a href="https://linkedin.com/company/tirjob">LinkedIn</a>
            <a href="https://instagram.com/tirjob.pl">Instagram</a>
          </div>
        </div>
        <div class="footer">
          <p>© ${new Date().getFullYear()} TirJob.pl. Wszelkie prawa zastrzeżone.</p>
          <p>ul. Świeradowska 47, 02-662 Warszawa</p>
          <p>
            <a href="https://tirjob.pl" style="color: #3b5998; text-decoration: none;">tirjob.pl</a> |
            <a href="mailto:kontakt@tirjob.pl" style="color: #3b5998; text-decoration: none;">kontakt@tirjob.pl</a>
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
  return {
    subject: title,
    message: html
  };
}

// Helper function to send application emails
export async function sendApplicationEmails({
  candidateName,
  candidateEmail,
  candidatePhone,
  message,
  jobTitle,
  employerEmail,
  cvFile
}: {
  candidateName: string;
  candidateEmail: string;
  candidatePhone: string;
  message: string;
  jobTitle: string;
  employerEmail: string;
  cvFile: File;
}): Promise<boolean> {
  try {
    // First send email to employer with CV attachment
    const employerTemplate = createEmailTemplate(
      `Nowa aplikacja na stanowisko: ${jobTitle}`,
      `
        <div class="highlight-box">
          <h2>Nowa aplikacja na stanowisko: ${jobTitle}</h2>
        </div>

        <h3>Dane kandydata:</h3>
        <ul>
          <li><strong>Imię i nazwisko:</strong> ${candidateName}</li>
          <li><strong>Email:</strong> ${candidateEmail}</li>
          <li><strong>Telefon:</strong> ${candidatePhone}</li>
        </ul>

        <h3>Wiadomość od kandydata:</h3>
        <div class="highlight-box">
          <p style="white-space: pre-line;">${message}</p>
        </div>

        <p class="accent">CV kandydata znajduje się w załączniku.</p>
      `
    );
    
    // Send email to employer with CV attachment
    const employerEmailSent = await sendEmail(
      employerEmail,
      employerTemplate,
      cvFile // Make sure to pass the CV file here
    );

    if (!employerEmailSent) {
      console.error('Failed to send email to employer');
      throw new Error('Failed to send email to employer');
    }

    // Then send confirmation to candidate
    const candidateTemplate = createEmailTemplate(
      `Potwierdzenie aplikacji - ${jobTitle}`,
      `
        <div class="highlight-box">
          <h2>Dziękujemy za aplikację!</h2>
        </div>

        <p>Twoja aplikacja na stanowisko <strong>${jobTitle}</strong> została przekazana do pracodawcy.</p>

        <div class="highlight-box">
          <p>Jeśli Twój profil będzie odpowiadał wymaganiom, pracodawca skontaktuje się z Tobą bezpośrednio.</p>
        </div>

        <p>
          Pozdrawiamy,<br>
          Zespół TirJob.pl
        </p>
      `
    );
    
    const candidateEmailSent = await sendEmail(candidateEmail, candidateTemplate);
    if (!candidateEmailSent) {
      console.error('Failed to send confirmation email to candidate');
      throw new Error('Failed to send confirmation email to candidate');
    }
    
    return true;
  } catch (error) {
    console.error('Error sending application emails:', error);
    throw error; // Re-throw the error so it can be handled by the calling code
  }
}