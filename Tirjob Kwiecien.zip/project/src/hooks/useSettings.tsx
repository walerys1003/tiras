import { useState, useEffect, createContext, useContext } from 'react';
import { getAllSettings, saveSettings, type Setting } from '../lib/settings';

interface SettingsContextType {
  settings: Record<string, string>;
  loading: boolean;
  error: string | null;
  updateSettings: (newSettings: Partial<Setting>[]) => Promise<void>;
  refetch: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType>({
  settings: {},
  loading: true,
  error: null,
  updateSettings: async () => {},
  refetch: async () => {}
});

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getAllSettings();
      
      // Convert to a key-value object for easier access
      const settingsMap: Record<string, string> = {};
      data.forEach(setting => {
        settingsMap[setting.key] = setting.value;
      });
      
      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
      setError('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const updateSettings = async (newSettings: Partial<Setting>[]) => {
    try {
      setError(null);
      
      // Save settings
      const result = await saveSettings(newSettings);
      
      if (!result.success) {
        throw new Error(result.error);
      }
      
      // Refresh settings
      await fetchSettings();
    } catch (err) {
      console.error('Error updating settings:', err);
      setError('Failed to update settings');
      throw err;
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  return (
    <SettingsContext.Provider value={{ settings, loading, error, updateSettings, refetch: fetchSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  return useContext(SettingsContext);
}