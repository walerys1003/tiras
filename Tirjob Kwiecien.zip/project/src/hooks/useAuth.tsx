import { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { User, UserRole } from '../lib/types';

console.log('useAuth hook loaded');

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string; user?: User }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  
  console.log('AuthProvider initialized with loading:', loading);

  const checkSession = async () => {
    try {
      console.log('Checking session...');

      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) {
        console.error('Error getting session:', error);
        setUser(null);
        setLoading(false);
        return;
      }
      
      console.log('Session check result:', { 
        hasSession: !!session, 
        user: session?.user ? { 
          id: session.user.id,
          email: session.user.email,
          metadata: session.user.app_metadata 
        } : null 
      });

      if (session?.user) {
        // Get role directly from app_metadata
        const role = session.user.app_metadata?.role as UserRole;
        
        if (role && ['admin', 'redaktor', 'moderator'].includes(role)) {
          // Create user object directly from session data
          const newUser: User = {
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
            role: role
          };
          
          console.log('Created user from auth metadata:', newUser);
          setUser(newUser);
        }
      } else {
        console.log('No session found');
        setUser(null);
      }
    } catch (error) {
      console.error('Unexpected error in checkSession:', error);
      console.error('Error checking session:', error);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkSession();
    console.log('Initial session check triggered');

    const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event);
      
      if (session?.user) {
        // Get role directly from app_metadata
        const role = session.user.app_metadata?.role as UserRole;
        
        if (role && ['admin', 'redaktor', 'moderator'].includes(role)) {
          // Create user object directly from session data
          const newUser: User = {
            id: session.user.id,
            email: session.user.email || '',
            name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
            role: role
          };
          
          console.log('Created user from auth metadata after auth change:', newUser);
          setUser(newUser);
        }
      } else {
        console.log('No session after auth change, setting user to null');
        setUser(null);
      }
    });

    return () => {
      data?.subscription?.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      console.log('signIn called with email:', email);
      // First try to sign in with Supabase Auth
      console.log('Attempting to sign in with:', email);
      const { data: { session }, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (authError) {
        console.log('Auth error during sign in:', authError);
        console.error('Auth error:', authError);
        return { success: false, error: 'Nieprawidłowy email lub hasło', user: undefined };
      }

      if (!session?.user) {
        console.log('No session or user after sign in');
        console.error('No session or user after sign in');
        return { success: false, error: 'Błąd logowania' };
      }

      // Get role directly from app_metadata
      const role = session.user.app_metadata?.role;
      console.log('User role from auth metadata:', role);
      console.log('Full app_metadata:', session.user.app_metadata);

      if (role && ['admin', 'redaktor', 'moderator'].includes(role)) {
        // Create user object directly from session data
        const user: User = {
          id: session.user.id,
          email: session.user.email || '',
          name: session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User',
          role: role as UserRole
        };

        console.log('Setting user with role:', user.role);
        setUser(user);
        return { success: true, user };
      } else {
        console.log('User has no admin role, signing out');
        await supabase.auth.signOut();
        return { success: false, error: 'Brak dostępu do panelu administracyjnego' };
      }

    } catch (error) {
      console.error('Sign in error:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Wystąpił błąd podczas logowania'
      };
    }
  };

  const signOut = async () => {
    try {
      console.log('Signing out user');
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      console.log('User signed out successfully');
      setUser(null);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  console.log('useAuth hook called, context exists:', !!context);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}